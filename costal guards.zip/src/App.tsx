import { useState } from 'react'

// ─── Types ──────────────────────────────────────────────────────────────────
type Screen =
  | 'command' | 'map' | 'vessels' | 'alerts' | 'ai'
  | 'vessel-detail' | 'vessel-risk' | 'cyclone' | 'incident' | 'sar' | 'routes'
type NavTab = 'command' | 'map' | 'vessels' | 'alerts' | 'ai'
type Lang = 'en' | 'hi' | 'mr'

// ─── Risk helpers ────────────────────────────────────────────────────────────
const riskBg = (l: string) =>
  l === 'critical' ? 'bg-red-600' : l === 'high' ? 'bg-orange-500' : l === 'warning' ? 'bg-yellow-500' : 'bg-green-500'
const riskText = (l: string) =>
  l === 'critical' ? 'text-red-600' : l === 'high' ? 'text-orange-600' : l === 'warning' ? 'text-yellow-600' : 'text-green-600'
const riskBorder = (l: string) =>
  l === 'critical' ? 'border-red-600' : l === 'high' ? 'border-orange-500' : l === 'warning' ? 'border-yellow-500' : 'border-green-500'
const riskLightBg = (l: string) =>
  l === 'critical' ? 'bg-red-50' : l === 'high' ? 'bg-orange-50' : l === 'warning' ? 'bg-yellow-50' : 'bg-green-50'

// ─── STATUS BAR ─────────────────────────────────────────────────────────────
function StatusBar() {
  return (
    <div className="flex justify-between items-center px-5 pt-2 pb-1 text-white text-[11px] font-semibold" style={{ background: '#0B1A2E' }}>
      <span>9:41</span>
      <div className="flex gap-1.5 items-center">
        <svg width="16" height="11" viewBox="0 0 16 11">
          <rect x="0" y="7" width="3" height="4" rx="0.5" fill="white" fillOpacity="0.5"/>
          <rect x="4" y="5" width="3" height="6" rx="0.5" fill="white" fillOpacity="0.7"/>
          <rect x="8" y="2.5" width="3" height="8.5" rx="0.5" fill="white"/>
          <rect x="12" y="0" width="3" height="11" rx="0.5" fill="white"/>
        </svg>
        <svg width="15" height="11" viewBox="0 0 15 11">
          <path d="M7.5 4C9 4 10.3 4.6 11.2 5.6L12.4 4.4C11.1 3.1 9.4 2.3 7.5 2.3S3.9 3.1 2.6 4.4L3.8 5.6C4.7 4.6 6 4 7.5 4Z" fill="white" fillOpacity="0.5"/>
          <path d="M7.5 6.5C8.4 6.5 9.2 6.9 9.8 7.5L11 6.3C10 5.3 8.8 4.8 7.5 4.8S5 5.3 4 6.3L5.2 7.5C5.8 6.9 6.6 6.5 7.5 6.5Z" fill="white" fillOpacity="0.8"/>
          <circle cx="7.5" cy="10" r="1.8" fill="white"/>
        </svg>
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0" y="1" width="22" height="10" rx="2" stroke="white" strokeWidth="1.5" fill="none"/>
          <rect x="1.5" y="2.5" width="16" height="7" rx="1" fill="white"/>
          <path d="M23.5 4.5V7.5C24.5 7.1 25 6.5 25 6S24.5 4.9 23.5 4.5Z" fill="white" fillOpacity="0.5"/>
        </svg>
      </div>
    </div>
  )
}

// ─── LANGUAGE SELECTOR ───────────────────────────────────────────────────────
function LanguageSelector({ lang, setLang }: { lang: Lang; setLang: (l: Lang) => void }) {
  const [open, setOpen] = useState(false)
  const labels: Record<Lang, string> = { en: 'English', hi: 'हिंदी', mr: 'मराठी' }
  return (
    <div className="relative z-50">
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1 text-white text-[11px] font-medium bg-white/10 rounded-full px-2.5 py-1 border border-white/20"
      >
        🌐 {labels[lang]} ▾
      </button>
      {open && (
        <div className="absolute right-0 top-8 bg-white rounded-xl shadow-xl border border-gray-100 w-28 overflow-hidden">
          {(['en', 'hi', 'mr'] as Lang[]).map(l => (
            <button
              key={l}
              onClick={() => { setLang(l); setOpen(false) }}
              className={`w-full px-3 py-2.5 text-left text-sm ${l === lang ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-gray-700 hover:bg-gray-50'}`}
            >
              {labels[l]}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── APP HEADER ──────────────────────────────────────────────────────────────
function AppHeader({
  lang, setLang, title, onBack, showNotif = false,
}: {
  lang: Lang; setLang: (l: Lang) => void
  title?: string; onBack?: () => void; showNotif?: boolean
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3 shrink-0" style={{ background: '#0B1A2E' }}>
      <div className="flex items-center gap-2.5">
        {onBack ? (
          <button onClick={onBack} className="text-white p-0.5">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M19 12H5M5 12L12 19M5 12L12 5" />
            </svg>
          </button>
        ) : (
          <div className="w-9 h-9 rounded-full bg-cyan-500 flex items-center justify-center shrink-0">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <path d="M4 20h16M4 20l4-8M20 20l-4-8M8 12l4-8 4 8M6 16h12" />
            </svg>
          </div>
        )}
        <div>
          {title ? (
            <span className="text-white font-semibold text-[15px]">{title}</span>
          ) : (
            <>
              <div className="text-white font-bold text-[16px] leading-tight tracking-wide">ORCA</div>
              <div className="text-cyan-400 text-[10px] leading-none font-medium tracking-wider">COASTAL GUARD</div>
            </>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <LanguageSelector lang={lang} setLang={setLang} />
        {showNotif && (
          <button className="relative text-white p-1">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" />
              <path d="M13.73 21a2 2 0 01-3.46 0" />
            </svg>
            <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full text-[9px] flex items-center justify-center font-bold">3</span>
          </button>
        )}
      </div>
    </div>
  )
}

// ─── BOTTOM NAVIGATION ───────────────────────────────────────────────────────
function BottomNav({ active, onSelect }: { active: NavTab; onSelect: (t: NavTab) => void }) {
  const items: { id: NavTab; label: string; icon: React.ReactNode }[] = [
    {
      id: 'command', label: 'Command',
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
    },
    {
      id: 'map', label: 'Map',
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>
    },
    {
      id: 'vessels', label: 'Vessels',
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 17l3-8h12l3 8H3z"/><path d="M12 9V3"/><path d="M9 9h6"/><path d="M1 17h22"/></svg>
    },
    {
      id: 'alerts', label: 'Alerts',
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><circle cx="12" cy="17" r="0.5" fill="currentColor"/></svg>
    },
    {
      id: 'ai', label: 'AI',
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="9"/><line x1="12" y1="3" x2="12" y2="9"/><line x1="12" y1="15" x2="12" y2="21"/><line x1="3" y1="12" x2="9" y2="12"/><line x1="15" y1="12" x2="21" y2="12"/></svg>
    },
  ]
  return (
    <div className="flex shrink-0 border-t" style={{ background: '#0B1A2E', borderColor: '#1a2d47' }}>
      {items.map(item => {
        const sel = active === item.id
        return (
          <button
            key={item.id}
            onClick={() => onSelect(item.id)}
            className={`flex-1 flex flex-col items-center py-2.5 gap-0.5 transition-colors relative ${sel ? 'text-cyan-400' : 'text-slate-500'}`}
          >
            {item.icon}
            <span className="text-[10px] font-medium">{item.label}</span>
            {item.id === 'alerts' && (
              <span className="absolute top-1.5 right-[30%] w-4 h-4 bg-red-500 rounded-full text-[8px] text-white flex items-center justify-center font-bold">3</span>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ─── COASTAL MAP SVG ─────────────────────────────────────────────────────────
function CoastalMap({
  showCyclone = false, showSAR = false, showRoutes = false, compact = false,
}: {
  showCyclone?: boolean; showSAR?: boolean; showRoutes?: boolean; compact?: boolean
}) {
  const h = compact ? 140 : 300
  return (
    <svg viewBox={`0 0 390 ${h}`} className="w-full" style={{ height: h }}>
      <defs>
        <linearGradient id="seaGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1a5276" />
          <stop offset="100%" stopColor="#154360" />
        </linearGradient>
        <marker id="arrowO" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
          <polygon points="0 0, 6 3, 0 6" fill="#f97316" />
        </marker>
        <marker id="arrowG" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
          <polygon points="0 0, 6 3, 0 6" fill="#22c55e" />
        </marker>
        <marker id="arrowR" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
          <polygon points="0 0, 6 3, 0 6" fill="#dc2626" />
        </marker>
        <marker id="arrowS" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
          <polygon points="0 0, 6 3, 0 6" fill="#94a3b8" />
        </marker>
      </defs>

      {/* Sea */}
      <rect width="390" height={h} fill="url(#seaGrad)" />

      {/* Sea grid */}
      {[...Array(7)].map((_, i) => (
        <line key={`gh${i}`} x1="0" y1={i * (h / 6)} x2="390" y2={i * (h / 6)} stroke="white" strokeOpacity="0.04" strokeWidth="1" />
      ))}
      {[...Array(9)].map((_, i) => (
        <line key={`gv${i}`} x1={i * 50} y1="0" x2={i * 50} y2={h} stroke="white" strokeOpacity="0.04" strokeWidth="1" />
      ))}

      {/* Scale relative to compact */}
      <g transform={compact ? 'scale(0.46, 0.47) translate(-10, 10)' : 'translate(0,0)'}>
        {/* Mainland coast (Maharashtra) */}
        <path d="M390,0 L390,300 L255,300 L235,280 L225,255 L220,230 L224,205 L232,178 L242,148 L248,118 L244,88 L248,58 L262,35 L280,15 L310,0 Z" fill="#c4b591" />
        {/* Mumbai peninsula */}
        <path d="M232,178 L236,158 L241,136 L247,112 L243,88 L237,66 L230,52 L222,62 L217,84 L213,112 L211,140 L213,168 Z" fill="#c4b591" />
        {/* Old Mumbai north bulge */}
        <path d="M215,56 L222,50 L228,56 L223,68 L215,63 Z" fill="#c4b591" />
        {/* Alibag peninsula */}
        <path d="M202,238 L213,232 L218,248 L213,262 L200,255 Z" fill="#c4b591" />
        {/* Ratnagiri */}
        <path d="M168,282 L182,276 L190,295 L174,300 L162,295 Z" fill="#c4b591" />

        {/* Labels */}
        <text x="230" y="115" fill="#7a6a45" fontSize="9" fontFamily="sans-serif" fontWeight="600">Mumbai</text>
        <text x="200" y="254" fill="#7a6a45" fontSize="8" fontFamily="sans-serif">Alibag</text>
        <text x="164" y="292" fill="#7a6a45" fontSize="7" fontFamily="sans-serif">Ratnagiri</text>
        <text x="90" y="170" fill="#4a87b0" fontSize="11" fontFamily="sans-serif" fontWeight="700" fontStyle="italic">Arabian Sea</text>

        {/* Lat/lon */}
        <text x="4" y="296" fill="white" fillOpacity="0.3" fontSize="8" fontFamily="monospace">72.0°E 18.0°N</text>
        <text x="4" y="42" fill="white" fillOpacity="0.3" fontSize="8" fontFamily="monospace">19.5°N</text>

        {/* MPA boundary */}
        <rect x="50" y="240" width="88" height="50" rx="4" fill="#22c55e08" stroke="#22c55e" strokeWidth="1.5" strokeDasharray="5,3" />
        <text x="68" y="268" fill="#22c55e" fontSize="7" fontFamily="sans-serif" fontWeight="600">Marine Protected Area</text>

        {/* Restricted area */}
        <polygon points="175,82 205,72 215,102 183,112" fill="#dc262610" stroke="#dc2626" strokeWidth="1.5" />
        <text x="183" y="95" fill="#dc2626" fontSize="7" fontFamily="sans-serif" fontWeight="600">RESTRICTED</text>

        {/* Cyclone + hazard */}
        {showCyclone && (
          <>
            <circle cx="95" cy="175" r="95" fill="#dc262608" stroke="#dc2626" strokeWidth="1.5" strokeDasharray="6,4" />
            <circle cx="95" cy="175" r="55" fill="#dc262614" />
            <text x="90" y="172" fontSize="28" textAnchor="middle">🌀</text>
            <text x="90" y="197" fill="#dc2626" fontSize="8" fontFamily="sans-serif" fontWeight="700" textAnchor="middle">CYCLONE</text>
            <path d="M35,285 L55,245 L75,210 L95,175 L115,138 L138,98 L158,62" stroke="#dc2626" strokeWidth="2.5" strokeDasharray="8,5" fill="none" />
            <polygon points="158,62 150,68 162,72" fill="#dc2626" />
          </>
        )}
        {!showCyclone && (
          <>
            {/* Hazard zone */}
            <circle cx="155" cy="200" r="26" fill="#f9731620" stroke="#f97316" strokeWidth="1.5" strokeDasharray="3,3" />
          </>
        )}

        {/* Safe harbour */}
        <circle cx="68" cy="278" r="9" fill="#15803d" />
        <text x="68" y="282" fill="white" fontSize="11" textAnchor="middle">⚓</text>
        <text x="68" y="292" fill="#22c55e" fontSize="7" textAnchor="middle" fontWeight="600">Harbour</text>

        {/* Guard position */}
        <circle cx="195" cy="215" r="13" fill="#2563eb20" stroke="#2563eb" strokeWidth="2" />
        <circle cx="195" cy="215" r="5" fill="#2563eb" />
        <circle cx="195" cy="215" r="2" fill="white" />

        {/* Normal vessels */}
        {[[75, 148], [125, 258], [58, 200], [48, 125], [108, 302], [35, 170]].map(([x, y], i) => (
          <g key={`nv${i}`}>
            <circle cx={x} cy={y} r="6" fill="#22c55e" stroke="white" strokeWidth="1.5" />
          </g>
        ))}

        {/* Warning vessels */}
        {[[162, 222], [88, 232], [142, 172]].map(([x, y], i) => (
          <circle key={`wv${i}`} cx={x} cy={y} r="7" fill="#eab308" stroke="white" strokeWidth="1.5" />
        ))}

        {/* High risk */}
        <circle cx="128" cy="192" r="7" fill="#f97316" stroke="white" strokeWidth="1.5" />
        <text x="128" y="196.5" fill="white" fontSize="9" textAnchor="middle" fontWeight="bold">!</text>

        {/* Critical IND-1042 */}
        <circle cx="155" cy="200" r="9" fill="#dc2626" stroke="white" strokeWidth="2" />
        <text x="155" y="204" fill="white" fontSize="9.5" textAnchor="middle" fontWeight="bold">!</text>
        <text x="155" y="217" fill="#dc2626" fontSize="7.5" textAnchor="middle" fontWeight="700" style={{ fontFamily: 'monospace' }}>1042</text>

        {/* SAR drift */}
        {showSAR && (
          <>
            <path d="M155,200 L162,222 L168,248" stroke="#f97316" strokeWidth="2.5" strokeDasharray="5,3" markerEnd="url(#arrowO)" fill="none" />
            <circle cx="168" cy="248" r="9" fill="#f97316" stroke="white" strokeWidth="2" />
            <text x="168" y="252" fill="white" fontSize="8.5" textAnchor="middle" fontWeight="700">P</text>
            <circle cx="168" cy="248" r="32" fill="#f9731614" stroke="#f97316" strokeWidth="2" strokeDasharray="5,3" />
            <text x="155" y="190" fill="white" fontSize="8" textAnchor="middle" fontWeight="600">Last Known</text>
          </>
        )}

        {/* Routes */}
        {showRoutes && (
          <>
            {/* Plan A */}
            <path d="M195,215 L175,205 L160,200" stroke="#dc2626" strokeWidth="2.5" fill="none" markerEnd="url(#arrowR)" />
            {/* Plan B (recommended) */}
            <path d="M195,215 L182,238 L172,258 L163,248 L159,202" stroke="#22c55e" strokeWidth="3" fill="none" markerEnd="url(#arrowG)" />
            {/* Plan C */}
            <path d="M195,215 L202,248 L188,278 L168,268 L159,202" stroke="#94a3b8" strokeWidth="2" fill="none" strokeDasharray="5,3" markerEnd="url(#arrowS)" />
          </>
        )}
      </g>
    </svg>
  )
}

// ─── RISK BADGE ───────────────────────────────────────────────────────────────
function RiskBadge({ level, size = 'sm' }: { level: string; size?: 'sm' | 'lg' }) {
  const cls = size === 'lg'
    ? `px-3 py-1 rounded-lg text-sm font-bold uppercase tracking-wide text-white ${riskBg(level)}`
    : `px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide text-white ${riskBg(level)}`
  return <span className={cls}>{level}</span>
}

// ─── STATUS BADGE ────────────────────────────────────────────────────────────
function StatusBadge({ label, level }: { label: string; level: string }) {
  return (
    <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border ${riskBorder(level)} ${riskLightBg(level)}`}>
      <div className={`w-2 h-2 rounded-full ${riskBg(level)}`} />
      <span className={`text-xs font-bold uppercase tracking-wide ${riskText(level)}`}>{label}</span>
    </div>
  )
}

// ─── SCREEN 1: COMMAND CENTER ────────────────────────────────────────────────
function CommandCenter({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const t = lang === 'mr'
    ? { morning: 'शुभ प्रभात, अधिकारी', sector: 'मुंबई किनारी क्षेत्र', status: 'सामान्य', statusDesc: 'सध्या कोणताही मोठा धोका नाही', vessels: 'निरीक्षित जहाजे', alerts: 'सक्रिय अलर्ट', highRisk: 'उच्च धोका', incidents: 'सक्रिय घटना', priority: 'प्राधान्य कृती', priorityMsg: '२ जहाजे चक्रीवादळ क्षेत्रात आहेत.', viewVessels: 'जहाजे पहा', askOrca: 'ORCA ला विचारा', liveMap: 'थेट नकाशा पहा' }
    : lang === 'hi'
    ? { morning: 'शुभ प्रभात, अधिकारी', sector: 'मुंबई तटीय क्षेत्र', status: 'सामान्य', statusDesc: 'अभी कोई बड़ा खतरा नहीं है', vessels: 'निगरानी जहाज', alerts: 'सक्रिय अलर्ट', highRisk: 'उच्च जोखिम', incidents: 'सक्रिय घटना', priority: 'प्राथमिकता कार्य', priorityMsg: '२ जहाज चक्रवात प्रभाव क्षेत्र में हैं।', viewVessels: 'जहाज देखें', askOrca: 'ORCA से पूछें', liveMap: 'लाइव मैप देखें' }
    : { morning: 'Good morning, Officer', sector: 'Mumbai Coastal Sector', status: 'NORMAL', statusDesc: 'No major threat at this time', vessels: 'Vessels Monitored', alerts: 'Active Alerts', highRisk: 'High-Risk Vessels', incidents: 'Active Incidents', priority: 'PRIORITY ACTION', priorityMsg: '2 vessels are within the affected cyclone zone.', viewVessels: 'VIEW VESSELS', askOrca: '🎙 Ask ORCA', liveMap: 'View Live Map →' }

  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Greeting */}
      <div className="px-4 pt-4 pb-3" style={{ background: '#0B1A2E' }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-600 flex items-center justify-center overflow-hidden border-2 border-cyan-400">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#e2e8f0" strokeWidth="2">
              <circle cx="12" cy="8" r="4" /><path d="M6 20c0-3.3 2.7-6 6-6s6 2.7 6 6" />
            </svg>
          </div>
          <div>
            <div className="text-white font-bold text-base">{t.morning}</div>
            <div className="flex items-center gap-1 text-cyan-300 text-xs mt-0.5">
              <span>📍</span><span>{t.sector}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-3 space-y-3">
        {/* Maritime Status */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Today's Maritime Status</div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </div>
              <div>
                <div className="text-green-600 font-extrabold text-xl tracking-wide">{t.status}</div>
                <div className="text-slate-500 text-xs mt-0.5">{t.statusDesc}</div>
              </div>
            </div>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: t.vessels, value: '27', color: 'text-blue-600', bg: 'bg-blue-50', icon: '🚢' },
            { label: t.alerts, value: '03', color: 'text-red-600', bg: 'bg-red-50', icon: '🚨' },
            { label: t.highRisk, value: '02', color: 'text-orange-600', bg: 'bg-orange-50', icon: '⚠' },
            { label: t.incidents, value: '01', color: 'text-yellow-700', bg: 'bg-yellow-50', icon: '📋' },
          ].map((s, i) => (
            <button key={i} onClick={() => navigate(i === 0 ? 'vessels' : i === 1 ? 'alerts' : i === 2 ? 'vessel-detail' : 'incident')}
              className={`${s.bg} rounded-xl p-2.5 text-center active:scale-95 transition-transform shadow-sm`}>
              <div className="text-lg mb-0.5">{s.icon}</div>
              <div className={`font-extrabold text-xl ${s.color}`}>{s.value}</div>
              <div className="text-[9px] font-semibold text-slate-500 leading-tight mt-0.5">{s.label}</div>
            </button>
          ))}
        </div>

        {/* Map preview */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
          <div className="relative">
            <CoastalMap compact />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
            <button
              onClick={() => navigate('map')}
              className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-white/95 text-slate-800 text-xs font-semibold px-4 py-2 rounded-full shadow flex items-center gap-1"
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6" /><line x1="8" y1="2" x2="8" y2="18" /><line x1="16" y1="6" x2="16" y2="22" /></svg>
              {t.liveMap}
            </button>
          </div>
        </div>

        {/* Priority action */}
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-7 h-7 rounded-full bg-red-500 flex items-center justify-center">
              <span className="text-white text-sm font-bold">!</span>
            </div>
            <span className="text-red-700 font-bold text-sm uppercase tracking-wide">{t.priority}</span>
          </div>
          <p className="text-slate-700 text-sm leading-relaxed mb-3">{t.priorityMsg}</p>
          <button
            onClick={() => navigate('cyclone')}
            className="w-full bg-red-600 text-white font-bold text-sm py-2.5 rounded-xl active:scale-95 transition-transform"
          >
            {t.viewVessels} →
          </button>
        </div>

        {/* ASK ORCA */}
        <button
          onClick={() => navigate('ai')}
          className="w-full py-4 rounded-2xl font-bold text-white text-base flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
          style={{ background: 'linear-gradient(135deg, #1E6FD9 0%, #0EA5E9 100%)' }}
        >
          <span className="text-xl">🎙</span>
          <span>{t.askOrca}</span>
        </button>
      </div>
    </div>
  )
}

// ─── SCREEN 2: LIVE MARINE MAP ────────────────────────────────────────────────
function LiveMarineMap({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const [activeLayers, setActiveLayers] = useState(['Vessels', 'Hazards', 'Cyclone'])
  const [showSheet, setShowSheet] = useState(true)
  const layers = ['Vessels', 'Hazards', 'Cyclone', 'Waves', 'Wind', 'MPA', 'Restricted', 'Safe Harbour']

  return (
    <div className="flex-1 relative overflow-hidden">
      {/* Map */}
      <div className="absolute inset-0">
        <CoastalMap showCyclone />
      </div>

      {/* Search bar */}
      <div className="absolute top-2 left-3 right-3 z-10">
        <div className="bg-white rounded-xl shadow-lg flex items-center gap-2 px-3 py-2.5">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2.5"><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" /></svg>
          <span className="text-slate-400 text-sm">Search vessel / location...</span>
          <div className="ml-auto">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2"><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M4.22 4.22l2.12 2.12M17.66 17.66l2.12 2.12M2 12h3M19 12h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12" /></svg>
          </div>
        </div>
      </div>

      {/* Layer chips */}
      <div className="absolute top-16 left-0 right-0 z-10 px-3">
        <div className="flex gap-1.5 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
          {layers.map(l => {
            const active = activeLayers.includes(l)
            return (
              <button
                key={l}
                onClick={() => setActiveLayers(prev => prev.includes(l) ? prev.filter(x => x !== l) : [...prev, l])}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${active ? 'bg-white border-cyan-400 text-cyan-600' : 'bg-black/30 border-white/20 text-white'}`}
              >
                {l}
              </button>
            )
          })}
        </div>
      </div>

      {/* Map controls */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 z-10 flex flex-col gap-2">
        {[
          { icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="5" /><line x1="12" y1="2" x2="12" y2="7" /><line x1="12" y1="17" x2="12" y2="22" /><line x1="2" y1="12" x2="7" y2="12" /><line x1="17" y1="12" x2="22" y2="12" /></svg>, action: () => {} },
          { icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>, action: () => {} },
          { icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="5" y1="12" x2="19" y2="12" /></svg>, action: () => {} },
        ].map((c, i) => (
          <button key={i} onClick={c.action} className="w-10 h-10 bg-white rounded-xl shadow-lg flex items-center justify-center text-slate-700 active:scale-95">
            {c.icon}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div className="absolute left-3 bottom-40 z-10 bg-black/70 rounded-xl p-2.5 text-white text-[10px] space-y-1.5">
        {[
          ['bg-green-500', 'Vessel (Normal)'],
          ['bg-yellow-500', 'Warning Vessel'],
          ['bg-orange-500', 'High-Risk Vessel'],
          ['bg-red-600', 'Critical Vessel'],
          ['bg-red-600 opacity-50', 'Cyclone Track'],
          ['bg-orange-500 opacity-50', 'Hazard Zone'],
          ['border-2 border-red-600', 'Restricted Area'],
          ['border-2 border-green-500', 'MPA'],
          ['bg-green-700', 'Safe Harbour'],
        ].map(([cls, label]) => (
          <div key={label} className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${cls}`} />
            <span>{label}</span>
          </div>
        ))}
      </div>

      {/* Bottom sheet - vessel info */}
      {showSheet && (
        <div className="absolute bottom-0 left-0 right-0 z-20 bg-white rounded-t-3xl shadow-2xl">
          <div className="flex justify-center pt-2 pb-1">
            <div className="w-10 h-1 bg-slate-200 rounded-full" />
          </div>
          <div className="px-4 pb-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="font-bold text-slate-800 text-base">IND-1042</div>
                <div className="text-slate-500 text-xs">Fishing Vessel</div>
              </div>
              <RiskBadge level="critical" />
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              {[['Distance', '14.2 km'], ['Speed', '6.4 kn'], ['Heading', '132°']].map(([k, v]) => (
                <div key={k} className="bg-slate-50 rounded-xl p-2.5 text-center">
                  <div className="font-bold text-slate-800 text-sm">{v}</div>
                  <div className="text-slate-400 text-[10px] mt-0.5">{k}</div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <button className="flex-1 bg-slate-100 text-slate-700 font-bold py-3 rounded-xl text-sm active:scale-95">TRACK</button>
              <button onClick={() => navigate('vessel-detail')} className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl text-sm active:scale-95">VIEW VESSEL</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── VESSEL LIST SCREEN ───────────────────────────────────────────────────────
function VesselsList({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const vessels = [
    { id: 'IND-1042', type: 'Fishing Vessel', distance: '14.2 km', risk: 'critical', speed: '6.4 kn' },
    { id: 'IND-0871', type: 'Traditional Motorized', distance: '8.7 km', risk: 'high', speed: '4.1 kn' },
    { id: 'MH-2234', type: 'Fishing Vessel', distance: '22.1 km', risk: 'warning', speed: '5.8 kn' },
    { id: 'GJ-0341', type: 'Cargo Boat', distance: '31.4 km', risk: 'warning', speed: '7.2 kn' },
    { id: 'MH-1108', type: 'Fishing Vessel', distance: '18.9 km', risk: 'normal', speed: '3.5 kn' },
    { id: 'KA-5501', type: 'Traditional Motorized', distance: '45.2 km', risk: 'normal', speed: '6.0 kn' },
    { id: 'MH-0022', type: 'Fishing Vessel', distance: '52.8 km', risk: 'normal', speed: '4.9 kn' },
  ]
  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Summary bar */}
      <div className="px-4 py-3 bg-white border-b border-slate-100">
        <div className="text-[11px] font-semibold text-slate-500 mb-2 uppercase tracking-widest">All Vessels — Live</div>
        <div className="flex gap-2">
          {[['27', 'Total', 'bg-blue-100 text-blue-600'], ['02', 'Critical/High', 'bg-red-100 text-red-600'], ['03', 'Warning', 'bg-yellow-100 text-yellow-700'], ['22', 'Normal', 'bg-green-100 text-green-600']].map(([v, l, c]) => (
            <div key={l} className={`flex-1 rounded-xl px-2 py-1.5 text-center ${c}`}>
              <div className="font-extrabold text-base">{v}</div>
              <div className="text-[9px] font-semibold leading-tight">{l}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="px-4 py-3 space-y-2">
        {vessels.map((v) => (
          <button
            key={v.id}
            onClick={() => navigate('vessel-detail')}
            className="w-full bg-white rounded-2xl p-4 shadow-sm flex items-center gap-3 active:scale-98 transition-transform"
          >
            <div className={`w-10 h-10 rounded-full ${riskBg(v.risk)} flex items-center justify-center shrink-0`}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <path d="M3 17l3-8h12l3 8H3z" /><path d="M12 9V4" /><path d="M1 17h22" />
              </svg>
            </div>
            <div className="flex-1 text-left">
              <div className="font-bold text-slate-800 text-sm">{v.id}</div>
              <div className="text-slate-400 text-xs">{v.type} • {v.distance}</div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <RiskBadge level={v.risk} />
              <div className="text-[10px] text-slate-400">{v.speed}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

// ─── SCREEN 3: VESSEL DETAILS ─────────────────────────────────────────────────
function VesselDetails({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const [tab, setTab] = useState('Overview')
  const tabs = ['Overview', 'Route', 'Weather', 'Risk', 'History']

  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Vessel visual header */}
      <div className="relative h-40 overflow-hidden" style={{ background: 'linear-gradient(160deg, #1a4f72 0%, #0f2d45 40%, #1b3a52 100%)' }}>
        {/* Sea wave effect */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 390 160" preserveAspectRatio="xMidYMid slice">
          <rect width="390" height="160" fill="#1a4f72" />
          <path d="M0,100 Q50,85 100,100 Q150,115 200,100 Q250,85 300,100 Q350,115 390,100 L390,160 L0,160 Z" fill="#154360" opacity="0.6" />
          <path d="M0,118 Q60,105 120,118 Q180,131 240,118 Q300,105 390,118 L390,160 L0,160 Z" fill="#0d2b3e" opacity="0.5" />
          {/* Vessel silhouette */}
          <g transform="translate(115, 50)">
            <rect x="20" y="30" width="120" height="30" rx="4" fill="#2d5a7a" />
            <rect x="40" y="15" width="60" height="20" rx="3" fill="#3a6b8a" />
            <rect x="60" y="5" width="20" height="14" rx="2" fill="#4a7a9b" />
            <line x1="70" y1="0" x2="70" y2="14" stroke="#6a9ab0" strokeWidth="1.5" />
            <path d="M10,60 L150,60 L140,72 L20,72 Z" fill="#2d5a7a" />
            <rect x="85" y="20" width="8" height="16" rx="1" fill="#2d5a7a" />
          </g>
        </svg>
        {/* Status overlay */}
        <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
          <div>
            <div className="text-white font-extrabold text-xl">IND-1042</div>
            <div className="text-slate-300 text-xs">Fishing Vessel</div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <StatusBadge label="CAUTION" level="warning" />
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-green-400 text-[10px] font-medium">Live · 09:42 AM</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick stats */}
      <div className="bg-white px-4 py-3 border-b border-slate-100">
        <div className="grid grid-cols-3 gap-2">
          {[['Distance', '14.2 km'], ['Speed', '6.4 knots'], ['Heading', '132°']].map(([k, v]) => (
            <div key={k} className="text-center">
              <div className="font-bold text-slate-800 text-base">{v}</div>
              <div className="text-slate-400 text-[11px]">{k}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Lat/Lon + Risk */}
      <div className="bg-white px-4 py-3 border-b border-slate-100">
        <div className="grid grid-cols-3 gap-2">
          <div>
            <div className="text-[10px] text-slate-400 mb-0.5">Latitude</div>
            <div className="font-semibold text-slate-700 text-sm font-mono">18.9176° N</div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 mb-0.5">Longitude</div>
            <div className="font-semibold text-slate-700 text-sm font-mono">72.8545° E</div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 mb-0.5">Risk Score</div>
            <div className="flex items-center gap-1">
              <span className="font-bold text-orange-600 text-sm">63 / 100</span>
              <RiskBadge level="high" />
            </div>
          </div>
        </div>
        {/* Risk bar */}
        <div className="mt-2 h-2 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full rounded-full bg-orange-500 transition-all" style={{ width: '63%' }} />
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-slate-100 px-4">
        <div className="flex gap-1 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`shrink-0 px-3 py-3 text-sm font-semibold border-b-2 transition-colors ${tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400'}`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      {tab === 'Overview' && (
        <div className="px-4 py-3 space-y-2">
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">Current Status</div>
            {[
              ['Vessel Type', 'Traditional Motorized'],
              ['Length', '8.5 m'],
              ['Crew', '5'],
              ['Last Contact', 'VHF (09:42 AM)'],
              ['Destination', 'Not available'],
              ['ETA', '—'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between py-2 border-b border-slate-50 last:border-0">
                <span className="text-slate-500 text-sm">{k}</span>
                <span className="text-slate-800 text-sm font-medium">{v}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action buttons */}
      <div className="px-4 py-3 space-y-2">
        <div className="grid grid-cols-3 gap-2">
          <button className="bg-green-600 text-white font-bold py-3 rounded-xl text-sm active:scale-95 flex items-center justify-center gap-1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10" /><polygon points="10 8 16 12 10 16 10 8" /></svg>
            TRACK
          </button>
          <button className="bg-blue-600 text-white font-bold py-3 rounded-xl text-sm active:scale-95 flex items-center justify-center gap-1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" /></svg>
            CONTACT
          </button>
          <button className="bg-slate-100 text-slate-700 font-bold py-3 rounded-xl text-sm active:scale-95">
            ROUTE
          </button>
        </div>
        <button
          onClick={() => navigate('vessel-risk')}
          className="w-full bg-red-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95"
        >
          ASSESS RISK
        </button>
      </div>
    </div>
  )
}

// ─── SCREEN 4: VESSEL RISK ASSESSMENT ────────────────────────────────────────
function VesselRiskAssessment({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Alert header */}
      <div className="mx-4 mt-4 bg-red-600 rounded-2xl p-4 shadow-md">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><circle cx="12" cy="17" r="0.5" fill="white" />
            </svg>
          </div>
          <div className="flex-1">
            <div className="text-white font-bold text-base">Vessel at High Risk</div>
            <div className="text-red-100 text-xs mt-0.5 leading-relaxed">Entering high-wave zone and forecast conditions are deteriorating.</div>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-red-500">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-red-100 text-[10px] font-semibold uppercase tracking-widest">Risk Score</div>
              <div className="text-white font-extrabold text-3xl">63 <span className="text-lg text-red-200 font-medium">/ 100</span></div>
            </div>
            <div className="bg-white/20 px-3 py-1.5 rounded-xl">
              <span className="text-white font-bold text-sm">HIGH RISK</span>
            </div>
          </div>
          <div className="mt-2 h-2 bg-red-800 rounded-full overflow-hidden">
            <div className="h-full bg-white rounded-full" style={{ width: '63%' }} />
          </div>
        </div>
      </div>

      <div className="px-4 py-3 space-y-3">
        {/* Risk factors */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">Key Risk Factors</div>
          {[
            'Wave height above vessel threshold (3.2 m > 2.0 m)',
            'Wind speed increasing (38 km/h, gusts 52 km/h)',
            'Vessel approaching hazard zone (4 km from boundary)',
            'Cyclone influence zone (IMD advisory active)',
            'Route intersects high-risk area',
          ].map((factor, i) => (
            <div key={i} className="flex items-start gap-2.5 py-2.5 border-b border-slate-50 last:border-0">
              <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center shrink-0 mt-0.5">
                <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="#dc2626" strokeWidth="2.5" strokeLinecap="round"><polyline points="2 6 5 9 10 3" /></svg>
              </div>
              <span className="text-slate-700 text-sm leading-snug">{factor}</span>
            </div>
          ))}
        </div>

        {/* Data sources */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">Data Used</div>
          <div className="grid grid-cols-4 gap-2">
            {[
              { name: 'IMD Weather', icon: '🌤' },
              { name: 'INCOIS Ocean Data', icon: '🌊' },
              { name: 'Vessel Profile', icon: '🚢' },
              { name: 'GIS Boundaries', icon: '🗺' },
            ].map(s => (
              <div key={s.name} className="text-center bg-slate-50 rounded-xl p-2.5">
                <div className="text-2xl mb-1">{s.icon}</div>
                <div className="text-[10px] text-slate-600 font-medium leading-tight">{s.name}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ORCA Confidence */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">ORCA Confidence</div>
          <div className="flex items-center gap-4">
            <div className="relative w-20 h-20">
              <svg viewBox="0 0 80 80" className="w-20 h-20 -rotate-90">
                <circle cx="40" cy="40" r="32" fill="none" stroke="#f1f5f9" strokeWidth="8" />
                <circle cx="40" cy="40" r="32" fill="none" stroke="#22c55e" strokeWidth="8"
                  strokeDasharray={`${0.91 * 2 * Math.PI * 32} ${2 * Math.PI * 32}`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="font-extrabold text-green-600 text-xl">91%</span>
              </div>
            </div>
            <div>
              <div className="font-bold text-green-600 text-lg">HIGH</div>
              <div className="text-slate-500 text-xs mt-1 leading-relaxed">Analysis based on real-time IMD and INCOIS data combined with vessel profile.</div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pb-2">
          <button onClick={() => navigate('incident')} className="flex-1 bg-red-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95">
            RESPOND
          </button>
          <button onClick={() => navigate('sar')} className="flex-1 bg-blue-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95">
            SAR ANALYSIS
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── SCREEN 5: ALERTS ────────────────────────────────────────────────────────
function AlertsScreen({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const [filter, setFilter] = useState('All')
  const filters = ['All (12)', 'Critical (3)', 'Warning (5)', 'Info (4)']

  const alerts = [
    {
      level: 'critical', time: '1 hour ago',
      title: 'Vessel IND-1042', desc: 'Entering severe wave zone. Wave height 3.2 m and increasing. Immediate attention required.',
      action: 'VIEW VESSEL', onAction: () => navigate('vessel-detail'),
    },
    {
      level: 'high', time: '3 hours ago',
      title: 'Cyclone track shifted', desc: 'Cyclone track shifted 18 km north. Affects 6 vessels in sector.',
      action: 'VIEW IMPACT', onAction: () => navigate('cyclone'),
    },
    {
      level: 'warning', time: '5 hours ago',
      title: '6 vessels near restricted area', desc: 'Vessels approaching MPA boundary within 10 km.',
      action: 'VIEW VESSELS', onAction: () => navigate('vessels'),
    },
    {
      level: 'info', time: '6 hours ago',
      title: 'New PFZ available', desc: 'High fishing activity zone detected 120 km west.',
      action: 'VIEW MAP', onAction: () => navigate('map'),
    },
    {
      level: 'critical', time: '8 hours ago',
      title: 'Vessel IND-0871 overdue', desc: 'Expected return time passed by 3 hours. No contact.',
      action: 'VIEW VESSEL', onAction: () => navigate('vessel-detail'),
    },
    {
      level: 'warning', time: '10 hours ago',
      title: 'Wind speed alert', desc: 'NW winds exceeding 40 km/h in open sea sectors 4, 5.',
      action: 'VIEW MAP', onAction: () => navigate('map'),
    },
  ]

  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Filter tabs */}
      <div className="bg-white border-b border-slate-100 px-4">
        <div className="flex gap-1 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
          {filters.map(f => {
            const sel = filter === f.split(' ')[0] || (filter === 'All' && f.startsWith('All'))
            return (
              <button
                key={f}
                onClick={() => setFilter(f.split(' ')[0])}
                className={`shrink-0 px-3 py-3 text-sm font-semibold border-b-2 transition-colors ${sel ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400'}`}
              >
                {f}
              </button>
            )
          })}
        </div>
      </div>

      <div className="px-4 py-3 space-y-2">
        {alerts.map((alert, i) => (
          <div key={i} className={`bg-white rounded-2xl overflow-hidden shadow-sm border-l-4 ${riskBorder(alert.level)}`}>
            <div className="px-4 pt-3 pb-1 flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <RiskBadge level={alert.level} />
                <span className="text-slate-400 text-[11px]">{alert.time}</span>
              </div>
            </div>
            <div className="px-4 pb-3">
              <div className="font-bold text-slate-800 text-sm mb-0.5">{alert.title}</div>
              <div className="text-slate-500 text-xs leading-relaxed mb-2.5">{alert.desc}</div>
              <button
                onClick={alert.onAction}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg active:scale-95 ${riskLightBg(alert.level)} ${riskText(alert.level)}`}
              >
                {alert.action} →
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── SCREEN 6: DISASTER / CYCLONE MODE ───────────────────────────────────────
function CycloneMode({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const [tab, setTab] = useState('Track Map')
  const tabs = ['Track Map', 'Affected Vessels', 'Forecast']

  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Alert banner */}
      <div className="bg-red-600 px-4 py-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-3xl">🌀</span>
            <div>
              <div className="text-white font-extrabold text-base">CYCLONE ALERT</div>
              <div className="text-red-100 text-xs">Cyclone affecting Maharashtra Coast</div>
            </div>
          </div>
          <div className="bg-white/20 px-2.5 py-1 rounded-full">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span className="text-white text-xs font-bold">ACTIVE</span>
            </div>
          </div>
        </div>
        {/* Cyclone info */}
        <div className="bg-red-700/50 rounded-xl p-2.5">
          <div className="grid grid-cols-4 gap-1 text-center text-white">
            {[['Wind', '110 km/h'], ['Dir', 'NW'], ['Move', '12 km/h'], ['ETA', '18 hrs']].map(([k, v]) => (
              <div key={k}>
                <div className="font-bold text-sm">{v}</div>
                <div className="text-[10px] text-red-200">{k}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div className="px-4 py-3">
        <div className="grid grid-cols-4 gap-2">
          {[
            { v: '17', l: 'Vessels Affected', c: 'bg-orange-50 text-orange-600' },
            { v: '02', l: 'Critical', c: 'bg-red-50 text-red-600' },
            { v: '06', l: 'High Risk', c: 'bg-orange-50 text-orange-600' },
            { v: '09', l: 'Monitoring', c: 'bg-yellow-50 text-yellow-700' },
          ].map(s => (
            <div key={s.l} className={`${s.c} rounded-xl p-2.5 text-center`}>
              <div className="font-extrabold text-xl">{s.v}</div>
              <div className="text-[9px] font-semibold leading-tight mt-0.5">{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-slate-100 px-4">
        <div className="flex gap-1">
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-3 py-3 text-sm font-semibold border-b-2 transition-colors ${tab === t ? 'border-red-600 text-red-600' : 'border-transparent text-slate-400'}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Map */}
      <div className="mx-4 mt-3 rounded-2xl overflow-hidden bg-white shadow-sm">
        <CoastalMap showCyclone />
        {/* Legend overlay */}
        <div className="bg-white px-4 py-2.5">
          <div className="flex flex-wrap gap-3">
            {[['bg-red-600', 'Cyclone Track'], ['bg-red-200', 'Impact Zone'], ['bg-orange-300', 'High Risk Zone'], ['bg-red-600', 'Affected Vessel']].map(([cls, label]) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className={`w-2.5 h-2.5 rounded-sm ${cls}`} />
                <span className="text-[10px] text-slate-600">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="px-4 py-3 flex gap-2">
        <button onClick={() => navigate('vessel-detail')} className="flex-1 bg-red-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95">
          CRITICAL VESSELS
        </button>
        <button onClick={() => navigate('routes')} className="flex-1 bg-blue-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95">
          PLAN RESPONSE
        </button>
      </div>
    </div>
  )
}

// ─── SCREEN 7: INCIDENT DETAILS ───────────────────────────────────────────────
function IncidentDetails({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      <div className="px-4 py-3 space-y-3">
        {/* Incident header */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-start justify-between mb-2">
            <div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Incident #024</div>
              <div className="font-bold text-slate-800 text-base mt-0.5">Vessel in hazardous sea state</div>
            </div>
            <RiskBadge level="critical" size="sm" />
          </div>
          <div className="text-[10px] font-semibold text-slate-400 mb-0.5">1 hour ago</div>
          <p className="text-slate-600 text-sm leading-relaxed">Vessel facing high waves and strong wind conditions.</p>
        </div>

        {/* Info grid */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">Incident Information</div>
          <div className="space-y-0">
            {[
              ['Location', '18.92° N, 72.85° E'],
              ['Vessel', 'IND-1042'],
              ['Severity', 'CRITICAL'],
              ['Cause', 'High waves + strong wind'],
              ['Last Known Position', '09:41 AM (28 Sep 2026)'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between py-2.5 border-b border-slate-50 last:border-0">
                <span className="text-slate-500 text-sm">{k}</span>
                <span className={`text-sm font-semibold ${k === 'Severity' ? 'text-red-600' : 'text-slate-800'}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Current situation */}
        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 shadow-sm">
          <div className="text-[11px] font-bold text-orange-700 uppercase tracking-widest mb-2">Current Situation</div>
          <p className="text-slate-700 text-sm leading-relaxed">
            Vessel reported heavy rolling and reduced visibility. Crew is safe but requires guidance for safe return.
          </p>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 pb-2">
          <button className="bg-green-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95 flex items-center justify-center gap-1.5">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" /></svg>
            CONTACT VESSEL
          </button>
          <button onClick={() => navigate('routes')} className="bg-blue-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95 flex items-center justify-center gap-1.5">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polygon points="3 11 22 2 13 21 11 13 3 11" /></svg>
            PLAN RESPONSE
          </button>
          <button className="bg-slate-100 text-slate-700 font-bold py-3.5 rounded-xl text-sm active:scale-95 flex items-center justify-center gap-1.5">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10" /><polyline points="12 8 12 12 14 14" /></svg>
            FIND SAFE ROUTE
          </button>
          <button onClick={() => navigate('sar')} className="bg-orange-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95 flex items-center justify-center gap-1.5">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" /></svg>
            START SAR ANALYSIS
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── SCREEN 8: SAR / DRIFT ANALYSIS ──────────────────────────────────────────
function SARDriftAnalysis({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      <div className="px-4 py-3 space-y-3">
        {/* Last known position */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1d4ed8" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="5" /><line x1="12" y1="2" x2="12" y2="7" /><line x1="12" y1="17" x2="12" y2="22" /><line x1="2" y1="12" x2="7" y2="12" /><line x1="17" y1="12" x2="22" y2="12" /></svg>
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Last Known Position</div>
              <div className="font-bold text-slate-800 text-sm font-mono">18.9176° N, 72.8545° E</div>
              <div className="text-[10px] text-slate-400">09:41 AM, 28 Sep 2026</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              ['Wind (at 10m)', '28 km/h', 'NE', '🌬'],
              ['Surface Current', '1.2 knots', 'NW', '🌊'],
              ['Wind Leeway', '1.5% of wind', '', '💨'],
            ].map(([k, v, d, icon]) => (
              <div key={k} className="bg-slate-50 rounded-xl p-2.5">
                <div className="text-lg mb-1">{icon}</div>
                <div className="font-bold text-slate-800 text-sm">{v}</div>
                {d && <div className="text-[10px] text-slate-400">{d}</div>}
                <div className="text-[10px] text-slate-400 font-medium mt-0.5">{k}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Drift results */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">Drift Analysis Results</div>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="bg-orange-50 rounded-xl p-3">
              <div className="text-[10px] font-semibold text-slate-400 uppercase mb-1">Net Drift Vector</div>
              <div className="font-extrabold text-orange-600 text-2xl">146.3°</div>
              <div className="text-[10px] text-slate-400">(SE direction)</div>
            </div>
            <div className="bg-blue-50 rounded-xl p-3">
              <div className="text-[10px] font-semibold text-slate-400 uppercase mb-1">Search Radius</div>
              <div className="font-extrabold text-blue-600 text-2xl">1.06 NM</div>
              <div className="text-[10px] text-slate-400">(1.96 km)</div>
            </div>
          </div>
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] font-bold text-orange-700 uppercase tracking-widest mb-0.5">Predicted Position</div>
                <div className="font-bold text-slate-800 text-sm font-mono">18.9052° N, 72.8731° E</div>
              </div>
              <div className="bg-orange-500 text-white px-2.5 py-1 rounded-lg font-bold text-sm">+3 HOURS</div>
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
          <CoastalMap showSAR />
          {/* Map legend */}
          <div className="px-4 py-2.5 bg-white">
            <div className="flex flex-wrap gap-3">
              {[['bg-red-600', 'Last Known Position'], ['bg-orange-500', 'Predicted Position'], ['border-2 border-orange-500', 'Search Area (1 NM)']].map(([cls, label]) => (
                <div key={label} className="flex items-center gap-1.5">
                  <div className={`w-3 h-3 rounded-full ${cls}`} />
                  <span className="text-[10px] text-slate-600">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pb-2">
          <button className="flex-1 bg-slate-100 text-slate-700 font-bold py-3.5 rounded-xl text-sm active:scale-95">
            SHOW SEARCH AREA
          </button>
          <button onClick={() => navigate('routes')} className="flex-1 bg-blue-600 text-white font-bold py-3.5 rounded-xl text-sm active:scale-95">
            GENERATE SAR PLAN
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── SCREEN 9: RESPONSE ROUTE PLANNER ────────────────────────────────────────
function ResponseRoutePlanner({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const [selected, setSelected] = useState<'A' | 'B' | 'C'>('B')

  const plans = [
    { id: 'A' as const, name: 'Fastest Response', eta: '18 min', dist: '24 km', risk: 'Moderate', color: 'border-orange-400 bg-orange-50', badgeBg: 'bg-orange-100 text-orange-700', riskColor: 'text-orange-600' },
    { id: 'B' as const, name: 'Safest Response', eta: '23 min', dist: '28 km', risk: 'Low', color: 'border-green-500 bg-green-50', badgeBg: 'bg-green-100 text-green-700', riskColor: 'text-green-600', recommended: true },
    { id: 'C' as const, name: 'Alternate Route', eta: '27 min', dist: '32 km', risk: 'Low', color: 'border-slate-300 bg-slate-50', badgeBg: 'bg-slate-100 text-slate-600', riskColor: 'text-slate-600' },
  ]

  return (
    <div className="flex-1 overflow-y-auto thin-scroll" style={{ background: '#EDF2F7' }}>
      {/* Context */}
      <div className="bg-white px-4 py-3 border-b border-slate-100">
        <div className="flex gap-4">
          <div>
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Vessel</div>
            <div className="font-bold text-slate-800 text-sm">IND-1042</div>
          </div>
          <div className="w-px bg-slate-100" />
          <div>
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Incident</div>
            <div className="font-bold text-slate-800 text-sm">#024</div>
          </div>
          <div className="w-px bg-slate-100" />
          <div>
            <div className="text-[10px] text-slate-400 font-semibold uppercase">Status</div>
            <div className="font-bold text-red-600 text-sm">CRITICAL</div>
          </div>
        </div>
      </div>

      <div className="px-4 py-3 space-y-3">
        {/* Route map */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
          <CoastalMap showRoutes />
          {/* Route legend */}
          <div className="px-4 py-2.5 bg-white">
            <div className="flex gap-4">
              {[['bg-red-500', 'Plan A'], ['bg-green-500', 'Plan B (Rec.)'], ['bg-slate-400', 'Plan C']].map(([cls, label]) => (
                <div key={label} className="flex items-center gap-1.5">
                  <div className={`w-6 h-1.5 rounded-full ${cls}`} />
                  <span className="text-[10px] text-slate-600">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Plan cards */}
        {plans.map(plan => (
          <button
            key={plan.id}
            onClick={() => setSelected(plan.id)}
            className={`w-full text-left border-2 rounded-2xl p-4 transition-all active:scale-98 shadow-sm ${selected === plan.id ? plan.color : 'bg-white border-slate-200'}`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-sm ${selected === plan.id ? (plan.id === 'B' ? 'bg-green-500 text-white' : plan.id === 'A' ? 'bg-orange-500 text-white' : 'bg-slate-400 text-white') : 'bg-slate-100 text-slate-600'}`}>
                  {plan.id}
                </div>
                <span className="font-bold text-slate-800 text-sm">Plan {plan.id}</span>
                {plan.recommended && (
                  <span className="bg-green-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">RECOMMENDED</span>
                )}
              </div>
              {selected === plan.id && (
                <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center">
                  <svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><polyline points="2 6 5 9 10 3" /></svg>
                </div>
              )}
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <div className="text-[10px] text-slate-400">ETA</div>
                <div className="font-bold text-slate-800 text-sm">{plan.eta}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400">Distance</div>
                <div className="font-bold text-slate-800 text-sm">{plan.dist}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400">Risk</div>
                <div className={`font-bold text-sm ${plan.riskColor}`}>{plan.risk}</div>
              </div>
            </div>
          </button>
        ))}

        {/* CTA */}
        <div className="flex gap-2 pb-2">
          <button
            onClick={() => setSelected(selected)}
            className="flex-1 bg-slate-100 text-slate-700 font-bold py-3.5 rounded-xl text-sm active:scale-95"
          >
            SELECT PLAN {selected}
          </button>
          <button
            className="flex-1 font-bold py-3.5 rounded-xl text-sm active:scale-95 text-white"
            style={{ background: 'linear-gradient(135deg, #1E6FD9, #0EA5E9)' }}
          >
            START RESPONSE
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── SCREEN 10: ORCA AI ───────────────────────────────────────────────────────
function ORCAAi({ lang, setLang, navigate }: {
  lang: Lang; setLang: (l: Lang) => void; navigate: (s: Screen) => void
}) {
  const [voiceState, setVoiceState] = useState<'idle' | 'listening' | 'processing' | 'response'>('idle')
  const [query, setQuery] = useState('')
  const [showResponse, setShowResponse] = useState(false)

  const suggestions = [
    { text: 'Which vessels are at highest risk?', action: () => navigate('vessel-detail') },
    { text: 'Show cyclone affected areas', action: () => navigate('cyclone') },
    { text: 'Find nearest safe harbour', action: () => navigate('map') },
    { text: 'Calculate drift for this vessel', action: () => navigate('sar') },
    { text: "Summarize today's alerts", action: () => navigate('alerts') },
  ]

  const handleVoice = () => {
    if (voiceState === 'idle') {
      setVoiceState('listening')
      setTimeout(() => {
        setVoiceState('processing')
        setTimeout(() => {
          setVoiceState('response')
          setShowResponse(true)
        }, 2000)
      }, 2500)
    } else {
      setVoiceState('idle')
      setShowResponse(false)
    }
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden" style={{ background: '#EDF2F7' }}>
      <div className="flex-1 overflow-y-auto thin-scroll px-4 py-3 space-y-3">
        {/* Greeting */}
        <div className="flex gap-3">
          <div className="w-9 h-9 rounded-full bg-cyan-500 flex items-center justify-center shrink-0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="3" /><circle cx="12" cy="12" r="9" />
              <line x1="12" y1="3" x2="12" y2="9" /><line x1="12" y1="15" x2="12" y2="21" />
              <line x1="3" y1="12" x2="9" y2="12" /><line x1="15" y1="12" x2="21" y2="12" />
            </svg>
          </div>
          <div className="bg-white rounded-2xl rounded-tl-sm p-4 shadow-sm flex-1">
            <div className="font-bold text-slate-800 text-sm mb-1">Good morning, Officer!</div>
            <p className="text-slate-600 text-sm leading-relaxed">
              I can help with vessel monitoring, cyclone analysis, SAR planning and operational decisions.
            </p>
          </div>
        </div>

        {/* Suggestions */}
        <div>
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Try asking:</div>
          <div className="flex flex-col gap-2">
            {suggestions.map((s, i) => (
              <button
                key={i}
                onClick={s.action}
                className="text-left bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-blue-600 font-medium active:scale-98 hover:border-blue-300 transition-colors shadow-sm"
              >
                {s.text}
              </button>
            ))}
          </div>
        </div>

        {/* AI Response card */}
        {showResponse && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-green-200">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-full bg-cyan-500 flex items-center justify-center">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">ORCA Analysis</span>
            </div>
            {[
              ['Decision', 'IND-1042 requires immediate attention. Recommend response initiation.'],
              ['Evidence', 'Wave height 3.2m exceeds vessel threshold. Cyclone track influence confirmed.'],
              ['Confidence', '91% — High'],
              ['Recommended Action', 'Dispatch nearest coast guard vessel via Plan B route.'],
            ].map(([k, v]) => (
              <div key={k} className="py-2 border-b border-slate-50 last:border-0">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">{k}</div>
                <div className={`text-sm ${k === 'Confidence' ? 'text-green-600 font-bold' : 'text-slate-700'} leading-snug`}>{v}</div>
              </div>
            ))}
            <button onClick={() => navigate('routes')} className="mt-3 w-full bg-blue-600 text-white font-bold py-2.5 rounded-xl text-sm active:scale-95">
              VIEW RESPONSE PLAN
            </button>
          </div>
        )}
      </div>

      {/* Voice button */}
      <div className="px-4 pt-3 pb-2 bg-white border-t border-slate-100">
        <div className="flex justify-center mb-3">
          <button
            onClick={handleVoice}
            className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all ${voiceState === 'idle' ? 'bg-blue-600' : voiceState === 'listening' ? 'bg-red-500' : voiceState === 'processing' ? 'bg-orange-500' : 'bg-green-500'}`}
          >
            {voiceState === 'idle' && (
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
                <path d="M12 2a3 3 0 013 3v7a3 3 0 11-6 0V5a3 3 0 013-3z" />
                <path d="M19 10v2a7 7 0 01-14 0v-2M12 19v3M8 22h8" />
              </svg>
            )}
            {voiceState === 'listening' && (
              <div className="flex gap-0.5 items-end">
                {[3, 5, 4, 6, 3, 5, 4].map((h, i) => (
                  <div key={i} className="bg-white rounded-full animate-pulse" style={{ width: 3, height: h * 3, animationDelay: `${i * 0.1}s` }} />
                ))}
              </div>
            )}
            {voiceState === 'processing' && (
              <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
            )}
            {voiceState === 'response' && (
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            )}
          </button>
        </div>
        <div className="text-center text-[11px] font-semibold text-slate-400 mb-3">
          {voiceState === 'idle' ? 'Tap to speak' : voiceState === 'listening' ? 'Listening...' : voiceState === 'processing' ? 'ORCA is analyzing...' : 'Response ready'}
        </div>
        {/* Waveform for listening */}
        {voiceState === 'listening' && (
          <div className="flex justify-center gap-0.5 items-center h-6 mb-2">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="bg-blue-400 rounded-full animate-pulse" style={{ width: 2, height: Math.random() * 16 + 4, animationDelay: `${i * 0.05}s` }} />
            ))}
          </div>
        )}
        {/* Text input */}
        <div className="flex items-center gap-2 bg-slate-100 rounded-xl px-3 py-2">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2"><circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" /></svg>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Type your question..."
            className="flex-1 bg-transparent text-sm text-slate-700 placeholder-slate-400 outline-none"
          />
          {query && (
            <button className="text-blue-600">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App() {
  const [lang, setLang] = useState<Lang>('mr')
  const [navTab, setNavTab] = useState<NavTab>('command')
  const [screen, setScreen] = useState<Screen>('command')

  const navigate = (s: Screen) => {
    setScreen(s)
    const tabMap: Partial<Record<Screen, NavTab>> = {
      command: 'command', map: 'map', vessels: 'vessels', alerts: 'alerts', ai: 'ai',
    }
    if (tabMap[s]) setNavTab(tabMap[s]!)
  }

  const handleNavSelect = (t: NavTab) => {
    setNavTab(t)
    setScreen(t)
  }

  const getBackTarget = (): Screen | undefined => {
    const backMap: Partial<Record<Screen, Screen>> = {
      'vessel-detail': 'vessels',
      'vessel-risk': 'vessel-detail',
      'cyclone': 'command',
      'incident': 'alerts',
      'sar': 'incident',
      'routes': 'sar',
    }
    return backMap[screen]
  }

  // Title for sub-screens
  const titles: Partial<Record<Screen, string>> = {
    'map': 'Live Marine Map',
    'vessel-detail': 'Vessel IND-1042',
    'vessel-risk': 'Why is this vessel at risk?',
    'cyclone': 'Cyclone Response',
    'incident': 'Incident #024',
    'sar': 'SAR / Drift Analysis',
    'routes': 'Response Options',
    'ai': 'ORCA AI',
  }

  const isSubScreen = !['command', 'vessels', 'alerts'].includes(screen)
  const backTarget = getBackTarget()

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#111827' }}>
      {/* Mobile frame */}
      <div className="relative flex flex-col overflow-hidden rounded-[2.5rem] shadow-2xl border border-slate-700"
        style={{ width: 390, height: 844, background: '#EDF2F7' }}>
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-7 rounded-b-2xl z-50"
          style={{ background: '#0B1A2E' }} />

        <StatusBar />

        <AppHeader
          lang={lang}
          setLang={setLang}
          title={titles[screen]}
          onBack={backTarget ? () => navigate(backTarget) : undefined}
          showNotif={screen === 'command'}
        />

        {/* Screen content */}
        {screen === 'command' && <CommandCenter lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'map' && <LiveMarineMap lang={lang} setLang={setLang} navigate={navigate} />}
        {(screen === 'vessels') && <VesselsList lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'vessel-detail' && <VesselDetails lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'vessel-risk' && <VesselRiskAssessment lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'alerts' && <AlertsScreen lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'cyclone' && <CycloneMode lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'incident' && <IncidentDetails lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'sar' && <SARDriftAnalysis lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'routes' && <ResponseRoutePlanner lang={lang} setLang={setLang} navigate={navigate} />}
        {screen === 'ai' && <ORCAAi lang={lang} setLang={setLang} navigate={navigate} />}

        <BottomNav active={navTab} onSelect={handleNavSelect} />
      </div>

      {/* Screen label */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-slate-500 text-xs font-mono">
        {screen.toUpperCase()} — ORCA Coastal Guard
      </div>
    </div>
  )
}
