import { FormEvent, ReactNode, useEffect, useRef, useState } from "react";
import fishingSunset from "./assets/fishing-sunset.jpg";
import coralReef from "./assets/coral-reef.jpg";

type Language = "en" | "hi" | "mr";
type Role = "fisherman" | "guard" | "researcher";

const copy = {
  en: {
    language: "English",
    subtitle: "Oceanic Resource & Coastal Advisory Assistant",
    tagline: "Safer Seas • Smarter Decisions",
    chooseRole: "Choose how you’ll use ORCA",
    roles: {
      fisherman: ["Fisherman", "Plan trips, receive alerts, and find better fishing opportunities"],
      guard: ["Coastal Guards", "Monitor vessels, ensure safety, and respond to incidents"],
      researcher: ["Marine Researchers", "Access data, analyze trends, and support marine research"],
    },
    benefits: ["Safer Operations", "Smarter Insights", "Healthier Oceans"],
    login: "Login",
    welcome: "Welcome back! Please enter your credentials.",
    change: "Change",
    username: "Username",
    password: "Password",
    remember: "Remember me",
    forgot: "Forgot password?",
    or: "OR",
    google: "Continue with Google",
    secure: "Secure • Reliable • For Safer Seas",
    back: "Back",
    showPassword: "Show password",
  },
  hi: {
    language: "हिंदी",
    subtitle: "समुद्री संसाधन और तटीय सलाह सहायक",
    tagline: "सुरक्षित समुद्र • बेहतर निर्णय",
    chooseRole: "ORCA में अपनी भूमिका चुनें",
    roles: {
      fisherman: ["मछुआरा", "यात्रा की योजना बनाएं, अलर्ट पाएं और बेहतर मछली क्षेत्र खोजें"],
      guard: ["तटरक्षक", "जहाज़ों की निगरानी, सुरक्षा और घटनाओं पर त्वरित कार्रवाई करें"],
      researcher: ["समुद्री शोधकर्ता", "डेटा देखें, रुझानों का विश्लेषण करें और शोध को आगे बढ़ाएं"],
    },
    benefits: ["सुरक्षित संचालन", "बेहतर जानकारी", "स्वस्थ महासागर"],
    login: "लॉग इन",
    welcome: "वापसी पर स्वागत है! कृपया अपनी जानकारी दर्ज करें।",
    change: "बदलें",
    username: "उपयोगकर्ता नाम",
    password: "पासवर्ड",
    remember: "मुझे याद रखें",
    forgot: "पासवर्ड भूल गए?",
    or: "या",
    google: "Google के साथ जारी रखें",
    secure: "सुरक्षित • विश्वसनीय • सुरक्षित समुद्र के लिए",
    back: "वापस",
    showPassword: "पासवर्ड दिखाएं",
  },
  mr: {
    language: "मराठी",
    subtitle: "सागरी संसाधन आणि किनारी सल्ला सहाय्यक",
    tagline: "सुरक्षित समुद्र • सुजाण निर्णय",
    chooseRole: "ORCA मधील तुमची भूमिका निवडा",
    roles: {
      fisherman: ["मच्छीमार", "सहलींचे नियोजन करा, सूचना मिळवा आणि उत्तम मासेमारी क्षेत्रे शोधा"],
      guard: ["तटरक्षक", "जहाजांवर लक्ष ठेवा, सुरक्षितता राखा आणि घटनांना प्रतिसाद द्या"],
      researcher: ["सागरी संशोधक", "डेटा मिळवा, कलांचे विश्लेषण करा आणि संशोधनास मदत करा"],
    },
    benefits: ["सुरक्षित कार्य", "सुजाण माहिती", "निरोगी महासागर"],
    login: "लॉग इन",
    welcome: "पुन्हा स्वागत! कृपया तुमची माहिती भरा.",
    change: "बदला",
    username: "वापरकर्ता नाव",
    password: "पासवर्ड",
    remember: "मला लक्षात ठेवा",
    forgot: "पासवर्ड विसरलात?",
    or: "किंवा",
    google: "Google सह पुढे जा",
    secure: "सुरक्षित • विश्वासार्ह • सुरक्षित समुद्रासाठी",
    back: "मागे",
    showPassword: "पासवर्ड दाखवा",
  },
} as const;

const languageOptions: { id: Language; label: string }[] = [
  { id: "en", label: "English" },
  { id: "hi", label: "हिंदी" },
  { id: "mr", label: "मराठी" },
];

const paths: Record<string, ReactNode> = {
  globe: <><circle cx="12" cy="12" r="9" /><path d="M3.5 9h17M3.5 15h17M12 3c2.2 2.5 3.2 5.5 3.2 9S14.2 18.5 12 21c-2.2-2.5-3.2-5.5-3.2-9S9.8 5.5 12 3Z" /></>,
  chevron: <path d="m7 9 5 5 5-5" />,
  arrow: <path d="m9 18 6-6-6-6" />,
  back: <path d="m15 18-6-6 6-6" />,
  user: <><circle cx="12" cy="8" r="3.5" /><path d="M5.5 20c.4-4.1 2.5-6 6.5-6s6.1 1.9 6.5 6" /></>,
  lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14.5v3" /></>,
  eye: <><path d="M2.5 12s3.4-5 9.5-5 9.5 5 9.5 5-3.4 5-9.5 5-9.5-5-9.5-5Z" /><circle cx="12" cy="12" r="2.5" /></>,
  shield: <><path d="M12 2.5 20 6v5.5c0 5-3.3 8.3-8 10-4.7-1.7-8-5-8-10V6l8-3.5Z" /><path d="m8.5 12 2.2 2.2 4.8-5" /></>,
  anchor: <><circle cx="12" cy="5" r="2" /><path d="M12 7v13M5 10h14M4 15c1.2 3.3 3.7 5 8 5s6.8-1.7 8-5M4 15l-1 3M20 15l1 3" /></>,
  research: <><path d="m10 3 4 1-1 4-4-1 1-4ZM11 8l-2.8 5.2M8 12c-3.5 1.1-4.7 4.3-3.6 7h12.8M13.5 10.5c3.2 1.8 4 5.4 2.2 8.5M3 21h17" /></>,
  fish: <><path d="M4 8c3-3 8-3.6 12.5-.5L21 4v9l-4.5-3.5C12 12.6 7 12 4 9.5L1.5 12V6L4 8Z" /><circle cx="16" cy="7" r=".7" fill="currentColor" /></>,
  chart: <><path d="M5 21V11M12 21V5M19 21V8" /></>,
  people: <><circle cx="9" cy="8" r="3" /><circle cx="17" cy="9" r="2.5" /><path d="M2.5 20c.3-4.2 2.5-6 6.5-6s6.2 1.8 6.5 6M15 14c3.8 0 5.7 1.7 6 5" /></>,
};

function Icon({ name, size = 24 }: { name: string; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function OrcaLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "brand--compact" : ""}`}>
      <svg className="orca-mark" viewBox="0 0 128 92" aria-label="ORCA ocean logo">
        <defs><linearGradient id="orcaBlue" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#43d5ff" /><stop offset="1" stopColor="#1688e7" /></linearGradient></defs>
        <path d="M18 55C20 24 39 7 66 8c20 1 36 12 44 31-13-17-28-22-44-20-22 2-36 16-40 38Z" fill="none" stroke="url(#orcaBlue)" strokeWidth="6" />
        <path d="M20 60c14-7 28-6 42 1-18-2-31 3-40 13 5-3 11-4 18-4 9-20 30-31 53-25 10 3 18 8 25 14-13-4-20-2-27 5-11 11-20 17-35 14-9-2-16-7-21-12l-15 3 9-9-9 0Z" fill="#f7fbff" />
        <path d="M40 70c15-17 31-24 51-23-15 3-25 10-31 21-3 6-7 10-12 12-4-3-6-6-8-10Z" fill="#07111f" />
        <path d="M88 47c8 1 14 4 20 8-8-1-13 1-18 5-4-1-7-3-9-5 2-4 4-6 7-8Z" fill="#07111f" />
        <ellipse cx="99" cy="51" rx="3.5" ry="2.5" fill="#f7fbff" />
        <path d="M21 79c15-5 29-4 42 4-18-3-31 0-42 7 5-5 10-8 14-9-6-1-10-1-14-2Z" fill="url(#orcaBlue)" />
      </svg>
      <div className="brand-title">ORCA</div>
    </div>
  );
}

function LanguageMenu({ language, onChange }: { language: Language; onChange: (value: Language) => void }) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const close = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    window.addEventListener("pointerdown", close);
    return () => window.removeEventListener("pointerdown", close);
  }, []);
  return (
    <div className="language" ref={root}>
      <button className={`language-trigger ${open ? "is-open" : ""}`} type="button" aria-expanded={open} onClick={() => setOpen(!open)}>
        <Icon name="globe" size={20} />
        <span>{copy[language].language}</span>
        <span className={open ? "chevron-up" : ""}><Icon name="chevron" size={17} /></span>
      </button>
      {open && (
        <div className="language-popover" role="menu">
          {languageOptions.map((option) => (
            <button key={option.id} type="button" role="menuitem" className={language === option.id ? "active" : ""} onClick={() => { onChange(option.id); setOpen(false); }}>
              <span>{option.label}</span><span>{language === option.id ? "✓" : ""}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function RoleSymbol({ role }: { role: Role }) {
  return <div className="role-symbol"><Icon name={role === "fisherman" ? "fish" : role === "guard" ? "anchor" : "research"} size={34} /></div>;
}

function RoleScreen({ language, setLanguage, onChoose }: { language: Language; setLanguage: (l: Language) => void; onChoose: (r: Role) => void }) {
  const t = copy[language];
  const roles: Role[] = ["fisherman", "guard", "researcher"];
  const [pressed, setPressed] = useState<Role>("fisherman");
  return (
    <main className="phone role-screen" style={{ "--photo": `url(${fishingSunset})` } as React.CSSProperties}>
      <div className="scrim" />
      <div className="topbar"><div /><LanguageMenu language={language} onChange={setLanguage} /></div>
      <div className="role-content">
        <div className="role-brand"><OrcaLogo /><div className="subtitle">{t.subtitle}</div><div className="tagline">{t.tagline}</div></div>
        <section className="role-list" aria-label={t.chooseRole}>
          {roles.map((role) => (
            <button
              type="button"
              key={role}
              className={`role-card ${pressed === role ? "selected" : ""}`}
              onPointerDown={() => setPressed(role)}
              onClick={() => onChoose(role)}
            >
              <RoleSymbol role={role} />
              <span className="role-copy"><strong>{t.roles[role][0]}</strong><small>{t.roles[role][1]}</small></span>
              <span className="round-arrow"><Icon name="arrow" size={23} /></span>
            </button>
          ))}
        </section>
      </div>
      <div className="wave-lines" aria-hidden="true"><i /><i /><i /></div>
      <footer className="benefits">
        {t.benefits.map((item, i) => <div key={item}><Icon name={["shield", "chart", "people"][i]} size={25} /><span>{item}</span></div>)}
      </footer>
    </main>
  );
}

function GoogleIcon() {
  return <span className="google" aria-hidden="true">G</span>;
}

function LoginScreen({ language, setLanguage, role, onBack }: { language: Language; setLanguage: (l: Language) => void; role: Role; onBack: () => void }) {
  const t = copy[language];
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const submit = (event: FormEvent) => event.preventDefault();
  return (
    <main className="phone login-screen" style={{ "--photo": `url(${coralReef})` } as React.CSSProperties}>
      <div className="login-overlay" />
      <div className="topbar">
        <button type="button" className="back-button" aria-label={t.back} onClick={onBack}><Icon name="back" size={28} /></button>
        <LanguageMenu language={language} onChange={setLanguage} />
      </div>
      <div className="login-content">
        <div className="login-brand"><OrcaLogo compact /><div className="subtitle">{t.subtitle}</div></div>
        <form className="login-card" onSubmit={submit}>
          <div className="login-heading">{t.login}</div>
          <div className="login-subheading">{t.welcome}</div>
          <div className="role-indicator">
            <RoleSymbol role={role} />
            <strong>{t.roles[role][0]}</strong>
            <button type="button" onClick={onBack}>{t.change}</button>
          </div>
          <label className="field">
            <Icon name="user" size={23} />
            <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder={t.username} autoComplete="username" />
          </label>
          <label className="field">
            <Icon name="lock" size={23} />
            <input type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder={t.password} autoComplete="current-password" />
            <button type="button" className="eye-button" aria-label={t.showPassword} onClick={() => setShowPassword(!showPassword)}><Icon name="eye" size={24} /></button>
          </label>
          <div className="login-options">
            <label className="check-label"><input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} /><span className="checkbox">{remember ? "✓" : ""}</span><span>{t.remember}</span></label>
            <button type="button" className="link-button">{t.forgot}</button>
          </div>
          <button className="primary-button" type="submit" disabled={!username || !password}><span>{t.login}</span><Icon name="arrow" size={22} /></button>
          <div className="divider"><span>{t.or}</span></div>
          <button className="google-button" type="button"><GoogleIcon />{t.google}</button>
        </form>
        <div className="security-pill"><Icon name="shield" size={18} />{t.secure}</div>
      </div>
    </main>
  );
}

export default function App() {
  const [language, setLanguage] = useState<Language>("en");
  const [role, setRole] = useState<Role | null>(null);
  return (
    <div className="app-shell">
      {role ? <LoginScreen language={language} setLanguage={setLanguage} role={role} onBack={() => setRole(null)} /> : <RoleScreen language={language} setLanguage={setLanguage} onChoose={setRole} />}
    </div>
  );
}
