import { useState } from 'react'
import { S01Dashboard } from './screens/S01Dashboard'
import { S02DataExplorer } from './screens/S02DataExplorer'
import { S03ParameterAnalysis } from './screens/S03ParameterAnalysis'
import { S04TimeSeries } from './screens/S04TimeSeries'
import { S05SpeciesZones } from './screens/S05SpeciesZones'
import { S06EnvInsights } from './screens/S06EnvInsights'
import { S07Forecast } from './screens/S07Forecast'
import { S08DataDownload } from './screens/S08DataDownload'
import { S09Workspace } from './screens/S09Workspace'
import { S10Comparison } from './screens/S10Comparison'
import { S11OrcaAI } from './screens/S11OrcaAI'
import { S12Profile } from './screens/S12Profile'

type Screen =
  | 'home' | 'map' | 'analysis' | 'timeseries' | 'species'
  | 'insights' | 'forecast' | 'download' | 'workspace'
  | 'comparison' | 'ai' | 'profile' | 'data'

function navToScreen(nav: string, history: Screen[]): Screen {
  switch (nav) {
    case 'home': return 'home'
    case 'map': return 'map'
    case 'data': return 'workspace'
    case 'insights': return 'insights'
    case 'ai': return 'ai'
    // secondary screens
    case 'analysis': return 'analysis'
    case 'timeseries': return 'timeseries'
    case 'species': return 'species'
    case 'forecast': return 'forecast'
    case 'download': return 'download'
    case 'workspace': return 'workspace'
    case 'comparison': return 'comparison'
    case 'profile': return 'profile'
    default: return history[history.length - 1] || 'home'
  }
}

export default function App() {
  const [lang, setLang] = useState('मराठी')
  const [screen, setScreen] = useState<Screen>('home')
  const [history, setHistory] = useState<Screen[]>(['home'])

  function navigate(nav: string) {
    const next = navToScreen(nav, history)
    setScreen(next)
    setHistory(prev => [...prev.slice(-10), next])
  }

  const props = { lang, onLangChange: setLang, onNav: navigate }

  const screens: Record<Screen, React.ReactNode> = {
    home: <S01Dashboard {...props} />,
    map: <S02DataExplorer {...props} />,
    analysis: <S03ParameterAnalysis {...props} />,
    timeseries: <S04TimeSeries {...props} />,
    species: <S05SpeciesZones {...props} />,
    insights: <S06EnvInsights {...props} />,
    forecast: <S07Forecast {...props} />,
    download: <S08DataDownload {...props} />,
    workspace: <S09Workspace {...props} />,
    data: <S09Workspace {...props} />,
    comparison: <S10Comparison {...props} />,
    ai: <S11OrcaAI {...props} />,
    profile: <S12Profile {...props} />
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100dvh', background: '#060E1C', padding: '0' }}>
      {/* Phone shell on desktop, full screen on mobile */}
      <div className="phone-frame" style={{ boxShadow: '0 25px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.06)' }}>
        {/* Screen navigator dots */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 }}>
          {screens[screen]}
        </div>
      </div>

      {/* Desktop sidebar navigator */}
      <div className="hidden md:flex flex-col gap-1 ml-4" style={{ opacity: 0.85 }}>
        {[
          { id: 'home', label: '01 Dashboard' },
          { id: 'map', label: '02 Data Explorer' },
          { id: 'analysis', label: '03 Parameter Analysis' },
          { id: 'timeseries', label: '04 Time Series' },
          { id: 'species', label: '05 Species & Zones' },
          { id: 'insights', label: '06 Env Insights' },
          { id: 'forecast', label: '07 Forecast' },
          { id: 'download', label: '08 Data Download' },
          { id: 'workspace', label: '09 Workspace' },
          { id: 'comparison', label: '10 Comparison' },
          { id: 'ai', label: '11 ORCA AI' },
          { id: 'profile', label: '12 Profile' }
        ].map(item => (
          <button
            key={item.id}
            onClick={() => navigate(item.id)}
            className="text-left rounded-lg px-3 py-2 font-medium transition-all"
            style={{
              fontSize: 11,
              color: screen === item.id ? '#00BDEA' : 'rgba(255,255,255,0.5)',
              background: screen === item.id ? 'rgba(0,189,234,0.12)' : 'transparent',
              borderLeft: screen === item.id ? '2px solid #00BDEA' : '2px solid transparent',
              whiteSpace: 'nowrap'
            }}
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  )
}
