import { useState } from 'react'
import { StatusBar, BottomNav, Card } from '../components/shared'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const compData = [
  { month: 'Jul', mumbai: 1.4, goa: 1.2, laks: 2.1 },
  { month: 'Aug', mumbai: 1.8, goa: 1.3, laks: 2.6 },
  { month: 'Sep', mumbai: 1.2, goa: 1.1, laks: 2.3 }
]

const REGIONS = [
  { name: 'Mumbai Coast', color: '#1565C0' },
  { name: 'Goa Coast', color: '#4CAF50' },
  { name: 'Lakshadweep', color: '#F97316' }
]

const PARAMS = ['Chlorophyll-a', 'SST', 'Sea Level', 'Wave Height']
const TIME_RANGES = ['Last Month', 'Last 3 Months', 'Last 6 Months', 'Last Year']

export function S10Comparison({ lang, onLangChange, onNav }: Props) {
  const [tab, setTab] = useState<'Region Comparison' | 'Parameter Comparison'>('Region Comparison')
  const [selectedRegions, setSelectedRegions] = useState(['Mumbai Coast', 'Goa Coast', 'Lakshadweep'])
  const [param, setParam] = useState('Chlorophyll-a')
  const [paramOpen, setParamOpen] = useState(false)
  const [timeRange, setTimeRange] = useState('Last 3 Months')
  const [timeOpen, setTimeOpen] = useState(false)

  function toggleRegion(name: string) {
    setSelectedRegions(prev =>
      prev.includes(name) ? prev.filter(r => r !== name) : [...prev, name]
    )
  }

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="px-4 pt-3 pb-3">
          <div className="font-bold text-white" style={{ fontSize: 15 }}>Comparison & Analysis</div>
          <div style={{ fontSize: 10, color: '#93C5FD' }}>Compare regions, parameters or time periods</div>
        </div>
        <div className="flex mx-4 mb-3 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.15)' }}>
          {(['Region Comparison', 'Parameter Comparison'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2.5 font-medium"
              style={{ background: tab === t ? '#1565C0' : 'rgba(255,255,255,0.08)', color: tab === t ? '#fff' : '#93C5FD', fontSize: 11 }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20 px-4 pt-4 flex flex-col gap-3">

        {/* Region selector */}
        <Card>
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Select Regions</div>
          <div className="flex flex-wrap gap-2">
            {REGIONS.map(r => (
              <button
                key={r.name}
                onClick={() => toggleRegion(r.name)}
                className="rounded-full px-3 py-1.5 flex items-center gap-1.5 font-medium"
                style={{
                  background: selectedRegions.includes(r.name) ? r.color : '#F1F5F9',
                  color: selectedRegions.includes(r.name) ? '#fff' : '#64748B',
                  fontSize: 11,
                  border: selectedRegions.includes(r.name) ? 'none' : '1px solid #E2E8F0'
                }}
              >
                {selectedRegions.includes(r.name) && <span>✓</span>}
                {r.name}
              </button>
            ))}
            <button
              className="rounded-full px-3 py-1.5 font-medium flex items-center gap-1"
              style={{ background: '#EEF2FF', color: '#4338CA', fontSize: 11, border: '1px dashed #C7D2FE' }}
            >
              + Add Region
            </button>
          </div>
        </Card>

        {/* Parameter & Time Range */}
        <div className="flex gap-2 relative">
          <div className="flex-1 relative">
            <div className="font-medium mb-1" style={{ fontSize: 11, color: '#64748B' }}>Parameter</div>
            <button
              onClick={() => setParamOpen(!paramOpen)}
              className="w-full flex items-center justify-between rounded-xl px-3 py-2.5 bg-white"
              style={{ border: '1px solid #E2E8F0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}
            >
              <span style={{ fontSize: 12, color: '#0F172A' }}>{param}</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#94A3B8"><path d="M7 10l5 5 5-5z" /></svg>
            </button>
            {paramOpen && (
              <div className="absolute left-0 right-0 top-16 rounded-xl z-50 shadow-xl overflow-hidden" style={{ background: '#fff', border: '1px solid #E2E8F0' }}>
                {PARAMS.map(p => (
                  <button key={p} onClick={() => { setParam(p); setParamOpen(false) }}
                    className="w-full px-3 py-2.5 text-left"
                    style={{ fontSize: 12, color: p === param ? '#1565C0' : '#0F172A', background: p === param ? '#EEF2FF' : '#fff', borderBottom: '1px solid #F1F5F9' }}
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex-1 relative">
            <div className="font-medium mb-1" style={{ fontSize: 11, color: '#64748B' }}>Time Range</div>
            <button
              onClick={() => setTimeOpen(!timeOpen)}
              className="w-full flex items-center justify-between rounded-xl px-3 py-2.5 bg-white"
              style={{ border: '1px solid #E2E8F0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}
            >
              <span style={{ fontSize: 11, color: '#0F172A' }}>{timeRange}</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#94A3B8"><path d="M7 10l5 5 5-5z" /></svg>
            </button>
            {timeOpen && (
              <div className="absolute left-0 right-0 top-16 rounded-xl z-50 shadow-xl overflow-hidden" style={{ background: '#fff', border: '1px solid #E2E8F0' }}>
                {TIME_RANGES.map(t => (
                  <button key={t} onClick={() => { setTimeRange(t); setTimeOpen(false) }}
                    className="w-full px-3 py-2.5 text-left"
                    style={{ fontSize: 12, color: t === timeRange ? '#1565C0' : '#0F172A', background: t === timeRange ? '#EEF2FF' : '#fff', borderBottom: '1px solid #F1F5F9' }}
                  >
                    {t}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Comparison chart */}
        <Card>
          <div className="font-semibold mb-1" style={{ fontSize: 13, color: '#0F172A' }}>{param} Comparison</div>
          <div className="flex items-center gap-3 mb-3">
            {REGIONS.map(r => (
              <div key={r.name} className="flex items-center gap-1">
                <div className="rounded-full" style={{ width: 8, height: 8, background: r.color }} />
                <span style={{ fontSize: 9, color: '#64748B' }}>{r.name.split(' ')[0]}</span>
              </div>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={compData} margin={{ top: 5, right: 5, left: -22, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#94A3B8' }} />
              <YAxis domain={[0, 3]} tick={{ fontSize: 9, fill: '#94A3B8' }} />
              <Tooltip
                contentStyle={{ fontSize: 11, borderRadius: 8 }}
                formatter={(v: number, name: string) => [`${v} mg/m³`, name]}
              />
              {selectedRegions.includes('Mumbai Coast') && <Line type="monotone" dataKey="mumbai" stroke="#1565C0" strokeWidth={2.5} dot={{ r: 4 }} name="Mumbai Coast" />}
              {selectedRegions.includes('Goa Coast') && <Line type="monotone" dataKey="goa" stroke="#4CAF50" strokeWidth={2.5} dot={{ r: 4 }} name="Goa Coast" />}
              {selectedRegions.includes('Lakshadweep') && <Line type="monotone" dataKey="laks" stroke="#F97316" strokeWidth={2.5} dot={{ r: 4 }} name="Lakshadweep" />}
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Current values */}
        <div className="grid grid-cols-3 gap-2">
          {REGIONS.map(r => {
            const val = r.name.includes('Mumbai') ? '1.2' : r.name.includes('Goa') ? '1.1' : '2.3'
            return (
              <div key={r.name} className="rounded-xl p-2.5 bg-white text-center" style={{ border: `1px solid ${r.color}30` }}>
                <div style={{ fontSize: 16, fontWeight: 700, color: r.color, fontFamily: 'JetBrains Mono' }}>{val}</div>
                <div style={{ fontSize: 8.5, color: '#94A3B8', marginTop: 1 }}>mg/m³</div>
                <div style={{ fontSize: 9, color: '#475569', marginTop: 2, lineHeight: 1.2 }}>{r.name.split(' ')[0]}</div>
              </div>
            )
          })}
        </div>

        {/* Summary */}
        <Card>
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Summary</div>
          <div className="flex flex-col gap-2">
            {[
              { text: 'Lakshadweep shows higher productivity in this period.', icon: '●', color: '#F97316' },
              { text: 'Mumbai shows moderate seasonal variation.', icon: '●', color: '#1565C0' },
              { text: 'Goa coast shows a relatively stable trend.', icon: '●', color: '#4CAF50' }
            ].map((s, i) => (
              <div key={i} className="flex items-start gap-2">
                <span style={{ color: s.color, fontSize: 10, marginTop: 2, flexShrink: 0 }}>{s.icon}</span>
                <span style={{ fontSize: 12, color: '#475569', lineHeight: 1.4 }}>{s.text}</span>
              </div>
            ))}
          </div>
          <div className="mt-2 pt-2 border-t" style={{ borderColor: '#F1F5F9' }}>
            <span style={{ fontSize: 9, color: '#94A3B8' }}>
              Summary based on measured data. Causal interpretation requires domain expertise.
            </span>
          </div>
        </Card>
      </div>

      <BottomNav active="insights" onNav={onNav} />
    </div>
  )
}
