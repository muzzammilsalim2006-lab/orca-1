import { useState } from 'react'
import { StatusBar, BottomNav, Card, OceanMapSVG } from '../components/shared'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const sstData = [
  { date: '1 Sep', mumbai: 29.1, offshore: 27.8, pfz: 27.0 },
  { date: '7 Sep', mumbai: 29.5, offshore: 28.1, pfz: 27.3 },
  { date: '14 Sep', mumbai: 30.2, offshore: 28.7, pfz: 27.8 },
  { date: '21 Sep', mumbai: 29.8, offshore: 28.2, pfz: 27.5 },
  { date: '28 Sep', mumbai: 28.4, offshore: 27.6, pfz: 26.8 }
]

const RANGES = ['7D', '30D', '3M', '1Y', '5Y']

export function S03ParameterAnalysis({ lang, onLangChange, onNav }: Props) {
  const [view, setView] = useState<'Map' | 'Chart'>('Chart')
  const [range, setRange] = useState('30D')

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        {/* Title bar */}
        <div className="flex items-center justify-between px-4 py-3">
          <div>
            <div className="font-bold text-white" style={{ fontSize: 15 }}>Sea Surface Temperature</div>
            <div style={{ fontSize: 10, color: '#93C5FD' }}>SST · °C · Source: INCOIS</div>
          </div>
          <button onClick={() => onNav('home')} style={{ color: '#94A3B8' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 6.4L17.6 5 12 10.6 6.4 5 5 6.4l5.6 5.6L5 17.6 6.4 19l5.6-5.6 5.6 5.6 1.4-1.4-5.6-5.6z" />
            </svg>
          </button>
        </div>
        {/* View toggle */}
        <div className="px-4 pb-3 flex gap-0">
          <button
            onClick={() => setView('Map')}
            className="flex-1 py-2 rounded-l-xl font-medium"
            style={{ background: view === 'Map' ? '#1565C0' : 'rgba(255,255,255,0.1)', color: view === 'Map' ? '#fff' : '#93C5FD', fontSize: 13, border: '1px solid rgba(255,255,255,0.15)' }}
          >
            Map View
          </button>
          <button
            onClick={() => setView('Chart')}
            className="flex-1 py-2 rounded-r-xl font-medium"
            style={{ background: view === 'Chart' ? '#1565C0' : 'rgba(255,255,255,0.1)', color: view === 'Chart' ? '#fff' : '#93C5FD', fontSize: 13, border: '1px solid rgba(255,255,255,0.15)' }}
          >
            Chart View
          </button>
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20">
        {/* Date range */}
        <div className="px-4 pt-3 flex items-center justify-between">
          <div className="flex items-center gap-2 rounded-xl px-3 py-2 flex-1 mr-2" style={{ background: '#fff', border: '1px solid #E2E8F0' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#1565C0">
              <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z" />
            </svg>
            <span style={{ fontSize: 11, color: '#475569', fontWeight: 500 }}>1 Sep 2026 – 28 Sep 2026</span>
          </div>
          <div className="flex gap-1">
            {RANGES.map(r => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className="rounded-lg px-2 py-1.5"
                style={{ background: r === range ? '#1565C0' : '#fff', color: r === range ? '#fff' : '#64748B', fontSize: 10, fontWeight: 600, border: '1px solid #E2E8F0' }}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Chart */}
        <Card className="mx-4 mt-3">
          <div className="font-semibold mb-1" style={{ fontSize: 13, color: '#0F172A' }}>SST Comparison</div>
          <div style={{ fontSize: 10, color: '#94A3B8', marginBottom: 8 }}>Mumbai Coast · Offshore · PFZ Region</div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={sstData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="date" tick={{ fontSize: 9, fill: '#94A3B8' }} />
              <YAxis domain={[24, 34]} tick={{ fontSize: 9, fill: '#94A3B8' }} unit="°" />
              <Tooltip
                contentStyle={{ fontSize: 11, borderRadius: 8, border: '1px solid #E2E8F0' }}
                formatter={(val: number) => [`${val}°C`]}
              />
              <Line type="monotone" dataKey="mumbai" stroke="#F44336" strokeWidth={2} dot={{ r: 3 }} name="Mumbai Coast" />
              <Line type="monotone" dataKey="offshore" stroke="#FF9800" strokeWidth={2} dot={{ r: 3 }} name="Offshore 100km" />
              <Line type="monotone" dataKey="pfz" stroke="#1565C0" strokeWidth={2} dot={{ r: 3 }} name="PFZ Region" />
            </LineChart>
          </ResponsiveContainer>
          {/* Legend */}
          <div className="flex flex-col gap-1 mt-3">
            {[
              { label: 'Mumbai Coast', value: '28.4°C', color: '#F44336' },
              { label: 'Offshore (100 km)', value: '27.6°C', color: '#FF9800' },
              { label: 'PFZ Region', value: '26.8°C', color: '#1565C0' }
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="rounded-full" style={{ width: 8, height: 8, background: item.color }} />
                  <span style={{ fontSize: 11, color: '#475569' }}>{item.label}</span>
                </div>
                <span style={{ fontSize: 11, fontWeight: 700, color: item.color, fontFamily: 'JetBrains Mono' }}>{item.value}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Stats */}
        <div className="px-4 mt-3 grid grid-cols-4 gap-2">
          {[
            { label: 'Current', value: '28.4°C', color: '#1565C0' },
            { label: 'Average', value: '28.1°C', color: '#475569' },
            { label: 'Minimum', value: '26.8°C', color: '#0891B2' },
            { label: 'Maximum', value: '30.4°C', color: '#F44336' }
          ].map(s => (
            <div key={s.label} className="rounded-xl p-2.5 text-center" style={{ background: '#fff', border: '1px solid #E2E8F0' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: s.color, fontFamily: 'JetBrains Mono' }}>{s.value}</div>
              <div style={{ fontSize: 9, color: '#94A3B8', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Spatial Distribution */}
        <Card className="mx-4 mt-3">
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Spatial Distribution</div>
          <div className="flex gap-3">
            <div style={{ flex: 1, borderRadius: 10, overflow: 'hidden', height: 130 }}>
              <OceanMapSVG layer="SST" height={130} />
            </div>
            <div className="flex flex-col justify-between" style={{ width: 100 }}>
              {[
                { region: 'Mumbai Coast', value: '28.4°C', color: '#F44336' },
                { region: 'Offshore', value: '27.6°C', color: '#FF9800' },
                { region: 'PFZ Region', value: '26.8°C', color: '#1565C0' }
              ].map(r => (
                <div key={r.region} className="rounded-lg p-2" style={{ background: '#F8FAFD', border: `1px solid ${r.color}30` }}>
                  <div style={{ fontSize: 9, color: '#64748B' }}>{r.region}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: r.color, fontFamily: 'JetBrains Mono' }}>{r.value}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Provenance */}
        <div className="mx-4 mt-2 mb-2 rounded-xl px-3 py-2" style={{ background: '#EEF2FF', border: '1px solid #C7D2FE' }}>
          <div style={{ fontSize: 9, color: '#4338CA', fontWeight: 500 }}>
            Source: INCOIS · Updated: 28 Sep 2026 · Variable: SST · Unit: °C · Product: GHRSST L4
          </div>
        </div>
      </div>

      <BottomNav active="map" onNav={onNav} />
    </div>
  )
}
