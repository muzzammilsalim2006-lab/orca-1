import { StatusBar, BottomNav, LanguageSelector } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const SETTINGS = [
  { icon: '📍', label: 'Preferred Region', value: 'Mumbai Coast', screen: null },
  { icon: '📊', label: 'Default Datasets', value: 'SST, Chlorophyll, Currents', screen: null },
  { icon: '🗺️', label: 'Map Settings', value: 'Layers, Colour, Units', screen: null },
  { icon: '🔔', label: 'Notifications', value: 'Data Updates, Alerts', screen: null },
  { icon: '⬇️', label: 'Data Download Settings', value: 'Format, Resolution', screen: 'download' },
  { icon: '🔬', label: 'Research Tools', value: 'Analysis, Export, API', screen: null },
  { icon: '🌐', label: 'Language', value: null, screen: null },
  { icon: '❓', label: 'Help & Support', value: null, screen: null },
  { icon: 'ℹ️', label: 'About ORCA', value: 'v2.4.1 · Build 2026.09', screen: null }
]

const ADVANCED = [
  { icon: '📡', label: 'Offline Data', value: '2.1 GB cached' },
  { icon: '📤', label: 'Export Preferences', value: 'NetCDF, PDF' },
  { icon: '📏', label: 'Units', value: 'Metric (°C, m, km)' },
  { icon: '🗂️', label: 'Map Layer Defaults', value: 'SST + Chlorophyll' }
]

export function S12Profile({ lang, onLangChange, onNav }: Props) {
  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="flex items-center justify-between px-4 pt-3 pb-4">
          <div className="flex items-center gap-2">
            <div className="rounded-full flex items-center justify-center" style={{ width: 28, height: 28, background: 'linear-gradient(135deg, #00BDEA, #0060A8)' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
                <path d="M12 2C8 2 4 5 4 9c0 5 8 13 8 13s8-8 8-13c0-4-3.6-7-8-7zm0 9.5c-1.4 0-2.5-1.1-2.5-2.5S10.6 6.5 12 6.5s2.5 1.1 2.5 2.5S13.4 11.5 12 11.5z" />
              </svg>
            </div>
            <div>
              <div className="font-bold text-white" style={{ fontSize: 15 }}>ORCA</div>
              <div style={{ fontSize: 9, color: '#93C5FD' }}>Researcher</div>
            </div>
          </div>
          <LanguageSelector lang={lang} onChange={onLangChange} />
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20">
        {/* Profile section */}
        <div className="flex items-center gap-4 px-4 py-5 bg-white mb-3" style={{ borderBottom: '1px solid #F1F5F9' }}>
          <div className="rounded-full flex items-center justify-center flex-shrink-0" style={{ width: 60, height: 60, background: 'linear-gradient(135deg, #1565C0, #00BDEA)' }}>
            <span style={{ fontSize: 26 }}>👤</span>
          </div>
          <div className="flex-1">
            <div className="font-bold" style={{ fontSize: 16, color: '#0F172A' }}>Dr. Priya Sharma</div>
            <div style={{ fontSize: 12, color: '#64748B', marginTop: 1 }}>Senior Marine Researcher</div>
            <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 1 }}>researcher@orca.in</div>
            <div style={{ fontSize: 10, color: '#94A3B8' }}>INCOIS, Hyderabad</div>
          </div>
          <button className="rounded-xl px-3 py-2" style={{ background: '#EEF2FF', border: '1px solid #C7D2FE' }}>
            <span style={{ fontSize: 11, color: '#4338CA', fontWeight: 600 }}>Edit Profile</span>
          </button>
        </div>

        {/* Main settings */}
        <div className="mx-4 mb-3 rounded-2xl overflow-hidden" style={{ boxShadow: '0 1px 6px rgba(0,0,0,0.06)', background: '#fff' }}>
          {SETTINGS.map((s, i) => (
            <button
              key={i}
              onClick={() => s.screen && onNav(s.screen)}
              className="w-full flex items-center gap-3 px-4 py-3.5"
              style={{ borderBottom: i < SETTINGS.length - 1 ? '1px solid #F8FAFD' : 'none' }}
            >
              <span style={{ fontSize: 18, width: 28, textAlign: 'center', flexShrink: 0 }}>{s.icon}</span>
              <div className="flex-1 text-left">
                <div style={{ fontSize: 13, color: '#0F172A', fontWeight: 500 }}>{s.label}</div>
                {s.value && <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 1 }}>{s.value}</div>}
              </div>
              {s.label === 'Language' ? (
                <div className="flex-shrink-0">
                  <span style={{ fontSize: 11, color: '#64748B' }}>
                    {lang === 'English' ? 'English' : lang === 'हिंदी' ? 'हिंदी' : 'मराठी'}
                  </span>
                </div>
              ) : (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#CBD5E1">
                  <path d="M10 6l-1.4 1.4L13.2 12l-4.6 4.6L10 18l6-6z" />
                </svg>
              )}
            </button>
          ))}
        </div>

        {/* Language quick switch */}
        <div className="mx-4 mb-3 rounded-2xl overflow-hidden bg-white" style={{ boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
          <div className="px-4 py-3 border-b" style={{ borderColor: '#F8FAFD' }}>
            <div className="font-semibold" style={{ fontSize: 12, color: '#64748B', textTransform: 'uppercase', letterSpacing: 0.5 }}>Application Language</div>
          </div>
          <div className="flex divide-x" style={{ divideColor: '#F1F5F9' }}>
            {['English', 'हिंदी', 'मराठी'].map(l => (
              <button
                key={l}
                onClick={() => onLangChange(l)}
                className="flex-1 py-3 font-medium"
                style={{ fontSize: 13, color: lang === l ? '#1565C0' : '#64748B', background: lang === l ? '#EEF2FF' : '#fff', borderRight: '1px solid #F1F5F9' }}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Advanced settings */}
        <div className="mx-4 mb-3 rounded-2xl overflow-hidden" style={{ boxShadow: '0 1px 6px rgba(0,0,0,0.06)', background: '#fff' }}>
          <div className="px-4 py-3 border-b" style={{ borderColor: '#F8FAFD' }}>
            <div className="font-semibold" style={{ fontSize: 12, color: '#64748B', textTransform: 'uppercase', letterSpacing: 0.5 }}>Advanced</div>
          </div>
          {ADVANCED.map((s, i) => (
            <button
              key={i}
              className="w-full flex items-center gap-3 px-4 py-3.5"
              style={{ borderBottom: i < ADVANCED.length - 1 ? '1px solid #F8FAFD' : 'none' }}
            >
              <span style={{ fontSize: 18, width: 28, textAlign: 'center', flexShrink: 0 }}>{s.icon}</span>
              <div className="flex-1 text-left">
                <div style={{ fontSize: 13, color: '#0F172A', fontWeight: 500 }}>{s.label}</div>
                <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 1 }}>{s.value}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#CBD5E1">
                <path d="M10 6l-1.4 1.4L13.2 12l-4.6 4.6L10 18l6-6z" />
              </svg>
            </button>
          ))}
        </div>

        {/* App info */}
        <div className="text-center pb-4">
          <div style={{ fontSize: 11, color: '#94A3B8' }}>ORCA · Marine Researcher</div>
          <div style={{ fontSize: 10, color: '#CBD5E1', marginTop: 2 }}>v2.4.1 · Build 2026.09.28 · INCOIS</div>
        </div>
      </div>

      <BottomNav active="home" onNav={onNav} />
    </div>
  )
}
