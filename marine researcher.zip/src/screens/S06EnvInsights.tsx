import { useState } from 'react'
import { StatusBar, BottomNav, Card, OceanMapSVG } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const INDICATORS = [
  { label: 'Sea Surface Temperature', value: '28.4°C', status: 'Normal', statusColor: '#1565C0', trend: '+0.2°C', icon: '🌡' },
  { label: 'Chlorophyll-a', value: '1.2 mg/m³', status: 'Good', statusColor: '#4CAF50', trend: '+0.3', icon: '🌿' },
  { label: 'Sea Level Anomaly', value: '+3.2 cm', status: 'Moderate', statusColor: '#F59E0B', trend: '+1.1 cm', icon: '📈' },
  { label: 'Sea Surface Salinity', value: '34.8 PSU', status: 'Good', statusColor: '#4CAF50', trend: 'Stable', icon: '💧' },
  { label: 'Dissolved Oxygen', value: '5.1 mg/L', status: 'Good', statusColor: '#4CAF50', trend: '+0.2', icon: '⚗️' }
]

export function S06EnvInsights({ lang, onLangChange, onNav }: Props) {
  const [changeTab, setChangeTab] = useState('Chlorophyll')

  const healthScore = 78
  const circumference = 2 * Math.PI * 35
  const progress = (healthScore / 100) * circumference

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="flex items-center justify-between px-4 pt-3 pb-3">
          <div>
            <div className="font-bold text-white" style={{ fontSize: 15 }}>Environmental Insights</div>
            <div style={{ fontSize: 10, color: '#93C5FD' }}>Ecosystem health & change detection</div>
          </div>
          <button className="rounded-xl px-3 py-1.5" style={{ background: 'rgba(0,189,234,0.2)', border: '1px solid rgba(0,189,234,0.3)' }}>
            <span style={{ fontSize: 11, color: '#00BDEA', fontWeight: 600 }}>ℹ Details</span>
          </button>
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20">
        {/* Ecosystem Health Index */}
        <Card className="mx-4 mt-4">
          <div className="font-semibold mb-3" style={{ fontSize: 13, color: '#0F172A' }}>Ecosystem Health Index</div>
          <div className="flex items-center gap-4">
            {/* Ring gauge */}
            <div className="relative flex items-center justify-center" style={{ width: 90, height: 90 }}>
              <svg width="90" height="90" viewBox="0 0 90 90">
                <circle cx="45" cy="45" r="35" fill="none" stroke="#E2E8F0" strokeWidth="7" />
                <circle
                  cx="45" cy="45" r="35"
                  fill="none"
                  stroke="#4CAF50"
                  strokeWidth="7"
                  strokeDasharray={`${progress} ${circumference - progress}`}
                  strokeDashoffset={circumference * 0.25}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute text-center">
                <div className="font-bold" style={{ fontSize: 22, color: '#0F172A', lineHeight: 1 }}>{healthScore}</div>
                <div style={{ fontSize: 9, color: '#94A3B8' }}>/ 100</div>
              </div>
            </div>
            <div>
              <div className="font-bold" style={{ fontSize: 20, color: '#4CAF50' }}>GOOD</div>
              <div style={{ fontSize: 11, color: '#475569', marginTop: 2 }}>Mumbai Coast</div>
              <div style={{ fontSize: 10, color: '#94A3B8' }}>September 2026</div>
              <div className="mt-2 flex items-center gap-1.5">
                <div className="rounded-full" style={{ width: 8, height: 8, background: '#4CAF50' }} />
                <span style={{ fontSize: 10, color: '#475569' }}>Above regional average</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Key Indicators */}
        <Card className="mx-4 mt-3">
          <div className="font-semibold mb-3" style={{ fontSize: 13, color: '#0F172A' }}>Key Indicators</div>
          <div className="flex flex-col gap-2">
            {INDICATORS.map((ind, i) => (
              <div key={i} className="flex items-center gap-2 py-2" style={{ borderBottom: i < INDICATORS.length - 1 ? '1px solid #F1F5F9' : 'none' }}>
                <span style={{ fontSize: 16, width: 24, textAlign: 'center' }}>{ind.icon}</span>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.2 }}>{ind.label}</div>
                </div>
                <div className="text-right">
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#0F172A', fontFamily: 'JetBrains Mono' }}>{ind.value}</div>
                  <div style={{ fontSize: 9, color: '#94A3B8' }}>{ind.trend}</div>
                </div>
                <span className="rounded-full px-2 py-0.5 ml-1" style={{ fontSize: 9, background: ind.statusColor + '18', color: ind.statusColor, fontWeight: 600, flexShrink: 0 }}>
                  {ind.status}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Change Detection */}
        <Card className="mx-4 mt-3">
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Change Detection</div>
          {/* Tab selector */}
          <div className="flex gap-1 mb-3">
            {['SST', 'Chlorophyll', 'Turbidity'].map(t => (
              <button
                key={t}
                onClick={() => setChangeTab(t)}
                className="rounded-full px-3 py-1 font-medium"
                style={{ background: t === changeTab ? '#1565C0' : '#F1F5F9', color: t === changeTab ? '#fff' : '#64748B', fontSize: 11 }}
              >
                {t}
              </button>
            ))}
          </div>
          {/* Before / After */}
          <div className="flex items-center gap-2">
            <div style={{ flex: 1, borderRadius: 10, overflow: 'hidden', height: 110 }}>
              <div className="relative" style={{ height: '100%' }}>
                <OceanMapSVG layer={changeTab === 'Chlorophyll' ? 'SST' : 'Chlorophyll-a'} height={110} />
                <div className="absolute bottom-0 left-0 right-0 py-1 text-center" style={{ background: 'rgba(0,0,0,0.5)', fontSize: 9, color: 'white' }}>15 Sep 2026</div>
              </div>
            </div>
            <div className="flex flex-col items-center">
              <div className="rounded-full flex items-center justify-center" style={{ width: 32, height: 32, background: '#EEF2FF', border: '2px solid #C7D2FE' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#4338CA">
                  <path d="M10 6l-1.4 1.4 4.6 4.6-4.6 4.6L10 18l6-6z" />
                </svg>
              </div>
            </div>
            <div style={{ flex: 1, borderRadius: 10, overflow: 'hidden', height: 110 }}>
              <div className="relative" style={{ height: '100%' }}>
                <OceanMapSVG layer={changeTab === 'Chlorophyll' ? 'Chlorophyll-a' : 'SST'} height={110} />
                <div className="absolute bottom-0 left-0 right-0 py-1 text-center" style={{ background: 'rgba(0,0,0,0.5)', fontSize: 9, color: 'white' }}>28 Sep 2026</div>
              </div>
            </div>
          </div>
          {/* Finding */}
          <div className="mt-3 rounded-xl p-3 flex items-start gap-2" style={{ background: '#FFF7ED', border: '1px solid #FED7AA' }}>
            <span style={{ fontSize: 16 }}>⚠️</span>
            <div>
              <div style={{ fontSize: 12, color: '#92400E', fontWeight: 600 }}>Measured Change</div>
              <div style={{ fontSize: 11, color: '#78350F', marginTop: 1 }}>
                {changeTab === 'Chlorophyll'
                  ? 'Increase in chlorophyll detected (~28% increase in selected region)'
                  : changeTab === 'SST'
                  ? 'SST decreased by 1.2°C relative to 15-day mean'
                  : 'Turbidity increased in coastal zone (+15%)'}
              </div>
              <div style={{ fontSize: 9, color: '#B45309', marginTop: 3 }}>Measured change · Scientific interpretation requires further analysis</div>
            </div>
          </div>
        </Card>
      </div>

      <BottomNav active="insights" onNav={onNav} />
    </div>
  )
}
