import { useState } from 'react'
import { StatusBar, BottomNav, TabBar, OceanMapSVG } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const SPECIES = [
  {
    name: 'Indian Oil Sardine',
    sci: 'Sardinella longiceps',
    suitability: 'High',
    depth: '18–40 m',
    sst: '26–29°C',
    area: 'Mumbai to Goa',
    icon: '🐟',
    suitColor: '#4CAF50'
  },
  {
    name: 'Bombay Duck',
    sci: 'Harpadon nehereus',
    suitability: 'Moderate',
    depth: '10–30 m',
    sst: '24–28°C',
    area: 'Mumbai Coast',
    icon: '🐡',
    suitColor: '#FFC107'
  }
]

const LEGEND = [
  { label: 'High Suitability', color: '#4CAF50' },
  { label: 'Moderate', color: '#8BC34A' },
  { label: 'Low', color: '#FFC107' },
  { label: 'Non-suitable', color: '#F5F5F5' }
]

export function S05SpeciesZones({ lang, onLangChange, onNav }: Props) {
  const [tab, setTab] = useState('Fish Species')
  const [selectedSpecies, setSelectedSpecies] = useState(0)

  const species = SPECIES[selectedSpecies]

  return (
    <div style={{ background: '#0A1628', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <StatusBar />
      <div style={{ background: '#0A1628' }}>
        <div className="px-4 pt-2 pb-2">
          <div className="font-bold text-white" style={{ fontSize: 15 }}>Species & Fishing Zones</div>
          <div style={{ fontSize: 10, color: '#93C5FD' }}>Marine ecosystem & biodiversity</div>
        </div>
        <TabBar tabs={['PFZ', 'Fish Species', 'Habitats', 'MPA']} active={tab} onSelect={setTab} accent="#00BDEA" />
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 px-4 py-2" style={{ background: '#0D1E3A' }}>
        {LEGEND.map(l => (
          <div key={l.label} className="flex items-center gap-1">
            <div className="rounded-sm" style={{ width: 10, height: 10, background: l.color, border: l.color === '#F5F5F5' ? '1px solid #ccc' : 'none' }} />
            <span style={{ fontSize: 8.5, color: '#CBD5E1' }}>{l.label}</span>
          </div>
        ))}
      </div>

      {/* Map */}
      <div style={{ flex: 1, position: 'relative' }}>
        {/* Suitability colored map */}
        <svg width="100%" height="100%" viewBox="0 0 390 300" preserveAspectRatio="xMidYMid slice">
          <defs>
            <radialGradient id="suit-grad" cx="55%" cy="45%" r="55%">
              <stop offset="0%" stopColor="#4CAF50" stopOpacity="0.8" />
              <stop offset="35%" stopColor="#8BC34A" stopOpacity="0.65" />
              <stop offset="65%" stopColor="#FFC107" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#F5F5F5" stopOpacity="0.2" />
            </radialGradient>
          </defs>
          <rect width="390" height="300" fill="#0D47A1" />
          <rect width="390" height="300" fill="url(#suit-grad)" />
          {/* Coastline */}
          <path d="M 230 0 L 235 30 L 240 60 L 238 90 L 242 120 L 240 150 L 244 180 L 248 210 L 252 240 L 258 270 L 264 300 L 390 300 L 390 0 Z"
            fill="#5D7A4A" opacity="0.85" />
          {/* PFZ zones */}
          <ellipse cx="140" cy="100" rx="45" ry="35" fill="none" stroke="#00BDEA" strokeWidth="2" strokeDasharray="8,4" opacity="0.8" />
          <text x="118" y="97" fill="white" fontSize="9" fontWeight="600" fontFamily="Inter">PFZ Zone A</text>
          <ellipse cx="110" cy="200" rx="40" ry="28" fill="none" stroke="#00BDEA" strokeWidth="1.5" strokeDasharray="8,4" opacity="0.6" />
          <text x="91" y="197" fill="white" fontSize="9" fontWeight="500" fontFamily="Inter">PFZ Zone B</text>
          {/* City markers */}
          <circle cx="237" cy="90" r="4" fill="#fff" stroke="#00BDEA" strokeWidth="1.5" />
          <text x="212" y="84" fill="white" fontSize="9" fontWeight="600" fontFamily="Inter">Mumbai</text>
          <circle cx="241" cy="160" r="3.5" fill="#fff" stroke="#00BDEA" strokeWidth="1.5" />
          <text x="210" y="156" fill="white" fontSize="8.5" fontFamily="Inter">Ratnagiri</text>
          {/* Map controls */}
          <rect x="356" y="120" width="28" height="28" rx="6" fill="rgba(255,255,255,0.9)" />
          <text x="365" y="139" fontSize="16" fontWeight="700" fill="#1565C0">+</text>
          <rect x="356" y="154" width="28" height="28" rx="6" fill="rgba(255,255,255,0.9)" />
          <text x="366" y="173" fontSize="20" fontWeight="700" fill="#1565C0">−</text>
        </svg>
      </div>

      {/* Species card */}
      <div className="px-4 pb-20" style={{ background: '#0D1E3A', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
        <div className="flex items-start gap-3 py-3">
          {/* Fish avatar */}
          <div className="rounded-xl flex items-center justify-center flex-shrink-0" style={{ width: 60, height: 60, background: 'rgba(0,189,234,0.15)', border: '1px solid rgba(0,189,234,0.3)' }}>
            <span style={{ fontSize: 30 }}>{species.icon}</span>
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-bold text-white" style={{ fontSize: 14 }}>{species.name}</div>
                <div style={{ fontSize: 10, color: '#93C5FD', fontStyle: 'italic' }}>{species.sci}</div>
              </div>
              <button onClick={() => onNav('home')} style={{ color: '#64748B', fontSize: 18 }}>×</button>
            </div>
            <div className="flex items-center gap-2 mt-1.5">
              <span className="rounded-full px-2 py-0.5 font-semibold" style={{ fontSize: 9, background: species.suitColor + '25', color: species.suitColor }}>
                {species.suitability}
              </span>
              <span style={{ fontSize: 9, color: '#64748B' }}>Suitability</span>
            </div>
          </div>
        </div>
        {/* Metrics */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          {[
            { label: 'Depth Range', value: species.depth },
            { label: 'Preferred SST', value: species.sst },
            { label: 'Distribution', value: species.area }
          ].map(m => (
            <div key={m.label} className="rounded-xl p-2.5" style={{ background: 'rgba(255,255,255,0.06)' }}>
              <div style={{ fontSize: 8.5, color: '#64748B', marginBottom: 2 }}>{m.label}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#E2E8F0' }}>{m.value}</div>
            </div>
          ))}
        </div>
        {/* Species selector dots */}
        <div className="flex gap-1.5 mb-3 justify-center">
          {SPECIES.map((_, i) => (
            <button key={i} onClick={() => setSelectedSpecies(i)} className="rounded-full" style={{ width: i === selectedSpecies ? 20 : 8, height: 8, background: i === selectedSpecies ? '#00BDEA' : 'rgba(255,255,255,0.3)', transition: 'all 0.2s' }} />
          ))}
        </div>
        {/* Action buttons */}
        <div className="flex gap-2">
          <button className="flex-1 rounded-xl py-3 font-semibold" style={{ background: '#1565C0', color: '#fff', fontSize: 12 }}>
            View Distribution
          </button>
          <button className="flex-1 rounded-xl py-3 font-semibold" style={{ background: 'rgba(255,255,255,0.1)', color: '#E2E8F0', fontSize: 12, border: '1px solid rgba(255,255,255,0.2)' }}>
            More Info
          </button>
        </div>
      </div>

      <BottomNav active="map" onNav={onNav} />
    </div>
  )
}
