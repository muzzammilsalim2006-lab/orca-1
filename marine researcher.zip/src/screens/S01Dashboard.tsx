import { Header, StatusBar, BottomNav, Card, SectionTitle, MetricCard, ProvenanceTag } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const SST_ICON = (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M15 13V5c0-1.7-1.3-3-3-3S9 3.3 9 5v8c-1.2.9-2 2.4-2 4 0 2.8 2.2 5 5 5s5-2.2 5-5c0-1.6-.8-3.1-2-4z" />
  </svg>
)
const CHLR_ICON = (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17 8C8 10 5.9 16.2 3.2 21.4L4.7 22 6 19c.7.2 1.4.3 2 .3C13 19.3 16 12 16 12s-3 3.3-7 3c2-3 6-5 8-7z" />
  </svg>
)
const WIND_ICON = (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6z" />
  </svg>
)
const WAVE_ICON = (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
    <path d="M8.5 3.8C7.4 2.4 5.6 1.5 3.5 1.5c-.6 0-1 .4-1 1s.4 1 1 1c1.4 0 2.5.6 3.2 1.5L8.5 6.7c1.1 1.4 2.9 2.3 5 2.3s3.9-.9 5-2.3l1.7-2.1c.7-.9 1.9-1.5 3.3-1.5.6 0 1-.4 1-1s-.4-1-1-1c-2.1 0-3.9.9-5 2.3L16.8 5.5c-.7.9-1.9 1.5-3.3 1.5s-2.5-.6-3.3-1.5L8.5 3.8z" />
  </svg>
)

const LAYER_ITEMS = [
  { icon: '🌡', label: 'SST', sub: 'Sea Surface Temp', color: '#F44336' },
  { icon: '🌿', label: 'Chlorophyll-a', sub: 'Primary Productivity', color: '#4CAF50' },
  { icon: '📈', label: 'Sea Level', sub: 'Anomaly', color: '#1565C0' },
  { icon: '🌊', label: 'Currents', sub: 'Surface & Depth', color: '#00BCD4' }
]

const UPDATES = [
  { icon: '🛰', title: 'New satellite SST data available', sub: '28 Sep 2026 · Copernicus', color: '#1565C0' },
  { icon: '🌦', title: 'IMD marine forecast updated', sub: '28 Sep 2026 · 6-hour cycle', color: '#0891B2' },
  { icon: '📄', title: '3 new marine research papers', sub: 'Marine Ecosystem · AI Summary', color: '#7C3AED' }
]

export function S01Dashboard({ lang, onLangChange, onNav }: Props) {
  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628', paddingBottom: 8 }}>
        <StatusBar />
        <Header lang={lang} onLangChange={onLangChange} />
        {/* Greeting */}
        <div className="flex items-center gap-3 px-4 pb-4 pt-1">
          <div className="rounded-full flex items-center justify-center flex-shrink-0" style={{ width: 40, height: 40, background: 'linear-gradient(135deg, #1565C0, #00BCD4)' }}>
            <span style={{ fontSize: 18 }}>👤</span>
          </div>
          <div>
            <div className="font-semibold text-white" style={{ fontSize: 15 }}>Good morning, Researcher!</div>
            <div className="flex items-center gap-1" style={{ color: '#93C5FD', fontSize: 12 }}>
              <span>📍</span> Mumbai, Maharashtra
            </div>
          </div>
        </div>
        {/* Nav Tabs */}
        <div className="flex px-4 gap-1">
          {['Overview', 'Data', 'Projects', 'Insights'].map((tab, i) => (
            <button
              key={tab}
              className="py-2 px-3 rounded-t-lg font-medium"
              style={{
                fontSize: 12,
                color: i === 0 ? '#fff' : '#93C5FD',
                background: i === 0 ? 'rgba(255,255,255,0.15)' : 'transparent',
                borderBottom: i === 0 ? '2px solid #00BDEA' : '2px solid transparent'
              }}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto screen-scroll pb-20 px-4 pt-4 flex flex-col gap-3">

        {/* Marine Conditions Card */}
        <Card>
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="font-semibold" style={{ fontSize: 13, color: '#0F172A' }}>Current Marine Conditions</div>
              <div style={{ fontSize: 10, color: '#94A3B8' }}>28 Sep 2026, 09:40 AM</div>
            </div>
            <button style={{ color: '#94A3B8' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.4L17.6 5 12 10.6 6.4 5 5 6.4l5.6 5.6L5 17.6 6.4 19l5.6-5.6 5.6 5.6 1.4-1.4-5.6-5.6z" />
              </svg>
            </button>
          </div>
          <div className="flex gap-2">
            <MetricCard label="SST" value="28.4" unit="°C" icon={SST_ICON} color="#F44336" />
            <MetricCard label="Chlorophyll" value="1.2" unit="mg/m³" icon={CHLR_ICON} color="#4CAF50" />
            <MetricCard label="Wind" value="18" unit="km/h" icon={WIND_ICON} color="#0891B2" />
            <MetricCard label="Wave" value="1.3" unit="m" icon={WAVE_ICON} color="#1565C0" />
          </div>
          <ProvenanceTag source="INCOIS" updated="28 Sep 2026" variable="Multi-param" unit="various" />
        </Card>

        {/* Key Research Layers */}
        <Card>
          <SectionTitle title="Key Research Layers" action={
            <button style={{ fontSize: 11, color: '#1565C0', fontWeight: 600 }}>View All</button>
          } />
          <div className="grid grid-cols-4 gap-2">
            {LAYER_ITEMS.map(item => (
              <button
                key={item.label}
                onClick={() => onNav('map')}
                className="flex flex-col items-center gap-1.5 p-2.5 rounded-xl"
                style={{ background: '#F8FAFD', border: '1px solid #E2E8F0' }}
              >
                <div className="rounded-lg flex items-center justify-center" style={{ width: 34, height: 34, background: item.color + '18' }}>
                  <span style={{ fontSize: 16 }}>{item.icon}</span>
                </div>
                <span style={{ fontSize: 10, fontWeight: 600, color: '#0F172A', textAlign: 'center', lineHeight: 1.2 }}>{item.label}</span>
                <span style={{ fontSize: 8.5, color: '#94A3B8', textAlign: 'center', lineHeight: 1.2 }}>{item.sub}</span>
              </button>
            ))}
          </div>
        </Card>

        {/* Latest Updates */}
        <Card>
          <SectionTitle title="Latest Updates" action={
            <button style={{ fontSize: 11, color: '#1565C0', fontWeight: 600 }}>See All</button>
          } />
          <div className="flex flex-col gap-2.5">
            {UPDATES.map((u, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="rounded-lg flex items-center justify-center flex-shrink-0" style={{ width: 34, height: 34, background: u.color + '15' }}>
                  <span style={{ fontSize: 16 }}>{u.icon}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 12, fontWeight: 500, color: '#0F172A', lineHeight: 1.3 }}>{u.title}</div>
                  <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 2 }}>{u.sub}</div>
                </div>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#CBD5E1">
                  <path d="M10 6l-1.4 1.4L13.2 12l-4.6 4.6L10 18l6-6z" />
                </svg>
              </div>
            ))}
          </div>
        </Card>

        {/* Quick actions */}
        <Card>
          <SectionTitle title="Quick Access" />
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: 'Parameter Analysis', icon: '📊', screen: 'analysis', color: '#1565C0' },
              { label: 'Forecasts', icon: '🔮', screen: 'forecast', color: '#7C3AED' },
              { label: 'Compare Regions', icon: '⚖️', screen: 'comparison', color: '#059669' },
              { label: 'Download Data', icon: '⬇️', screen: 'download', color: '#D97706' }
            ].map(q => (
              <button
                key={q.label}
                onClick={() => onNav(q.screen)}
                className="flex items-center gap-2 p-3 rounded-xl"
                style={{ background: q.color + '10', border: `1px solid ${q.color}20` }}
              >
                <span style={{ fontSize: 18 }}>{q.icon}</span>
                <span style={{ fontSize: 11, fontWeight: 500, color: q.color, textAlign: 'left', lineHeight: 1.3 }}>{q.label}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>

      <BottomNav active="home" onNav={onNav} />
    </div>
  )
}
