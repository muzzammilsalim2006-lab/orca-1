import { useState } from 'react'
import { StatusBar, BottomNav, OceanMapSVG, MapControls, SSTColorBar, LanguageSelector } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const LAYERS = ['SST', 'Chlorophyll-a', 'Currents', 'Sea Level', 'Wind', 'Waves', 'Salinity', 'MPA', 'PFZ']
const DATES = ['26 Sep', '27 Sep', '28 Sep', '29 Sep']

export function S02DataExplorer({ lang, onLangChange, onNav }: Props) {
  const [activeLayer, setActiveLayer] = useState('SST')
  const [activeDate, setActiveDate] = useState(2)
  const [showPanel, setShowPanel] = useState(true)

  return (
    <div style={{ background: '#0A1628', height: '100%', display: 'flex', flexDirection: 'column', position: 'relative' }}>
      <StatusBar />

      {/* Search bar */}
      <div className="flex items-center gap-2 px-4 pt-2 pb-2" style={{ background: '#0A1628' }}>
        <div className="flex-1 flex items-center gap-2 rounded-xl px-3 py-2" style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.12)' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="#94A3B8">
            <path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16a6.47 6.47 0 0 0 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
          </svg>
          <span style={{ fontSize: 12, color: '#64748B' }}>Search location / coordinates...</span>
        </div>
        <LanguageSelector lang={lang} onChange={onLangChange} />
        <button className="rounded-xl p-2" style={{ background: 'rgba(255,255,255,0.1)' }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#94A3B8">
            <path d="M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z" />
          </svg>
        </button>
      </div>

      {/* Layer chips */}
      <div className="px-4 pb-2">
        <div className="chip-scroll gap-1.5">
          {LAYERS.map(l => (
            <button
              key={l}
              onClick={() => setActiveLayer(l)}
              className="rounded-full px-3 py-1.5 font-medium flex-shrink-0"
              style={{
                background: l === activeLayer ? '#00BDEA' : 'rgba(255,255,255,0.12)',
                color: l === activeLayer ? '#fff' : '#CBD5E1',
                fontSize: 11,
                border: l === activeLayer ? 'none' : '1px solid rgba(255,255,255,0.15)'
              }}
            >
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Map */}
      <div style={{ flex: 1, position: 'relative', margin: '0 0', overflow: 'hidden' }}>
        <OceanMapSVG layer={activeLayer} showSelection={true} height={310} />
        {/* SST colorbar */}
        <div style={{ position: 'absolute', left: 12, top: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
          <span style={{ fontSize: 8, color: 'white', fontWeight: 600, writingMode: 'horizontal-tb' }}>{activeLayer}</span>
          <div style={{ width: 12, height: 110, background: activeLayer === 'Chlorophyll-a' ? 'linear-gradient(to bottom, #1B5E20, #4CAF50, #81D4FA)' : 'linear-gradient(to bottom, #F44336, #FF9800, #FFEB3B, #4CAF50, #2196F3)', borderRadius: 3 }} />
          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', position: 'absolute', left: 18, top: 16, height: 110 }}>
            <span style={{ fontSize: 7.5, color: 'white' }}>{activeLayer === 'SST' ? '32' : activeLayer === 'Chlorophyll-a' ? '3.0' : '10'}</span>
            <span style={{ fontSize: 7.5, color: 'white' }}>{activeLayer === 'SST' ? '30' : activeLayer === 'Chlorophyll-a' ? '2.0' : '6'}</span>
            <span style={{ fontSize: 7.5, color: 'white' }}>{activeLayer === 'SST' ? '28' : activeLayer === 'Chlorophyll-a' ? '1.0' : '3'}</span>
            <span style={{ fontSize: 7.5, color: 'white' }}>{activeLayer === 'SST' ? '26' : activeLayer === 'Chlorophyll-a' ? '0.5' : '1'}</span>
            <span style={{ fontSize: 7.5, color: 'white' }}>{activeLayer === 'SST' ? '24' : activeLayer === 'Chlorophyll-a' ? '0.1' : '0'}</span>
          </div>
          <span style={{ fontSize: 7.5, color: 'rgba(255,255,255,0.7)' }}>{activeLayer === 'SST' ? '°C' : activeLayer === 'Chlorophyll-a' ? 'mg/m³' : 'cm/s'}</span>
        </div>
        {/* Map controls */}
        <MapControls />
        {/* Selected region label */}
        <div style={{ position: 'absolute', top: 12, right: 50, background: 'rgba(0,0,0,0.6)', borderRadius: 8, padding: '4px 8px' }}>
          <span style={{ fontSize: 10, color: 'white', fontWeight: 500 }}>Mumbai Coast</span>
        </div>
      </div>

      {/* Timeline */}
      <div className="px-4 pt-3 pb-2" style={{ background: '#0D1E3A' }}>
        <div className="flex items-center gap-2 mb-2">
          <button className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#1565C0' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
              <path d="M8 5v14l11-7z" />
            </svg>
          </button>
          <div className="flex-1 flex items-center gap-1">
            {DATES.map((d, i) => (
              <button
                key={d}
                onClick={() => setActiveDate(i)}
                className="flex-1 rounded-lg py-1.5 text-center"
                style={{
                  background: i === activeDate ? '#1565C0' : 'rgba(255,255,255,0.08)',
                  color: i === activeDate ? 'white' : '#94A3B8',
                  fontSize: 10,
                  fontWeight: i === activeDate ? 600 : 400
                }}
              >
                {d}
              </button>
            ))}
          </div>
        </div>
        <div className="text-center" style={{ fontSize: 11, color: '#93C5FD', fontWeight: 500 }}>
          {DATES[activeDate]} 2026, 09:00 AM
        </div>
      </div>

      {/* Bottom info panel */}
      {showPanel && (
        <div className="px-4 pb-20" style={{ background: '#0D1E3A', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <div className="flex items-center justify-between py-2">
            <span style={{ fontSize: 11, color: '#93C5FD', fontWeight: 600 }}>Selected Region</span>
            <button onClick={() => setShowPanel(false)} style={{ color: '#64748B' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.4L17.6 5 12 10.6 6.4 5 5 6.4l5.6 5.6L5 17.6 6.4 19l5.6-5.6 5.6 5.6 1.4-1.4-5.6-5.6z" />
              </svg>
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: activeLayer, value: activeLayer === 'SST' ? '28.4 °C' : activeLayer === 'Chlorophyll-a' ? '1.2 mg/m³' : '0.8 m/s', color: '#00BDEA' },
              { label: 'Timestamp', value: '28 Sep 2026', color: '#94A3B8' },
              { label: 'Source', value: 'INCOIS / Copernicus', color: '#94A3B8' },
              { label: 'Resolution', value: '4 km', color: '#94A3B8' }
            ].map(item => (
              <div key={item.label} className="rounded-lg p-2" style={{ background: 'rgba(255,255,255,0.06)' }}>
                <div style={{ fontSize: 9, color: '#64748B', marginBottom: 2 }}>{item.label}</div>
                <div style={{ fontSize: 12, color: item.color, fontWeight: 600 }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <BottomNav active="map" onNav={onNav} />
    </div>
  )
}
