import { useState } from 'react'
import { StatusBar, BottomNav, Card } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const DATASETS = ['Chlorophyll-a (MODIS)', 'SST (GHRSST L4)', 'Sea Level Anomaly', 'Ocean Currents (HYCOM)', 'Wave Height (WW3)']
const FORMATS = ['NetCDF', 'GeoTIFF', 'CSV']

export function S08DataDownload({ lang, onLangChange, onNav }: Props) {
  const [tab, setTab] = useState<'Satellite Data' | 'Model Data'>('Satellite Data')
  const [dataset, setDataset] = useState('Chlorophyll-a (MODIS)')
  const [datasetOpen, setDatasetOpen] = useState(false)
  const [region, setRegion] = useState('Custom Area')
  const [format, setFormat] = useState('NetCDF')
  const [downloading, setDownloading] = useState(false)
  const [done, setDone] = useState(false)

  function handleDownload() {
    setDownloading(true)
    setTimeout(() => { setDownloading(false); setDone(true) }, 2200)
  }

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="px-4 pt-3 pb-3">
          <div className="font-bold text-white" style={{ fontSize: 15 }}>Data Download</div>
          <div style={{ fontSize: 10, color: '#93C5FD' }}>Access and export marine datasets</div>
        </div>
        {/* Tabs */}
        <div className="flex mx-4 mb-3 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.15)' }}>
          {(['Satellite Data', 'Model Data'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2.5 font-medium"
              style={{ background: tab === t ? '#1565C0' : 'rgba(255,255,255,0.08)', color: tab === t ? '#fff' : '#93C5FD', fontSize: 12 }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20 px-4 pt-4 flex flex-col gap-3">

        {/* Dataset selector */}
        <Card>
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Select Dataset</div>
          <div className="relative">
            <button
              onClick={() => setDatasetOpen(!datasetOpen)}
              className="w-full flex items-center justify-between rounded-xl px-3 py-2.5"
              style={{ background: '#F8FAFD', border: '1px solid #E2E8F0' }}
            >
              <span style={{ fontSize: 13, color: '#0F172A' }}>{dataset}</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#94A3B8"><path d="M7 10l5 5 5-5z" /></svg>
            </button>
            {datasetOpen && (
              <div className="absolute left-0 right-0 top-12 rounded-xl z-50 shadow-xl overflow-hidden" style={{ background: '#fff', border: '1px solid #E2E8F0' }}>
                {DATASETS.map(d => (
                  <button
                    key={d}
                    onClick={() => { setDataset(d); setDatasetOpen(false) }}
                    className="w-full px-4 py-3 text-left"
                    style={{ fontSize: 13, color: d === dataset ? '#1565C0' : '#0F172A', background: d === dataset ? '#EEF2FF' : '#fff', borderBottom: '1px solid #F1F5F9', fontWeight: d === dataset ? 600 : 400 }}
                  >
                    {d}
                  </button>
                ))}
              </div>
            )}
          </div>
          {/* Dataset info */}
          <div className="mt-2 rounded-lg p-2.5 flex items-center justify-between" style={{ background: '#EEF2FF' }}>
            <div>
              <div style={{ fontSize: 9, color: '#4338CA' }}>Source: NASA MODIS Aqua · 4km resolution</div>
              <div style={{ fontSize: 9, color: '#6366F1' }}>Updated daily · Available: 2000–present</div>
            </div>
            <span className="rounded-full px-2 py-0.5" style={{ fontSize: 9, background: '#DBEAFE', color: '#1E40AF', fontWeight: 600 }}>L3</span>
          </div>
        </Card>

        {/* Region selector */}
        <Card>
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Select Region</div>
          <div className="flex gap-2 mb-3">
            {['Custom Area', 'Predefined', 'Draw on Map'].map(r => (
              <button
                key={r}
                onClick={() => setRegion(r)}
                className="rounded-full px-3 py-1.5 font-medium"
                style={{ background: r === region ? '#1565C0' : '#F1F5F9', color: r === region ? '#fff' : '#64748B', fontSize: 11, border: r !== region ? '1px solid #E2E8F0' : 'none' }}
              >
                {r}
              </button>
            ))}
          </div>
          {/* Mini map with selection */}
          <div style={{ borderRadius: 12, overflow: 'hidden', height: 140, position: 'relative' }}>
            <svg width="100%" height="140" viewBox="0 0 320 140" preserveAspectRatio="xMidYMid slice">
              <rect width="320" height="140" fill="#0D47A1" />
              <defs>
                <radialGradient id="dl-grad" cx="50%" cy="50%" r="70%">
                  <stop offset="0%" stopColor="#4CAF50" stopOpacity="0.6" />
                  <stop offset="60%" stopColor="#00BCD4" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#1565C0" stopOpacity="0.2" />
                </radialGradient>
              </defs>
              <rect width="320" height="140" fill="url(#dl-grad)" />
              <path d="M 190 0 L 194 20 L 197 40 L 195 60 L 198 80 L 196 100 L 200 120 L 203 140 L 320 140 L 320 0 Z" fill="#5D7A4A" opacity="0.85" />
              {/* Selection box */}
              <rect x="70" y="25" width="110" height="80" fill="rgba(0,189,234,0.12)" stroke="#00BDEA" strokeWidth="2" strokeDasharray="8,4" rx="4" />
              {/* Corner handles */}
              {[[70,25],[180,25],[70,105],[180,105]].map(([x,y],i) => (
                <circle key={i} cx={x} cy={y} r="4" fill="#00BDEA" />
              ))}
              <circle cx="192" cy="42" r="3.5" fill="#fff" />
              <text x="175" y="37" fill="white" fontSize="8" fontFamily="Inter">Mumbai</text>
              <circle cx="196" cy="88" r="3" fill="#fff" />
              <text x="183" y="83" fill="white" fontSize="7.5" fontFamily="Inter">Ratnagiri</text>
              <text x="88" y="67" fill="white" fontSize="9" fontWeight="600" fontFamily="Inter">Selected Area</text>
              <text x="96" y="78" fill="rgba(255,255,255,0.7)" fontSize="7.5" fontFamily="Inter">~280 × 200 km</text>
            </svg>
          </div>
        </Card>

        {/* Time Range */}
        <Card>
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Time Range</div>
          <div className="flex items-center gap-2">
            <div className="flex-1 rounded-xl px-3 py-2.5 flex items-center gap-2" style={{ background: '#F8FAFD', border: '1px solid #E2E8F0' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#1565C0"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z" /></svg>
              <span style={{ fontSize: 12, color: '#475569' }}>01 Sep 2026</span>
            </div>
            <span style={{ fontSize: 12, color: '#94A3B8' }}>—</span>
            <div className="flex-1 rounded-xl px-3 py-2.5 flex items-center gap-2" style={{ background: '#F8FAFD', border: '1px solid #E2E8F0' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#1565C0"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z" /></svg>
              <span style={{ fontSize: 12, color: '#475569' }}>28 Sep 2026</span>
            </div>
          </div>
        </Card>

        {/* Format */}
        <Card>
          <div className="font-semibold mb-2" style={{ fontSize: 13, color: '#0F172A' }}>Export Format</div>
          <div className="flex gap-2">
            {FORMATS.map(f => (
              <button
                key={f}
                onClick={() => setFormat(f)}
                className="flex-1 rounded-xl py-3 font-semibold"
                style={{ background: f === format ? '#1565C0' : '#F1F5F9', color: f === format ? '#fff' : '#64748B', fontSize: 12, border: f !== format ? '1px solid #E2E8F0' : 'none' }}
              >
                {f}
              </button>
            ))}
          </div>
          {/* Size estimate */}
          <div className="mt-2 flex items-center justify-between rounded-lg px-3 py-2" style={{ background: '#F8FAFD', border: '1px solid #E2E8F0' }}>
            <span style={{ fontSize: 11, color: '#475569' }}>Estimated size: <strong>124 MB</strong></span>
            <span style={{ fontSize: 11, color: '#94A3B8' }}>~2 min download</span>
          </div>
        </Card>

        {/* Download button */}
        {done ? (
          <div className="rounded-2xl py-4 flex items-center justify-center gap-2" style={{ background: '#DCFCE7', border: '1px solid #BBF7D0' }}>
            <span style={{ fontSize: 18 }}>✅</span>
            <span style={{ fontSize: 14, fontWeight: 600, color: '#166534' }}>Download Complete</span>
          </div>
        ) : (
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="rounded-2xl py-4 flex items-center justify-center gap-2 font-bold"
            style={{ background: downloading ? '#94A3B8' : '#1565C0', color: '#fff', fontSize: 15 }}
          >
            {downloading ? (
              <>
                <div className="rounded-full border-2 border-white border-t-transparent" style={{ width: 18, height: 18, animation: 'spin 0.8s linear infinite' }} />
                Preparing Download…
              </>
            ) : (
              <>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" /></svg>
                Download Data
              </>
            )}
          </button>
        )}

        <div className="rounded-xl px-3 py-2 mb-2" style={{ background: '#FEF9C3', border: '1px solid #FDE68A' }}>
          <span style={{ fontSize: 10, color: '#854D0E' }}>
            ⚠ Large downloads require a stable connection. Data access is subject to source data policies.
          </span>
        </div>
      </div>

      <BottomNav active="data" onNav={onNav} />
    </div>
  )
}
