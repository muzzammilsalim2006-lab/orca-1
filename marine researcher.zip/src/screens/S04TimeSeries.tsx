import { useState } from 'react'
import { StatusBar, BottomNav, Card, TabBar } from '../components/shared'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const chloroTrend = [
  { year: '2019', value: 1.1 }, { year: '2020', value: 1.3 }, { year: '2021', value: 1.0 },
  { year: '2022', value: 1.4 }, { year: '2023', value: 1.2 }, { year: '2024', value: 1.5 },
  { year: '2025', value: 1.3 }, { year: '2026', value: 1.8 }
]

const seasonal = [
  { month: 'Jan', value: 0.8 }, { month: 'Feb', value: 0.7 }, { month: 'Mar', value: 0.6 },
  { month: 'Apr', value: 0.7 }, { month: 'May', value: 0.9 }, { month: 'Jun', value: 2.1 },
  { month: 'Jul', value: 2.6 }, { month: 'Aug', value: 2.8 }, { month: 'Sep', value: 2.4 },
  { month: 'Oct', value: 1.5 }, { month: 'Nov', value: 1.0 }, { month: 'Dec', value: 0.9 }
]

const sstTrend = [
  { year: '2019', value: 27.2 }, { year: '2020', value: 27.5 }, { year: '2021', value: 27.8 },
  { year: '2022', value: 28.0 }, { year: '2023', value: 28.3 }, { year: '2024', value: 28.1 },
  { year: '2025', value: 28.5 }, { year: '2026', value: 28.4 }
]

const TABS = ['SST', 'Chlorophyll', 'Sea Level', 'Waves']
const RANGES = ['7D', '30D', '3M', '1Y', '5Y']

export function S04TimeSeries({ lang, onLangChange, onNav }: Props) {
  const [tab, setTab] = useState('Chlorophyll')
  const [range, setRange] = useState('5Y')

  const isChlorophyll = tab === 'Chlorophyll'
  const chartData = isChlorophyll ? chloroTrend : sstTrend
  const unit = isChlorophyll ? 'mg/m³' : tab === 'SST' ? '°C' : tab === 'Sea Level' ? 'cm' : 'm'
  const color = isChlorophyll ? '#4CAF50' : tab === 'SST' ? '#F44336' : tab === 'Sea Level' ? '#1565C0' : '#00BCD4'

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="px-4 pt-3 pb-2">
          <div className="font-bold text-white" style={{ fontSize: 15 }}>Time Series & Trends</div>
          <div style={{ fontSize: 10, color: '#93C5FD' }}>Long-term analysis · Mumbai Coast</div>
        </div>
        <TabBar tabs={TABS} active={tab} onSelect={setTab} accent="#00BDEA" />
      </div>

      <div className="flex-1 screen-scroll pb-20">
        {/* Range selector */}
        <div className="px-4 pt-3 flex items-center justify-between">
          <span style={{ fontSize: 11, color: '#475569', fontWeight: 500 }}>
            {isChlorophyll ? 'Chlorophyll-a Trend (2019–2026)' : `${tab} Trend (2019–2026)`}
          </span>
          <div className="flex gap-1">
            {RANGES.map(r => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className="rounded-lg px-2 py-1"
                style={{ background: r === range ? color : '#fff', color: r === range ? '#fff' : '#64748B', fontSize: 10, fontWeight: 600, border: '1px solid #E2E8F0' }}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Main trend chart */}
        <Card className="mx-4 mt-2">
          <div className="font-semibold mb-3" style={{ fontSize: 12, color: '#0F172A' }}>
            {isChlorophyll ? 'Chlorophyll-a Trend (2019–2026)' : `${tab} Trend`}
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={chartData} margin={{ top: 5, right: 5, left: -22, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="year" tick={{ fontSize: 8.5, fill: '#94A3B8' }} />
              <YAxis tick={{ fontSize: 8.5, fill: '#94A3B8' }} unit={isChlorophyll ? '' : '°'} />
              <Tooltip
                contentStyle={{ fontSize: 11, borderRadius: 8 }}
                formatter={(v: number) => [`${v} ${unit}`]}
              />
              <Line type="monotone" dataKey="value" stroke={color} strokeWidth={2.5} dot={{ r: 3, fill: color }} name={tab} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Seasonal pattern */}
        <Card className="mx-4 mt-3">
          <div className="font-semibold mb-3" style={{ fontSize: 12, color: '#0F172A' }}>Seasonal Pattern</div>
          <ResponsiveContainer width="100%" height={120}>
            <BarChart data={seasonal} margin={{ top: 5, right: 5, left: -22, bottom: 0 }}>
              <XAxis dataKey="month" tick={{ fontSize: 8, fill: '#94A3B8' }} />
              <YAxis tick={{ fontSize: 8, fill: '#94A3B8' }} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} formatter={(v: number) => [`${v} ${unit}`]} />
              <Bar dataKey="value" fill={color} radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-3 mt-2">
            <div className="flex items-center gap-1">
              <div className="rounded-full" style={{ width: 8, height: 8, background: '#4CAF50' }} />
              <span style={{ fontSize: 9, color: '#64748B' }}>Monsoon peak (Jun–Sep)</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="rounded-full" style={{ width: 8, height: 8, background: '#FFC107' }} />
              <span style={{ fontSize: 9, color: '#64748B' }}>Pre-monsoon low</span>
            </div>
          </div>
        </Card>

        {/* Key observations */}
        <Card className="mx-4 mt-3">
          <div className="font-semibold mb-3" style={{ fontSize: 12, color: '#0F172A' }}>Key Observations</div>
          <div className="flex flex-col gap-2.5">
            {[
              { text: 'Higher productivity during monsoon (Jun–Sep)', type: 'Observation', color: '#4CAF50', icon: '✓' },
              { text: 'Lower chlorophyll in pre-monsoon (Mar–May)', type: 'Trend', color: '#1565C0', icon: '↘' },
              { text: '2026 shows above-average productivity', type: 'Anomaly', color: '#F97316', icon: '⚠' }
            ].map((obs, i) => (
              <div key={i} className="flex items-start gap-2">
                <div className="rounded-full flex items-center justify-center flex-shrink-0 mt-0.5" style={{ width: 20, height: 20, background: obs.color + '20' }}>
                  <span style={{ fontSize: 10, color: obs.color }}>{obs.icon}</span>
                </div>
                <div className="flex-1">
                  <div style={{ fontSize: 12, color: '#0F172A', lineHeight: 1.4 }}>{obs.text}</div>
                </div>
                <span className="rounded-full px-2 py-0.5 flex-shrink-0" style={{ fontSize: 9, background: obs.color + '15', color: obs.color, fontWeight: 600 }}>
                  {obs.type}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Summary stats */}
        <div className="px-4 mt-3 grid grid-cols-3 gap-2">
          {[
            { label: 'Mean (5Y)', value: isChlorophyll ? '1.3 mg/m³' : '28.0°C', color: '#475569' },
            { label: 'Peak', value: isChlorophyll ? '2.8 mg/m³' : '30.2°C', color: '#4CAF50' },
            { label: 'Anomaly', value: isChlorophyll ? '+0.5' : '+0.4', color: '#F97316' }
          ].map(s => (
            <div key={s.label} className="rounded-xl p-2.5 text-center bg-white" style={{ border: '1px solid #E2E8F0' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: s.color, fontFamily: 'JetBrains Mono' }}>{s.value}</div>
              <div style={{ fontSize: 9, color: '#94A3B8', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <BottomNav active="insights" onNav={onNav} />
    </div>
  )
}
