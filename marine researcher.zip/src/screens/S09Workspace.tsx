import { useState } from 'react'
import { StatusBar, BottomNav, Card } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const PROJECTS = [
  {
    name: 'Coastal Productivity Analysis',
    tags: ['SST', 'Chlorophyll', 'PFZ'],
    edited: 'Last edited: 25 Sep 2026',
    color: '#1565C0',
    icon: '📊',
    status: 'Active'
  },
  {
    name: 'Cyclone Impact Study',
    tags: ['SST', 'Wind', 'Waves', 'Drift'],
    edited: 'Last edited: 18 Sep 2026',
    color: '#7C3AED',
    icon: '🌀',
    status: 'Active'
  },
  {
    name: 'MPA Effectiveness',
    tags: ['Biodiversity', 'Habitat', 'Fishing'],
    edited: 'Last edited: 10 Sep 2026',
    color: '#059669',
    icon: '🐠',
    status: 'Archived'
  }
]

const RECENT = [
  { name: 'Chlorophyll-a (MODIS)', date: '28 Sep 2026', source: 'NASA MODIS', icon: '🌿', color: '#4CAF50' },
  { name: 'Sea Level Anomaly', date: '28 Sep 2026', source: 'AVISO+', icon: '📈', color: '#1565C0' },
  { name: 'Ocean Currents (HYCOM)', date: '27 Sep 2026', source: 'HYCOM / NCODA', icon: '🌊', color: '#00BCD4' }
]

export function S09Workspace({ lang, onLangChange, onNav }: Props) {
  const [tab, setTab] = useState<'My Projects' | 'Shared'>('My Projects')

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="px-4 pt-3 pb-3">
          <div className="font-bold text-white" style={{ fontSize: 15 }}>Research Workspace</div>
          <div style={{ fontSize: 10, color: '#93C5FD' }}>Manage projects, datasets & notes</div>
        </div>
        <div className="flex mx-4 mb-3 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.15)' }}>
          {(['My Projects', 'Shared'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2.5 font-medium"
              style={{ background: tab === t ? '#1565C0' : 'rgba(255,255,255,0.08)', color: tab === t ? '#fff' : '#93C5FD', fontSize: 12 }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20 px-4 pt-4 flex flex-col gap-3">

        {/* Projects */}
        <div className="flex flex-col gap-2.5">
          {PROJECTS.map((proj, i) => (
            <button
              key={i}
              className="rounded-2xl p-4 text-left w-full flex items-start gap-3"
              style={{ background: '#fff', boxShadow: '0 1px 6px rgba(0,0,0,0.07)', borderLeft: `4px solid ${proj.color}` }}
            >
              <div className="rounded-xl flex items-center justify-center flex-shrink-0" style={{ width: 44, height: 44, background: proj.color + '15' }}>
                <span style={{ fontSize: 22 }}>{proj.icon}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div className="font-semibold" style={{ fontSize: 13, color: '#0F172A', lineHeight: 1.3 }}>{proj.name}</div>
                  <span className="rounded-full px-2 py-0.5 flex-shrink-0" style={{ fontSize: 9, background: proj.status === 'Active' ? '#DBEAFE' : '#F1F5F9', color: proj.status === 'Active' ? '#1E40AF' : '#64748B', fontWeight: 600 }}>
                    {proj.status}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {proj.tags.map(tag => (
                    <span key={tag} className="rounded-full px-2 py-0.5" style={{ fontSize: 9, background: proj.color + '12', color: proj.color, fontWeight: 500 }}>{tag}</span>
                  ))}
                </div>
                <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 5 }}>{proj.edited}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#CBD5E1">
                <path d="M10 6l-1.4 1.4L13.2 12l-4.6 4.6L10 18l6-6z" />
              </svg>
            </button>
          ))}
        </div>

        {/* New project button */}
        <button
          onClick={() => {}}
          className="w-full rounded-2xl py-3.5 flex items-center justify-center gap-2 font-semibold"
          style={{ background: '#EEF2FF', border: '2px dashed #C7D2FE', color: '#4338CA', fontSize: 13 }}
        >
          <span style={{ fontSize: 18 }}>+</span>
          New Project
        </button>

        {/* Recently Viewed Data */}
        <Card>
          <div className="font-semibold mb-3" style={{ fontSize: 13, color: '#0F172A' }}>Recently Viewed Data</div>
          <div className="flex flex-col gap-2.5">
            {RECENT.map((item, i) => (
              <button
                key={i}
                className="flex items-center gap-3 w-full"
                style={{ borderBottom: i < RECENT.length - 1 ? '1px solid #F1F5F9' : 'none', paddingBottom: i < RECENT.length - 1 ? 10 : 0 }}
              >
                {/* Thumbnail */}
                <div className="rounded-xl flex items-center justify-center flex-shrink-0" style={{ width: 44, height: 44, background: item.color + '18', border: `1px solid ${item.color}30` }}>
                  <span style={{ fontSize: 20 }}>{item.icon}</span>
                </div>
                <div className="flex-1 text-left">
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#0F172A' }}>{item.name}</div>
                  <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 1 }}>{item.date} · {item.source}</div>
                </div>
                <div className="flex gap-1">
                  <button className="rounded-lg px-2 py-1" style={{ background: '#F1F5F9', fontSize: 10, color: '#475569' }}>Open</button>
                  <button className="rounded-lg p-1" style={{ background: '#F1F5F9' }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="#64748B"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" /></svg>
                  </button>
                </div>
              </button>
            ))}
          </div>
        </Card>
      </div>

      <BottomNav active="data" onNav={onNav} />
    </div>
  )
}
