import { useState } from 'react'
import { StatusBar, BottomNav, Card, OceanMapSVG } from '../components/shared'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer, Area, AreaChart } from 'recharts'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

const forecastData = [
  { date: '28 Sep', observed: 28.4, forecast: null, upper: null, lower: null },
  { date: '29 Sep', observed: 28.2, forecast: 28.2, upper: 28.6, lower: 27.8 },
  { date: '30 Sep', observed: null, forecast: 28.0, upper: 28.7, lower: 27.3 },
  { date: '1 Oct', observed: null, forecast: 27.8, upper: 28.9, lower: 26.7 },
  { date: '2 Oct', observed: null, forecast: 27.5, upper: 29.0, lower: 26.0 },
  { date: '3 Oct', observed: null, forecast: 27.2, upper: 29.1, lower: 25.3 },
  { date: '4 Oct', observed: null, forecast: 27.0, upper: 29.2, lower: 24.8 },
]

const PARAMS = ['Sea Surface Temperature', 'Chlorophyll-a', 'Wave Height', 'Wind Speed']

export function S07Forecast({ lang, onLangChange, onNav }: Props) {
  const [tab, setTab] = useState<'Forecast' | 'Model Comparison'>('Forecast')
  const [param, setParam] = useState('Sea Surface Temperature')
  const [paramOpen, setParamOpen] = useState(false)

  return (
    <div style={{ background: '#F4F7FA', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: '#0A1628' }}>
        <StatusBar />
        <div className="px-4 pt-3 pb-3">
          <div className="font-bold text-white" style={{ fontSize: 15 }}>Model & Forecast</div>
          <div style={{ fontSize: 10, color: '#93C5FD' }}>Predictive analysis · 7-day horizon</div>
        </div>
        {/* Tabs */}
        <div className="flex mx-4 mb-3 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.15)' }}>
          {(['Forecast', 'Model Comparison'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2 font-medium"
              style={{ background: tab === t ? '#1565C0' : 'rgba(255,255,255,0.08)', color: tab === t ? '#fff' : '#93C5FD', fontSize: 12 }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 screen-scroll pb-20">
        {/* Parameter selector */}
        <div className="px-4 pt-3 relative">
          <button
            onClick={() => setParamOpen(!paramOpen)}
            className="w-full flex items-center justify-between rounded-xl px-3 py-3"
            style={{ background: '#fff', border: '1px solid #E2E8F0', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}
          >
            <span style={{ fontSize: 13, color: '#0F172A', fontWeight: 500 }}>{param}</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="#94A3B8">
              <path d="M7 10l5 5 5-5z" />
            </svg>
          </button>
          {paramOpen && (
            <div className="absolute left-4 right-4 top-16 rounded-xl z-50 shadow-xl overflow-hidden" style={{ background: '#fff', border: '1px solid #E2E8F0' }}>
              {PARAMS.map(p => (
                <button
                  key={p}
                  onClick={() => { setParam(p); setParamOpen(false) }}
                  className="w-full px-4 py-3 text-left"
                  style={{ fontSize: 13, color: p === param ? '#1565C0' : '#0F172A', background: p === param ? '#EEF2FF' : '#fff', borderBottom: '1px solid #F1F5F9', fontWeight: p === param ? 600 : 400 }}
                >
                  {p}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Confidence notice */}
        <div className="mx-4 mt-2 rounded-xl px-3 py-2 flex items-center gap-2" style={{ background: '#EEF2FF', border: '1px solid #C7D2FE' }}>
          <span style={{ fontSize: 12 }}>ℹ️</span>
          <span style={{ fontSize: 10, color: '#4338CA' }}>
            Shaded area shows 90% forecast confidence interval. Uncertainty increases with forecast horizon.
          </span>
        </div>

        {/* Forecast chart */}
        <Card className="mx-4 mt-3">
          <div className="flex items-center justify-between mb-1">
            <div className="font-semibold" style={{ fontSize: 13, color: '#0F172A' }}>Forecast (Next 7 Days)</div>
            <span className="rounded-full px-2 py-0.5" style={{ fontSize: 9, background: '#DBEAFE', color: '#1E40AF', fontWeight: 600 }}>
              High Confidence
            </span>
          </div>
          <div style={{ fontSize: 10, color: '#94A3B8', marginBottom: 8 }}>
            {param} · °C · INCOIS WRF-MOM
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={forecastData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="confGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1565C0" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#1565C0" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="date" tick={{ fontSize: 9, fill: '#94A3B8' }} />
              <YAxis domain={[24, 32]} tick={{ fontSize: 9, fill: '#94A3B8' }} unit="°" />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} formatter={(v: number) => v ? [`${v}°C`] : ['—']} />
              <ReferenceLine x="29 Sep" stroke="#F97316" strokeDasharray="4,2" label={{ value: 'Now', fill: '#F97316', fontSize: 9 }} />
              <Area type="monotone" dataKey="upper" stroke="none" fill="url(#confGrad)" name="Upper bound" />
              <Area type="monotone" dataKey="lower" stroke="none" fill="white" name="Lower bound" />
              <Line type="monotone" dataKey="observed" stroke="#F44336" strokeWidth={2.5} dot={{ r: 3 }} name="Observed" connectNulls={false} />
              <Line type="monotone" dataKey="forecast" stroke="#1565C0" strokeWidth={2} strokeDasharray="5,3" dot={{ r: 2 }} name="Forecast" connectNulls={false} />
            </AreaChart>
          </ResponsiveContainer>
          {/* Legend */}
          <div className="flex gap-4 mt-2">
            <div className="flex items-center gap-1.5">
              <div className="rounded-full" style={{ width: 12, height: 3, background: '#F44336' }} />
              <span style={{ fontSize: 10, color: '#475569' }}>Observed</span>
            </div>
            <div className="flex items-center gap-1.5">
              <svg width="14" height="3" viewBox="0 0 14 3"><line x1="0" y1="1.5" x2="14" y2="1.5" stroke="#1565C0" strokeWidth="2" strokeDasharray="4,2" /></svg>
              <span style={{ fontSize: 10, color: '#475569' }}>Forecast</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div style={{ width: 12, height: 8, background: '#1565C020', borderRadius: 2 }} />
              <span style={{ fontSize: 10, color: '#475569' }}>90% CI</span>
            </div>
          </div>
        </Card>

        {/* Forecast Map */}
        <Card className="mx-4 mt-3">
          <div className="flex items-center justify-between mb-2">
            <div className="font-semibold" style={{ fontSize: 13, color: '#0F172A' }}>Forecast Map (3 Days)</div>
            <span style={{ fontSize: 10, color: '#94A3B8' }}>1 Oct 2026, 12:00 PM</span>
          </div>
          <div style={{ borderRadius: 12, overflow: 'hidden', position: 'relative', height: 160 }}>
            <OceanMapSVG layer="SST" height={160} />
            {/* Play overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <button className="rounded-full flex items-center justify-center shadow-lg" style={{ width: 44, height: 44, background: 'rgba(21,101,192,0.88)' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </button>
            </div>
            {/* Timestamp overlay */}
            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
              <span className="rounded-lg px-2 py-1" style={{ background: 'rgba(0,0,0,0.65)', fontSize: 9, color: 'white' }}>1 Oct 2026, 12:00 PM</span>
              <span className="rounded-lg px-2 py-1" style={{ background: 'rgba(0,0,0,0.65)', fontSize: 9, color: '#93C5FD' }}>+72h forecast</span>
            </div>
          </div>
          {/* Time slider */}
          <div className="mt-3">
            <input type="range" min="0" max="7" defaultValue="3" className="w-full" style={{ accentColor: '#1565C0' }} />
            <div className="flex justify-between mt-1">
              <span style={{ fontSize: 9, color: '#94A3B8' }}>Now</span>
              <span style={{ fontSize: 9, color: '#94A3B8' }}>+7 days</span>
            </div>
          </div>
        </Card>

        {/* Model info */}
        <Card className="mx-4 mt-3 mb-2">
          <div className="font-semibold mb-2" style={{ fontSize: 12, color: '#0F172A' }}>Forecast Details</div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'Model', value: 'WRF-MOM' },
              { label: 'Resolution', value: '4 km' },
              { label: 'Run Time', value: '28 Sep 00Z' }
            ].map(d => (
              <div key={d.label} className="rounded-lg p-2" style={{ background: '#F8FAFD' }}>
                <div style={{ fontSize: 9, color: '#94A3B8' }}>{d.label}</div>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#0F172A', fontFamily: 'JetBrains Mono' }}>{d.value}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <BottomNav active="insights" onNav={onNav} />
    </div>
  )
}
