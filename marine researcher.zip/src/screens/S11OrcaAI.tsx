import { useState, useRef, useEffect } from 'react'
import { StatusBar, BottomNav, LanguageSelector } from '../components/shared'

interface Props {
  lang: string
  onLangChange: (l: string) => void
  onNav: (s: string) => void
}

type VoiceState = 'idle' | 'listening' | 'processing' | 'response'

const SUGGESTED = [
  'Show SST trend for Mumbai',
  'Compare chlorophyll in 2024 vs 2026',
  'Find high productivity regions',
  'Summarize recent cyclone impact',
  'Generate research summary'
]

const SAMPLE_RESPONSES: Record<string, string> = {
  'Show SST trend for Mumbai': 'Mumbai Coast SST has ranged from 26.8°C to 30.4°C over the past 5 years. Current value: 28.4°C. The 2026 average (28.3°C) is +0.3°C above the 2019–2024 mean. [Source: INCOIS GHRSST L4, updated daily]',
  'Compare chlorophyll in 2024 vs 2026': 'Chlorophyll-a comparison for Mumbai Coast:\n• 2024 annual mean: 1.3 mg/m³\n• 2026 mean (Jan–Sep): 1.6 mg/m³\n• Change: +23% increase observed\nNote: Seasonal sampling differences may affect direct comparison. [Source: MODIS Aqua L3, 4km]',
  'Find high productivity regions': 'Based on Sep 2026 Chlorophyll-a data:\n1. Lakshadweep Islands: 2.3 mg/m³ (High)\n2. Kerala Coast: 1.9 mg/m³ (High)\n3. Mumbai–Goa Coast: 1.2–1.4 mg/m³ (Moderate)\nThese are measured satellite-derived values. [Source: INCOIS / MODIS]',
  'Summarize recent cyclone impact': 'No active cyclones in the Arabian Sea as of 28 Sep 2026. Recent Bay of Bengal cyclone (Sep 12–18) caused: SST cooling of –1.8°C in affected track; Chlorophyll increase detected 5–7 days post-storm. Mumbai coast not directly impacted. [Source: IMD, INCOIS]',
  'Generate research summary': 'Research Summary — Mumbai Coast, September 2026:\n• SST: 28.4°C (above 5-year mean)\n• Chlorophyll-a: 1.2 mg/m³ (above average for Sep)\n• Ecosystem Health Index: 78/100 (Good)\n• PFZ active in 3 zones\n[Generated from INCOIS, MODIS, IMD datasets]'
}

export function S11OrcaAI({ lang, onLangChange, onNav }: Props) {
  const [voiceState, setVoiceState] = useState<VoiceState>('idle')
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; text: string }[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  function scrollToBottom() {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => { scrollToBottom() }, [messages])

  function sendMessage(text: string) {
    if (!text.trim()) return
    const userMsg = text.trim()
    setMessages(prev => [...prev, { role: 'user', text: userMsg }])
    setInput('')
    setVoiceState('processing')
    setTimeout(() => {
      const response = SAMPLE_RESPONSES[userMsg] || `I've analyzed the data for "${userMsg}". Based on available INCOIS and satellite datasets, here is what I found for the Mumbai Coast region as of 28 Sep 2026. For a detailed analysis, please refine your query or specify a parameter and region.`
      setMessages(prev => [...prev, { role: 'ai', text: response }])
      setVoiceState('idle')
    }, 1400)
  }

  function handleVoice() {
    if (voiceState === 'idle') {
      setVoiceState('listening')
      setTimeout(() => {
        setVoiceState('processing')
        setTimeout(() => {
          const msg = 'Show SST trend for Mumbai'
          setMessages(prev => [...prev, { role: 'user', text: msg }])
          setTimeout(() => {
            setMessages(prev => [...prev, { role: 'ai', text: SAMPLE_RESPONSES[msg] }])
            setVoiceState('idle')
          }, 800)
        }, 800)
      }, 2000)
    } else {
      setVoiceState('idle')
    }
  }

  const hasMessages = messages.length > 0

  return (
    <div style={{ background: '#0A1628', height: '100%', display: 'flex', flexDirection: 'column' }}>
      <StatusBar />
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5" style={{ background: '#0A1628' }}>
        <div className="flex items-center gap-2">
          <div className="rounded-full flex items-center justify-center" style={{ width: 32, height: 32, background: 'linear-gradient(135deg, #00BDEA, #1565C0)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
              <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
            </svg>
          </div>
          <div>
            <div className="font-bold text-white" style={{ fontSize: 15 }}>ORCA AI</div>
            <div style={{ fontSize: 9, color: '#93C5FD' }}>Research Assistant</div>
          </div>
        </div>
        <LanguageSelector lang={lang} onChange={onLangChange} />
      </div>

      {/* Chat area */}
      <div className="flex-1 overflow-y-auto screen-scroll px-4 pb-2">
        {!hasMessages && (
          <div className="flex flex-col items-center pt-6 pb-4">
            {/* AI avatar */}
            <div className="rounded-full flex items-center justify-center mb-4" style={{ width: 64, height: 64, background: 'linear-gradient(135deg, #00BDEA20, #1565C030)', border: '2px solid rgba(0,189,234,0.3)' }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="#00BDEA">
                <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
              </svg>
            </div>
            {/* Greeting */}
            <div className="rounded-2xl p-4 mb-4" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.1)', maxWidth: '85%' }}>
              <div className="font-semibold text-white mb-1" style={{ fontSize: 14 }}>Good morning, Researcher!</div>
              <div style={{ fontSize: 12, color: '#CBD5E1', lineHeight: 1.5 }}>
                I can help you analyze marine data, compare regions, generate insights, and support your research.
              </div>
            </div>
            {/* Suggested prompts */}
            <div className="w-full mb-4">
              <div style={{ fontSize: 11, color: '#64748B', marginBottom: 8, textAlign: 'center' }}>Try asking:</div>
              <div className="flex flex-col gap-2">
                {SUGGESTED.map(s => (
                  <button
                    key={s}
                    onClick={() => sendMessage(s)}
                    className="rounded-xl px-4 py-2.5 text-left font-medium"
                    style={{ background: 'rgba(255,255,255,0.08)', color: '#00BDEA', fontSize: 12, border: '1px solid rgba(0,189,234,0.2)' }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Messages */}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} mb-3`}>
            {msg.role === 'ai' && (
              <div className="rounded-full flex items-center justify-center mr-2 flex-shrink-0 self-end" style={{ width: 28, height: 28, background: 'linear-gradient(135deg, #00BDEA, #1565C0)' }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
                  <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
                </svg>
              </div>
            )}
            <div
              className="rounded-2xl px-4 py-3"
              style={{
                maxWidth: '80%',
                background: msg.role === 'user' ? '#1565C0' : 'rgba(255,255,255,0.1)',
                color: 'white',
                fontSize: 12,
                lineHeight: 1.6,
                whiteSpace: 'pre-line',
                borderBottomRightRadius: msg.role === 'user' ? 4 : 16,
                borderBottomLeftRadius: msg.role === 'ai' ? 4 : 16
              }}
            >
              {msg.text}
              {msg.role === 'ai' && (
                <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.45)', marginTop: 6 }}>
                  AI-generated · Verify with source data
                </div>
              )}
            </div>
          </div>
        ))}
        {voiceState === 'processing' && (
          <div className="flex justify-start mb-3">
            <div className="rounded-full flex items-center justify-center mr-2 flex-shrink-0" style={{ width: 28, height: 28, background: 'linear-gradient(135deg, #00BDEA, #1565C0)' }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" /></svg>
            </div>
            <div className="rounded-2xl px-4 py-3 flex items-center gap-1.5" style={{ background: 'rgba(255,255,255,0.1)' }}>
              {[0.6, 0.85, 1, 0.85, 0.6].map((h, i) => (
                <div key={i} className="rounded-full" style={{ width: 5, height: 5 * h * 4, background: '#00BDEA', opacity: 0.7 + i * 0.05 }} />
              ))}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Voice state indicator */}
      {voiceState === 'listening' && (
        <div className="flex flex-col items-center py-4" style={{ background: '#0D1E3A' }}>
          <div className="flex items-end gap-1.5 h-10">
            {[18, 28, 36, 44, 36, 28, 44, 32, 20, 38].map((h, i) => (
              <div key={i} className="wave-bar" style={{ height: h }} />
            ))}
          </div>
          <div style={{ fontSize: 11, color: '#00BDEA', marginTop: 6, fontWeight: 500 }}>Listening…</div>
        </div>
      )}

      {/* Bottom controls */}
      <div className="px-4 pb-20 pt-3" style={{ background: '#0D1E3A', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        {/* Voice button */}
        <div className="flex justify-center mb-3">
          <button
            onClick={handleVoice}
            className="rounded-full flex items-center justify-center shadow-lg"
            style={{
              width: 64,
              height: 64,
              background: voiceState === 'listening'
                ? 'linear-gradient(135deg, #F44336, #FF7043)'
                : 'linear-gradient(135deg, #00BDEA, #1565C0)',
              boxShadow: voiceState === 'listening'
                ? '0 0 0 8px rgba(244,67,54,0.2)'
                : '0 4px 20px rgba(0,189,234,0.3)'
            }}
          >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
              {voiceState === 'listening'
                ? <rect x="7" y="7" width="10" height="10" rx="2" />
                : <path d="M12 14c1.7 0 3-1.3 3-3V5c0-1.7-1.3-3-3-3S9 3.3 9 5v6c0 1.7 1.3 3 3 3zm-1-9c0-.6.4-1 1-1s1 .4 1 1v6c0 .6-.4 1-1 1s-1-.4-1-1V5zm-4 6c0 2.8 2.2 5 5 5s5-2.2 5-5h-2c0 1.7-1.3 3-3 3s-3-1.3-3-3H7zm5 8v-2h-1v2H9v2h6v-2h-3z" />
              }
            </svg>
          </button>
        </div>
        {voiceState === 'idle' && <div className="text-center mb-3" style={{ fontSize: 10, color: '#64748B' }}>Tap to speak</div>}
        {/* Text input */}
        <div className="flex items-center gap-2 rounded-2xl px-4 py-2.5" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}>
          <input
            className="flex-1 bg-transparent text-white outline-none"
            style={{ fontSize: 13 }}
            placeholder="Type your question..."
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage(input)}
          />
          <button
            onClick={() => sendMessage(input)}
            className="rounded-xl px-3 py-1.5"
            style={{ background: input.trim() ? '#1565C0' : 'rgba(255,255,255,0.1)', opacity: input.trim() ? 1 : 0.5 }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
              <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
            </svg>
          </button>
        </div>
      </div>

      <BottomNav active="ai" onNav={onNav} />
    </div>
  )
}
