import { useState } from 'react'

// ── Status Bar ────────────────────────────────────────────────────────────────
export function StatusBar() {
  return (
    <div className="flex items-center justify-between px-5 pt-3 pb-1" style={{ background: '#0A1628' }}>
      <span className="text-white text-xs font-semibold" style={{ fontFamily: 'Inter' }}>9:41</span>
      <div className="flex items-center gap-1.5">
        <svg width="16" height="11" viewBox="0 0 16 11" fill="white" opacity="0.9">
          <rect x="0" y="5" width="3" height="6" rx="0.5" />
          <rect x="4.5" y="3" width="3" height="8" rx="0.5" />
          <rect x="9" y="1" width="3" height="10" rx="0.5" />
          <rect x="13.5" y="0" width="2.5" height="11" rx="0.5" />
        </svg>
        <svg width="15" height="11" viewBox="0 0 15 11" fill="none">
          <path d="M7.5 2.5C9.8 2.5 11.9 3.4 13.4 4.9L14.8 3.5C12.9 1.6 10.3 0.5 7.5 0.5C4.7 0.5 2.1 1.6 0.2 3.5L1.6 4.9C3.1 3.4 5.2 2.5 7.5 2.5Z" fill="white" opacity="0.9" />
          <path d="M7.5 5.5C9 5.5 10.3 6.1 11.3 7L12.7 5.6C11.3 4.3 9.5 3.5 7.5 3.5C5.5 3.5 3.7 4.3 2.3 5.6L3.7 7C4.7 6.1 6 5.5 7.5 5.5Z" fill="white" opacity="0.9" />
          <circle cx="7.5" cy="9" r="1.5" fill="white" />
        </svg>
        <div className="flex items-center gap-0.5">
          <div className="rounded-sm" style={{ width: 22, height: 11, border: '1.5px solid rgba(255,255,255,0.8)', padding: '1.5px', display: 'flex', alignItems: 'center' }}>
            <div style={{ width: '75%', height: '100%', background: '#4CAF50', borderRadius: 1 }} />
          </div>
        </div>
      </div>
    </div>
  )
}

// ── ORCA Header ───────────────────────────────────────────────────────────────
interface HeaderProps {
  title?: string
  subtitle?: string
  showLang?: boolean
  showNotif?: boolean
  showBack?: boolean
  onBack?: () => void
  lang: string
  onLangChange: (l: string) => void
}

export function Header({ title = 'ORCA', subtitle = 'Marine Researcher', showLang = true, showNotif = true, showBack = false, onBack, lang, onLangChange }: HeaderProps) {
  return (
    <div className="flex items-center justify-between px-4 py-2.5" style={{ background: '#0A1628' }}>
      <div className="flex items-center gap-2.5">
        {showBack && (
          <button onClick={onBack} className="mr-1">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="white">
              <path d="M12.5 15L7.5 10L12.5 5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            </svg>
          </button>
        )}
        <div className="flex items-center gap-1.5">
          <div className="rounded-full flex items-center justify-center" style={{ width: 30, height: 30, background: 'linear-gradient(135deg, #00BDEA, #0060A8)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
              <path d="M12 2C8 2 4 5 4 9c0 5 8 13 8 13s8-8 8-13c0-4-3.6-7-8-7zm0 9.5c-1.4 0-2.5-1.1-2.5-2.5S10.6 6.5 12 6.5s2.5 1.1 2.5 2.5S13.4 11.5 12 11.5z" />
            </svg>
          </div>
          <div>
            <div className="font-bold text-white" style={{ fontSize: 15, letterSpacing: 0.5 }}>{title}</div>
            <div style={{ fontSize: 9, color: '#93C5FD', letterSpacing: 0.3 }}>{subtitle}</div>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {showLang && <LanguageSelector lang={lang} onChange={onLangChange} />}
        {showNotif && (
          <button className="relative">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6V11c0-3.1-1.6-5.6-4.5-6.3V4c0-.8-.7-1.5-1.5-1.5S10.5 3.2 10.5 4v.7C7.6 5.4 6 7.9 6 11v5l-1.3 1.3c-.6.6-.2 1.7.7 1.7h13.2c.9 0 1.3-1.1.7-1.7L18 16z" fill="white" opacity="0.9" />
            </svg>
            <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full" style={{ background: '#F44336' }} />
          </button>
        )}
      </div>
    </div>
  )
}

// ── Language Selector ─────────────────────────────────────────────────────────
const LANGS = ['English', 'हिंदी', 'मराठी']
const LANG_SHORT: Record<string, string> = { English: 'EN', 'हिंदी': 'हिं', 'मराठी': 'मर' }

export function LanguageSelector({ lang, onChange }: { lang: string; onChange: (l: string) => void }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium"
        style={{ background: 'rgba(255,255,255,0.12)', color: '#E2E8F0', fontSize: 11 }}
      >
        <span style={{ fontSize: 11 }}>🌐</span>
        <span>{lang === 'English' ? 'EN' : lang === 'हिंदी' ? 'हिं' : 'मर'}</span>
        <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
          <path d="M2 3.5L5 6.5L8 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        </svg>
      </button>
      {open && (
        <div className="absolute right-0 top-8 rounded-xl shadow-xl z-50 overflow-hidden" style={{ background: '#1A2744', minWidth: 110 }}>
          {LANGS.map(l => (
            <button
              key={l}
              onClick={() => { onChange(l); setOpen(false) }}
              className="w-full text-left px-3 py-2 text-xs flex items-center gap-2"
              style={{ color: l === lang ? '#00BDEA' : '#CBD5E1', background: l === lang ? 'rgba(0,189,234,0.12)' : 'transparent', fontSize: 12 }}
            >
              {l === lang && <span style={{ color: '#00BDEA' }}>✓</span>}
              {l !== lang && <span style={{ width: 12 }} />}
              {l}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ── Bottom Navigation ─────────────────────────────────────────────────────────
interface BottomNavProps {
  active: string
  onNav: (screen: string) => void
}

const NAV_ITEMS = [
  {
    id: 'home', label: 'Home',
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill={active ? '#00BDEA' : '#94A3B8'}>
        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
      </svg>
    )
  },
  {
    id: 'map', label: 'Map',
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M9 3L3 6v15l6-3 6 3 6-3V3l-6 3-6-3z" stroke={active ? '#00BDEA' : '#94A3B8'} strokeWidth="1.8" strokeLinejoin="round" />
        <path d="M9 3v15M15 6v15" stroke={active ? '#00BDEA' : '#94A3B8'} strokeWidth="1.8" />
      </svg>
    )
  },
  {
    id: 'data', label: 'Data',
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill={active ? '#00BDEA' : '#94A3B8'}>
        <rect x="3" y="13" width="4" height="8" rx="1" />
        <rect x="10" y="9" width="4" height="12" rx="1" />
        <rect x="17" y="5" width="4" height="16" rx="1" />
      </svg>
    )
  },
  {
    id: 'insights', label: 'Insights',
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="4" stroke={active ? '#00BDEA' : '#94A3B8'} strokeWidth="2" />
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M16.9 16.9l2.1 2.1M4.9 19.1l2.1-2.1M16.9 7.1l2.1-2.1" stroke={active ? '#00BDEA' : '#94A3B8'} strokeWidth="2" strokeLinecap="round" />
      </svg>
    )
  },
  {
    id: 'ai', label: 'AI',
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill={active ? '#00BDEA' : '#94A3B8'} />
      </svg>
    )
  }
]

export function BottomNav({ active, onNav }: BottomNavProps) {
  return (
    <div
      className="flex items-center justify-around px-2 pb-2 pt-2 border-t"
      style={{ background: '#fff', borderColor: '#E2E8F0', position: 'absolute', bottom: 0, left: 0, right: 0 }}
    >
      {NAV_ITEMS.map(item => (
        <button
          key={item.id}
          onClick={() => onNav(item.id)}
          className="flex flex-col items-center gap-0.5 px-3 py-1"
        >
          {item.icon(active === item.id)}
          <span style={{ fontSize: 10, color: active === item.id ? '#00BDEA' : '#94A3B8', fontWeight: active === item.id ? 600 : 400 }}>
            {item.label}
          </span>
        </button>
      ))}
    </div>
  )
}

// ── Metric Card ───────────────────────────────────────────────────────────────
interface MetricCardProps {
  label: string
  value: string
  unit: string
  icon: React.ReactNode
  color?: string
}

export function MetricCard({ label, value, unit, icon, color = '#1565C0' }: MetricCardProps) {
  return (
    <div className="flex flex-col items-center gap-1 p-3 rounded-xl flex-1" style={{ background: '#F8FAFD', minWidth: 0 }}>
      <div className="rounded-lg flex items-center justify-center" style={{ width: 32, height: 32, background: color + '18' }}>
        <span style={{ color }}>{icon}</span>
      </div>
      <div className="font-bold text-center" style={{ fontSize: 15, color: '#0F172A', lineHeight: 1.1 }}>{value}</div>
      <div style={{ fontSize: 9, color: '#64748B', textAlign: 'center', fontWeight: 500 }}>{unit}</div>
      <div style={{ fontSize: 9, color: '#94A3B8', textAlign: 'center' }}>{label}</div>
    </div>
  )
}

// ── Tab Bar ───────────────────────────────────────────────────────────────────
export function TabBar({ tabs, active, onSelect, accent = '#1565C0' }: { tabs: string[]; active: string; onSelect: (t: string) => void; accent?: string }) {
  return (
    <div className="flex border-b" style={{ borderColor: '#E2E8F0', background: '#fff' }}>
      {tabs.map(t => (
        <button
          key={t}
          onClick={() => onSelect(t)}
          className="flex-1 py-2.5 text-center text-xs font-medium transition-colors"
          style={{
            color: active === t ? accent : '#64748B',
            borderBottom: active === t ? `2px solid ${accent}` : '2px solid transparent',
            fontSize: 12
          }}
        >
          {t}
        </button>
      ))}
    </div>
  )
}

// ── Chip ─────────────────────────────────────────────────────────────────────
export function Chip({ label, active, onClick, color }: { label: string; active?: boolean; onClick?: () => void; color?: string }) {
  const bg = active ? (color || '#1565C0') : '#F1F5F9'
  const text = active ? '#fff' : '#475569'
  return (
    <button
      onClick={onClick}
      className="rounded-full px-3 py-1 font-medium whitespace-nowrap flex-shrink-0"
      style={{ background: bg, color: text, fontSize: 11, border: active ? 'none' : '1px solid #E2E8F0' }}
    >
      {label}
    </button>
  )
}

// ── Section Title ─────────────────────────────────────────────────────────────
export function SectionTitle({ title, action }: { title: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-2">
      <span className="font-semibold" style={{ fontSize: 13, color: '#0F172A' }}>{title}</span>
      {action}
    </div>
  )
}

// ── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, className = '', style = {} }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <div className={`rounded-2xl bg-white p-4 ${className}`} style={{ boxShadow: '0 1px 6px rgba(0,0,0,0.07)', ...style }}>
      {children}
    </div>
  )
}

// ── Status Badge ─────────────────────────────────────────────────────────────
export function StatusBadge({ status }: { status: 'good' | 'normal' | 'moderate' | 'caution' | 'anomaly' | 'critical' }) {
  const config = {
    good: { label: 'Good', bg: '#DCFCE7', text: '#166534' },
    normal: { label: 'Normal', bg: '#DBEAFE', text: '#1e40af' },
    moderate: { label: 'Moderate', bg: '#FEF9C3', text: '#854d0e' },
    caution: { label: 'Caution', bg: '#FFEDD5', text: '#9a3412' },
    anomaly: { label: 'Anomaly', bg: '#FEE2E2', text: '#991b1b' },
    critical: { label: 'Critical', bg: '#FEE2E2', text: '#7f1d1d' }
  }[status]
  return (
    <span className="rounded-full px-2 py-0.5 font-medium" style={{ background: config.bg, color: config.text, fontSize: 10 }}>
      {config.label}
    </span>
  )
}

// ── Data Provenance Footer ─────────────────────────────────────────────────────
export function ProvenanceTag({ source, updated, variable, unit }: { source: string; updated: string; variable: string; unit: string }) {
  return (
    <div className="flex items-center gap-3 mt-2 pt-2 border-t flex-wrap" style={{ borderColor: '#F1F5F9' }}>
      <span style={{ fontSize: 9, color: '#94A3B8' }}>Source: <span style={{ color: '#64748B' }}>{source}</span></span>
      <span style={{ fontSize: 9, color: '#94A3B8' }}>Updated: <span style={{ color: '#64748B' }}>{updated}</span></span>
      <span style={{ fontSize: 9, color: '#94A3B8' }}>{variable} · {unit}</span>
    </div>
  )
}

// ── Ocean Map SVG ─────────────────────────────────────────────────────────────
export function OceanMapSVG({ layer = 'SST', showSelection = false, height = 280 }: { layer?: string; showSelection?: boolean; height?: number }) {
  const gradientId = `grad-${layer}`
  return (
    <svg width="100%" height={height} viewBox="0 0 340 280" preserveAspectRatio="xMidYMid slice" style={{ borderRadius: 12 }}>
      <defs>
        <radialGradient id={gradientId} cx="60%" cy="50%" r="70%">
          {layer === 'SST' && <>
            <stop offset="0%" stopColor="#F44336" stopOpacity="0.85" />
            <stop offset="30%" stopColor="#FF9800" stopOpacity="0.75" />
            <stop offset="60%" stopColor="#FFEB3B" stopOpacity="0.6" />
            <stop offset="80%" stopColor="#4CAF50" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#2196F3" stopOpacity="0.4" />
          </>}
          {layer === 'Chlorophyll-a' && <>
            <stop offset="0%" stopColor="#1B5E20" stopOpacity="0.85" />
            <stop offset="40%" stopColor="#4CAF50" stopOpacity="0.7" />
            <stop offset="70%" stopColor="#81D4FA" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#E3F2FD" stopOpacity="0.3" />
          </>}
          {layer === 'Currents' && <>
            <stop offset="0%" stopColor="#1565C0" stopOpacity="0.7" />
            <stop offset="50%" stopColor="#42A5F5" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#90CAF9" stopOpacity="0.3" />
          </>}
          {!['SST','Chlorophyll-a','Currents'].includes(layer) && <>
            <stop offset="0%" stopColor="#0060A8" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#90CAF9" stopOpacity="0.3" />
          </>}
        </radialGradient>
        <clipPath id="map-clip">
          <rect x="0" y="0" width="340" height="280" rx="12" />
        </clipPath>
      </defs>
      {/* Ocean background */}
      <rect width="340" height="280" fill="#1565C0" rx="12" />
      <rect width="340" height="280" fill="#0D47A1" opacity="0.5" />
      {/* Ocean gradient overlay */}
      <rect width="340" height="280" fill={`url(#${gradientId})`} clipPath="url(#map-clip)" />
      {/* India west coast outline - simplified */}
      <path
        d="M 200 0 L 205 20 L 210 40 L 208 60 L 212 80 L 210 100 L 215 120 L 213 140 L 218 160 L 216 180 L 220 200 L 218 220 L 215 240 L 220 260 L 225 280 L 340 280 L 340 0 Z"
        fill="#5D7A4A"
        opacity="0.85"
      />
      {/* Coastline details */}
      <path
        d="M 195 0 L 200 20 L 204 40 L 202 60 L 206 80 L 204 100 L 209 120 L 207 140 L 212 160 L 210 180 L 214 200 L 212 220 L 209 240 L 213 260 L 218 280"
        fill="none"
        stroke="#8BC34A"
        strokeWidth="1.5"
        opacity="0.6"
      />
      {/* Depth lines */}
      <line x1="180" y1="0" x2="175" y2="280" stroke="#1976D2" strokeWidth="0.5" strokeDasharray="4,4" opacity="0.4" />
      <line x1="140" y1="0" x2="135" y2="280" stroke="#1976D2" strokeWidth="0.5" strokeDasharray="4,4" opacity="0.3" />
      {/* Selection box */}
      {showSelection && (
        <rect x="100" y="80" width="90" height="80" fill="none" stroke="#00BDEA" strokeWidth="2" strokeDasharray="6,3" rx="4" />
      )}
      {/* City markers */}
      <circle cx="203" cy="82" r="4" fill="#fff" stroke="#00BDEA" strokeWidth="1.5" />
      <text x="186" y="78" fill="white" fontSize="9" fontWeight="600" fontFamily="Inter">Mumbai</text>
      <circle cx="207" cy="152" r="3.5" fill="#fff" stroke="#00BDEA" strokeWidth="1.5" />
      <text x="175" y="148" fill="white" fontSize="8.5" fontWeight="500" fontFamily="Inter">Ratnagiri</text>
      <circle cx="212" cy="218" r="3.5" fill="#fff" stroke="#00BDEA" strokeWidth="1.5" />
      <text x="198" y="213" fill="white" fontSize="8.5" fontWeight="500" fontFamily="Inter">Goa</text>
      {/* Scale indicator */}
      <line x1="20" y1="264" x2="70" y2="264" stroke="white" strokeWidth="1.5" opacity="0.7" />
      <text x="25" y="274" fill="white" fontSize="7" opacity="0.7" fontFamily="Inter">100 km</text>
    </svg>
  )
}

// ── Map Controls ─────────────────────────────────────────────────────────────
export function MapControls() {
  return (
    <div className="absolute right-3 top-1/3 flex flex-col gap-1.5">
      {['+', '−', '⊕'].map((icon, i) => (
        <button
          key={i}
          className="w-8 h-8 rounded-lg flex items-center justify-center shadow-md font-bold"
          style={{ background: 'rgba(255,255,255,0.92)', color: '#1565C0', fontSize: i < 2 ? 18 : 14 }}
        >
          {icon}
        </button>
      ))}
    </div>
  )
}

// ── SST Color Bar ─────────────────────────────────────────────────────────────
export function SSTColorBar({ min = 24, max = 32, unit = '°C', label = 'SST' }: { min?: number; max?: number; unit?: string; label?: string }) {
  return (
    <div className="flex flex-col items-center gap-1" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)' }}>
      <span style={{ fontSize: 8, color: 'white', fontWeight: 600, writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>{label} ({unit})</span>
      <div style={{ width: 10, height: 100, background: 'linear-gradient(to bottom, #F44336, #FF9800, #FFEB3B, #4CAF50, #2196F3)', borderRadius: 3 }} />
      <span style={{ fontSize: 8, color: 'white' }}>{max}</span>
      <span style={{ fontSize: 8, color: 'white', marginTop: 60, position: 'absolute', top: 85 }}>{min}</span>
    </div>
  )
}
