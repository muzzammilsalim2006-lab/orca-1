import { useState } from "react"

type Lang = "en" | "hi" | "mr"
type Screen =
  | "splash"
  | "location-perm"
  | "location-detected"
  | "home"
  | "map"
  | "trip-planner"
  | "mission"
  | "why-route"
  | "orca-ai"
  | "orca-response"
  | "alerts"
  | "emergency"

// ─── Translations ────────────────────────────────────────────────────────────
const T: Record<Lang, Record<string, string>> = {
  en: {
    appSubtitle: "AI-Powered Marine Safety for Fishermen",
    getStarted: "Get Started →",
    enableLocation: "Enable Your Location",
    locationDesc:
      "ORCA needs your location to show nearby marine conditions, fishing opportunities and safety alerts.",
    useMyLocation: "Use My Location",
    selectManually: "Select Location Manually",
    locationPrivacy: "Your location is only used for marine safety and will not be shared.",
    locationFound: "Location Found!",
    locationCity: "Kochi, Kerala",
    accuracy: "Accuracy: Good (± 10 m)",
    continueBtn: "Continue →",
    greeting: "Good Morning, Ramesh! 👋",
    locationLabel: "📍 Kochi, Kerala • 28 Sep 2026",
    safetyStatus: "LOW RISK",
    safetyDesc: "Sea is safe today",
    waveHeight: "Wave Height",
    windSpeed: "Wind Speed",
    rainChance: "Rain",
    seaTemp: "Sea Temp",
    pfzTitle: "Fishing Opportunity (PFZ)",
    pfzScore: "High  87/100",
    pfzDistance: "Nearest PFZ: 18 km",
    planTrip: "Plan Fishing Trip",
    askOrca: "🎙 Ask ORCA",
    noWarning: "No active high-severity warning",
    home: "Home",
    map: "Map",
    mission: "Mission",
    alerts: "Alerts",
    orcaAI: "ORCA AI",
    search: "Search location (e.g. Kochi, Alibag)",
    layerPFZ: "PFZ",
    layerSafety: "Safety",
    layerWind: "Wind",
    layerWave: "Wave",
    layerMPA: "MPA",
    layerRestricted: "Restricted",
    layerIMBL: "IMBL",
    pfzSheet: "PFZ-01 — High Opportunity",
    pfzOpportunity: "Opportunity",
    pfzWave: "Wave",
    pfzWind: "Wind",
    pfzDist: "Distance",
    planRoute: "Plan Route",
    viewDetails: "View Details",
    tripTitle: "Plan Fishing Trip",
    stepLocation: "Location",
    stepDate: "Date & Time",
    stepDuration: "Duration",
    stepVessel: "Vessel",
    stepPriority: "Priority",
    locationValue: "Kochi, Kerala (Current Location)",
    dateValue: "29 Sep 2026",
    timeValue: "05:00 AM",
    durationValue: "6 hours",
    vesselValue: "Traditional Motorized Craft (< 10m)",
    prioritySafety: "Safety",
    priorityFishing: "Fishing",
    priorityFuel: "Fuel",
    planWithOrca: "Ask ORCA to Plan →",
    missionTitle: "Route Recommendation",
    routeRecommended: "Route B Recommended",
    routeSubtitle: "Best balanced route",
    confidence: "Confidence",
    routeA: "Route A",
    routeB: "Route B",
    routeC: "Route C",
    safe: "Safe",
    balanced: "Balanced",
    fishing: "Fishing",
    safety: "Safety",
    fuel: "Fuel",
    routeInfo: "Route B — 32 km • 5h 40m",
    startMission: "Start Mission →",
    viewMap: "View Map",
    whyRoute: "Why This Route?",
    whatIf: "What If?",
    whyTitle: "Why This Route?",
    reason1: "High PFZ opportunity — excellent fishing zone",
    reason2: "Wave conditions within vessel limits — max wave 1.4 m",
    reason3: "Favourable wind — 17–22 km/h",
    reason4: "Outside restricted areas — clear of MPA and IMBL",
    reason5: "Low fuel consumption — 32 km round trip feasible",
    reason6: "No active severe weather warning from IMD",
    dataSources: "Data Sources",
    src1: "INCOIS PFZ",
    src2: "IMD Weather",
    src3: "Open-Meteo Ocean",
    highConfidence: "HIGH CONFIDENCE",
    orcaAITitle: "ORCA AI",
    orcaGreeting: "Good Morning, Ramesh!\nI'm your marine safety assistant.",
    chip1: "Is it safe to fish tomorrow?",
    chip2: "Find nearby PFZ",
    chip3: "Check my route",
    chip4: "Check weather",
    listening: "Listening...",
    speakLang: "Speak in English",
    typeHere: "Or type here...",
    userQ: "Is it safe to fish tomorrow morning?",
    orcaResp:
      "Tomorrow morning from 5 AM to 8 AM, conditions appear relatively safe for your vessel.",
    lowRiskBadge: "LOW RISK",
    waveRange: "1.1–1.4 m",
    windRange: "15–22 km/h",
    rainPct: "20%",
    warningNone: "None",
    safeNote: "Safe for small boats (< 10m)",
    seeDetails: "See Details",
    alertsTitle: "Alerts",
    tabAll: "All (3)",
    tabImportant: "Important (1)",
    tabEnded: "Ended (1)",
    alert1Title: "Strong wind warning",
    alert1Desc: "Wind expected to increase to 38–45 km/h by evening.",
    alert1Time: "1 hour ago",
    alert2Title: "Wave conditions deteriorating",
    alert2Desc:
      "Wave height on your planned return route increased to 3.1 m.",
    alert2Time: "3 hours ago",
    alert3Title: "New PFZ Available",
    alert3Desc: "A new PFZ has been identified near your area.",
    alert3Time: "5 hours ago",
    viewNewRoute: "View New Route",
    emergencyTitle: "Emergency Help",
    sos: "SOS",
    sosLabel: "Request Immediate Help",
    shareLocation: "Share My Location",
    findSafeHarbour: "Find Safe Harbour",
    calculateDrift: "Calculate Drift",
    contactCoastGuard: "Important Contacts",
    coordsLabel: "Current Coordinates",
    coords: "9.9312° N, 76.2673° E",
    lastSaved: "Last location saved",
    emergencyWarning:
      "Use this only in genuine emergencies. Do not use irresponsibly.",
    langName: "English",
  },
  hi: {
    appSubtitle: "मछुआरों के लिए AI-संचालित समुद्री सुरक्षा",
    getStarted: "शुरू करें →",
    enableLocation: "अपना स्थान सक्षम करें",
    locationDesc:
      "ORCA को पास की समुद्री स्थिति, मछली पकड़ने के अवसर और सुरक्षा अलर्ट दिखाने के लिए आपके स्थान की आवश्यकता है।",
    useMyLocation: "मेरा स्थान उपयोग करें",
    selectManually: "स्थान मैन्युअल रूप से चुनें",
    locationPrivacy:
      "आपका स्थान केवल समुद्री सुरक्षा के लिए उपयोग किया जाता है।",
    locationFound: "स्थान मिल गया!",
    locationCity: "कोच्चि, केरल",
    accuracy: "सटीकता: अच्छी (± 10 मी)",
    continueBtn: "आगे बढ़ें →",
    greeting: "शुभ प्रभात, रमेश! 👋",
    locationLabel: "📍 कोच्चि, केरल • 28 सितंबर 2026",
    safetyStatus: "कम खतरा",
    safetyDesc: "आज समुद्र सुरक्षित है",
    waveHeight: "लहर ऊंचाई",
    windSpeed: "हवा गति",
    rainChance: "वर्षा",
    seaTemp: "समुद्र तापमान",
    pfzTitle: "मछली पकड़ने का अवसर (PFZ)",
    pfzScore: "उच्च  87/100",
    pfzDistance: "नजदीकी PFZ: 18 किमी",
    planTrip: "मछली पकड़ने की यात्रा योजना",
    askOrca: "🎙 ORCA से पूछें",
    noWarning: "कोई गंभीर चेतावनी नहीं",
    home: "होम",
    map: "नक्शा",
    mission: "मिशन",
    alerts: "अलर्ट",
    orcaAI: "ORCA AI",
    search: "स्थान खोजें",
    layerPFZ: "PFZ",
    layerSafety: "सुरक्षा",
    layerWind: "हवा",
    layerWave: "लहर",
    layerMPA: "MPA",
    layerRestricted: "प्रतिबंधित",
    layerIMBL: "IMBL",
    pfzSheet: "PFZ-01 — उच्च अवसर",
    pfzOpportunity: "अवसर",
    pfzWave: "लहर",
    pfzWind: "हवा",
    pfzDist: "दूरी",
    planRoute: "मार्ग योजना बनाएं",
    viewDetails: "विवरण देखें",
    tripTitle: "मछली पकड़ने की यात्रा",
    stepLocation: "स्थान",
    stepDate: "तारीख और समय",
    stepDuration: "अवधि",
    stepVessel: "नाव",
    stepPriority: "प्राथमिकता",
    locationValue: "कोच्चि, केरल (वर्तमान स्थान)",
    dateValue: "29 सितंबर 2026",
    timeValue: "05:00 पूर्वाह्न",
    durationValue: "6 घंटे",
    vesselValue: "पारंपरिक मोटर नाव (< 10मी)",
    prioritySafety: "सुरक्षा",
    priorityFishing: "मछली पकड़ना",
    priorityFuel: "ईंधन",
    planWithOrca: "ORCA से योजना बनाएं →",
    missionTitle: "मार्ग अनुशंसा",
    routeRecommended: "मार्ग B अनुशंसित है",
    routeSubtitle: "सर्वोत्तम संतुलित मार्ग",
    confidence: "विश्वास",
    routeA: "मार्ग A",
    routeB: "मार्ग B",
    routeC: "मार्ग C",
    safe: "सुरक्षित",
    balanced: "संतुलित",
    fishing: "मछली",
    safety: "सुरक्षा",
    fuel: "ईंधन",
    routeInfo: "मार्ग B — 32 किमी • 5घं 40मि",
    startMission: "मिशन शुरू करें →",
    viewMap: "नक्शा देखें",
    whyRoute: "यह मार्ग क्यों?",
    whatIf: "क्या होगा यदि?",
    whyTitle: "यह मार्ग क्यों?",
    reason1: "उच्च PFZ अवसर — उत्कृष्ट मछली पकड़ने का क्षेत्र",
    reason2: "लहर की स्थिति नाव की सीमा में — अधिकतम 1.4 मी",
    reason3: "अनुकूल हवा — 17–22 km/h",
    reason4: "प्रतिबंधित क्षेत्र के बाहर — MPA और IMBL से दूर",
    reason5: "कम ईंधन खपत — 32 किमी का चक्कर संभव",
    reason6: "IMD की ओर से कोई गंभीर मौसम चेतावनी नहीं",
    dataSources: "डेटा स्रोत",
    src1: "INCOIS PFZ",
    src2: "IMD हवामान",
    src3: "Open-Meteo समुद्र",
    highConfidence: "उच्च विश्वास",
    orcaAITitle: "ORCA AI",
    orcaGreeting: "शुभ प्रभात, रमेश!\nमैं आपका समुद्री सुरक्षा सहायक हूं।",
    chip1: "क्या कल मछली पकड़ना सुरक्षित है?",
    chip2: "नजदीकी PFZ खोजें",
    chip3: "मेरा मार्ग जांचें",
    chip4: "मौसम जांचें",
    listening: "सुन रहा हूं...",
    speakLang: "हिंदी में बोलें",
    typeHere: "यहां टाइप करें...",
    userQ: "क्या कल सुबह मछली पकड़ना सुरक्षित है?",
    orcaResp:
      "कल सुबह 5 से 8 बजे तक, स्थिति आपकी नाव के लिए अपेक्षाकृत सुरक्षित दिखती है।",
    lowRiskBadge: "कम खतरा",
    waveRange: "1.1–1.4 मी",
    windRange: "15–22 km/h",
    rainPct: "20%",
    warningNone: "कोई नहीं",
    safeNote: "छोटी नाव (< 10मी) के लिए सुरक्षित",
    seeDetails: "विवरण देखें",
    alertsTitle: "सूचनाएं",
    tabAll: "सभी (3)",
    tabImportant: "महत्वपूर्ण (1)",
    tabEnded: "समाप्त (1)",
    alert1Title: "तेज हवा की चेतावनी",
    alert1Desc: "शाम तक हवा 38–45 km/h तक बढ़ने की उम्मीद।",
    alert1Time: "1 घंटे पहले",
    alert2Title: "लहर की स्थिति बिगड़ रही है",
    alert2Desc: "नियोजित वापसी मार्ग पर लहर 3.1 मी हो गई।",
    alert2Time: "3 घंटे पहले",
    alert3Title: "नया PFZ उपलब्ध",
    alert3Desc: "आपके क्षेत्र के पास एक नया PFZ पहचाना गया।",
    alert3Time: "5 घंटे पहले",
    viewNewRoute: "नया मार्ग देखें",
    emergencyTitle: "आपातकालीन सहायता",
    sos: "SOS",
    sosLabel: "तत्काल सहायता मांगें",
    shareLocation: "मेरा स्थान साझा करें",
    findSafeHarbour: "सुरक्षित बंदरगाह खोजें",
    calculateDrift: "बहाव की गणना करें",
    contactCoastGuard: "महत्वपूर्ण संपर्क",
    coordsLabel: "वर्तमान निर्देशांक",
    coords: "9.9312° N, 76.2673° E",
    lastSaved: "अंतिम स्थान सहेजा गया",
    emergencyWarning:
      "इसका उपयोग केवल वास्तविक आपात स्थितियों में करें।",
    langName: "हिंदी",
  },
  mr: {
    appSubtitle: "मच्छीमारांसाठी AI-चालित समुद्री सुरक्षा",
    getStarted: "सुरुवात करा →",
    enableLocation: "तुमचे स्थान सक्षम करा",
    locationDesc:
      "ORCA ला जवळपासच्या समुद्री परिस्थिती, मासेमारीच्या संधी आणि सुरक्षा सूचना दाखवण्यासाठी तुमच्या स्थानाची आवश्यकता आहे.",
    useMyLocation: "माझे स्थान वापरा",
    selectManually: "स्थान स्वतः निवडा",
    locationPrivacy:
      "तुमचे स्थान फक्त समुद्री सुरक्षेसाठी वापरले जाईल.",
    locationFound: "स्थान सापडले!",
    locationCity: "कोची, केरळ",
    accuracy: "अचूकता: चांगली (± 10 मी)",
    continueBtn: "पुढे जा →",
    greeting: "शुभ सकाळ, रमेश! 👋",
    locationLabel: "📍 Kochi, Kerala • 28 सप्टेंबर 2026",
    safetyStatus: "कमी धोका",
    safetyDesc: "आज समुद्र सुरक्षित आहे",
    waveHeight: "लाट उंची",
    windSpeed: "वाऱ्याचा वेग",
    rainChance: "पाऊस",
    seaTemp: "समुद्र तापमान",
    pfzTitle: "मासेमारीची संधी (PFZ)",
    pfzScore: "उच्च  87/100",
    pfzDistance: "जवळचा PFZ: 18 किमी",
    planTrip: "मासेमारी सहल नियोजित करा",
    askOrca: "🎙 ORCA ला विचारा",
    noWarning: "कोणतीही गंभीर सूचना नाही",
    home: "मुख्यपृष्ठ",
    map: "नकाशा",
    mission: "सहल",
    alerts: "सूचना",
    orcaAI: "ORCA AI",
    search: "ठिकाण शोधा (उदा. Kochi, Alibag)",
    layerPFZ: "PFZ",
    layerSafety: "सुरक्षा",
    layerWind: "वारा",
    layerWave: "लाट",
    layerMPA: "MPA",
    layerRestricted: "प्रतिबंधित",
    layerIMBL: "IMBL",
    pfzSheet: "PFZ-01 — उच्च संधी",
    pfzOpportunity: "संधी",
    pfzWave: "लाट",
    pfzWind: "वारा",
    pfzDist: "अंतर",
    planRoute: "मार्ग नियोजित करा",
    viewDetails: "माहिती पहा",
    tripTitle: "मासेमारी सहल नियोजित करा",
    stepLocation: "ठिकाण",
    stepDate: "तारीख व वेळ",
    stepDuration: "किती वेळ?",
    stepVessel: "तुमची बोट",
    stepPriority: "प्राधान्य कोणत्या?",
    locationValue: "Kochi, Kerala (सध्याचे स्थान)",
    dateValue: "29 सप्टेंबर 2026",
    timeValue: "05:00 AM",
    durationValue: "6 तास",
    vesselValue: "Traditional Motorized Craft (< 10m)",
    prioritySafety: "सुरक्षा",
    priorityFishing: "मासेमारी",
    priorityFuel: "इंधन",
    planWithOrca: "ORCA ला योजना तयार करण्यास सांगा →",
    missionTitle: "प्रवास शिफारस",
    routeRecommended: "मार्ग B शिफारस केला आहे",
    routeSubtitle: "न्याहारी वाटाघाटीचा रस्ता",
    confidence: "विश्वास",
    routeA: "मार्ग A",
    routeB: "मार्ग B",
    routeC: "मार्ग C",
    safe: "सुरक्षित",
    balanced: "संतुलित",
    fishing: "मासेमारी",
    safety: "सुरक्षा",
    fuel: "इंधन",
    routeInfo: "मार्ग B — 32 किमी • 5तास 40मि",
    startMission: "हा मार्ग निवडा →",
    viewMap: "नकाशा पहा",
    whyRoute: "मार्ग B का?",
    whatIf: "जर...?",
    whyTitle: "मार्ग B का?",
    reason1: "PFZ मध्ये प्रवेश — उच्च मासेमारी संधी",
    reason2: "लाटा सुरक्षित मर्यादेत — कमाल लाट 1.4 मी",
    reason3: "वारा 17–22 km/h",
    reason4: "प्रतिबंधित क्षेत्र टाळलेले — MPA आणि IMBL पासून सुरक्षित अंतर",
    reason5: "इंधन वापर कमी — 32 किमी अंतर (परत येणे शक्य)",
    reason6: "IMD कोणत्याही मोठ्या दुर्घटनेसाठी हवामान सुरक्षित",
    dataSources: "डेटा स्रोत",
    src1: "INCOIS PFZ",
    src2: "IMD हवामान",
    src3: "Open-Meteo समुद्र शिपाई",
    highConfidence: "उच्च विश्वास",
    orcaAITitle: "ORCA AI",
    orcaGreeting:
      "शुभ सकाळ, रमेश!\nमी तुमचा समुद्री सुरक्षा सहायक आहे.",
    chip1: "उद्या मासेमारीला जाणे सुरक्षित आहे का?",
    chip2: "जवळचा PFZ शोवा",
    chip3: "माझा मार्ग तपासा",
    chip4: "समुद्र स्थिती कशी आहे?",
    listening: "ऐकत आहे...",
    speakLang: "मराठीत बोला",
    typeHere: "किंवा टाइप करा...",
    userQ: "उद्या मासेमारीला जाणे सुरक्षित आहे का?",
    orcaResp:
      "हो, उद्या सकाळी 5 ते 8 वाजेपर्यंत परिस्थिती तुमच्या बोटीसाठी सुरक्षित आहे.",
    lowRiskBadge: "कमी धोका",
    waveRange: "1.1–1.4 मी",
    windRange: "15–22 km/h",
    rainPct: "20%",
    warningNone: "कोणती नाही",
    safeNote: "लहान बोटीसाठी (< 10मी) प्रवास सुरक्षित आहे",
    seeDetails: "तपशील पहा",
    alertsTitle: "सूचना",
    tabAll: "सर्व (3)",
    tabImportant: "महत्वाचे (1)",
    tabEnded: "बंद होणे (1)",
    alert1Title: "उच्च प्रचंड वाऱ्याची शक्यता",
    alert1Desc:
      "उद्या संध्याकाळी वारा 38–45 km/h पर्यंत वाढू शकतो.",
    alert1Time: "1 तासापूर्वी",
    alert2Title: "लाटा वाढत्या आहेत",
    alert2Desc:
      "नियोजित परतीच्या मार्गावर लाटांची उंची 2.4 मी ते 3.1 मी पर्यंत वाढू शकते.",
    alert2Time: "3 तासापूर्वी",
    alert3Title: "नवीन PFZ उपलब्ध",
    alert3Desc: "तुमच्या परिसरात नवीन PFZ क्षेत्र आढळले आहे.",
    alert3Time: "5 तासापूर्वी",
    viewNewRoute: "नवीन मार्ग पहा",
    emergencyTitle: "आपत्कालीन मदत",
    sos: "SOS",
    sosLabel: "तत्काळ मदत मागवा",
    shareLocation: "माझे स्थान सेव्ह करा",
    findSafeHarbour: "सुरक्षित बंदर शोधा",
    calculateDrift: "समुद्र प्रवाह अंदाज (Drift)",
    contactCoastGuard: "महत्वाचे संपर्क",
    coordsLabel: "सध्याचे स्थान",
    coords: "9.9312° N, 76.2673° E",
    lastSaved: "शेवटचे स्थान सेव्ह झाले आहे",
    emergencyWarning:
      "हे Emergency फक्त खऱ्या परिस्थितीत वापरण्यास सांगतो. बेजबाबदारपणे वापर करू नका.",
    langName: "मराठी",
  },
}

// ─── Language Selector ────────────────────────────────────────────────────────
function LangSelector({
  lang,
  onChange,
  light = false,
}: {
  lang: Lang
  onChange: (l: Lang) => void
  light?: boolean
}) {
  const [open, setOpen] = useState(false)
  const labels: Record<Lang, string> = { en: "English", hi: "हिंदी", mr: "मराठी" }
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={`flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full border transition-all ${
          light
            ? "border-white/30 text-white bg-white/10"
            : "border-slate-200 text-slate-700 bg-white"
        }`}
      >
        <span className="text-sm">🌐</span>
        <span>{labels[lang]}</span>
        <span className="text-[10px]">▼</span>
      </button>
      {open && (
        <div className="absolute right-0 top-8 bg-white rounded-xl shadow-xl border border-slate-100 z-50 min-w-[110px] overflow-hidden">
          {(["en", "hi", "mr"] as Lang[]).map((l) => (
            <button
              key={l}
              onClick={() => { onChange(l); setOpen(false) }}
              className={`w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors ${
                lang === l ? "text-blue-600 font-semibold bg-blue-50" : "text-slate-700"
              }`}
            >
              {labels[l]}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Status Bar ───────────────────────────────────────────────────────────────
function StatusBar({ light = false }: { light?: boolean }) {
  return (
    <div className={`flex justify-between items-center px-5 pt-3 pb-1 text-xs font-semibold ${light ? "text-white" : "text-slate-800"}`}>
      <span>9:41</span>
      <div className="flex items-center gap-1">
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor">
          <rect x="0" y="6" width="3" height="6" rx="0.5" opacity="0.4"/>
          <rect x="4" y="4" width="3" height="8" rx="0.5" opacity="0.6"/>
          <rect x="8" y="2" width="3" height="10" rx="0.5" opacity="0.8"/>
          <rect x="12" y="0" width="3" height="12" rx="0.5"/>
        </svg>
        <svg width="16" height="12" viewBox="0 0 24 12" fill="currentColor">
          <path d="M12 3C8.8 3 5.9 4.4 3.9 6.7L2 5C4.5 2.1 8.1 0 12 0s7.5 2.1 10 5l-1.9 1.7C18.1 4.4 15.2 3 12 3z" opacity="0.4"/>
          <path d="M12 6c-2.2 0-4.2 1-5.6 2.6L4.5 7C6.4 4.8 9.1 3.5 12 3.5s5.6 1.3 7.5 3.5L17.6 8.6C16.2 7 14.2 6 12 6z" opacity="0.7"/>
          <circle cx="12" cy="10" r="2"/>
        </svg>
        <svg width="25" height="12" viewBox="0 0 25 12" fill="currentColor">
          <rect x="0" y="1" width="21" height="10" rx="2" stroke="currentColor" strokeWidth="1" fill="none" opacity="0.5"/>
          <rect x="21" y="4" width="2" height="4" rx="1" opacity="0.5"/>
          <rect x="1.5" y="2.5" width="17" height="7" rx="1.5"/>
        </svg>
      </div>
    </div>
  )
}

// ─── ORCA Logo ─────────────────────────────────────────────────────────────────
function OrcaLogo({ size = 56, white = false }: { size?: number; white?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" fill="none">
      <circle cx="28" cy="28" r="28" fill={white ? "rgba(255,255,255,0.15)" : "#1565C0"} />
      <path d="M14 28c0-7.7 6.3-14 14-14 5.2 0 9.7 2.8 12.1 7" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
      <path d="M28 42c-7.7 0-14-6.3-14-14" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
      <path d="M42 28c0 3.2-1.1 6.1-2.9 8.4" stroke="white" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
      <path d="M20 24c2-1.5 4.5-2.5 7.2-2.5 2 0 3.9.5 5.5 1.5" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none"/>
      <path d="M26 33c.6.3 1.3.5 2 .5s1.4-.2 2-.5" stroke="white" strokeWidth="2" strokeLinecap="round" fill="none"/>
      <circle cx="28" cy="28" r="3" fill="white" opacity="0.9"/>
      <path d="M40 22l3-4 1 5-4-1z" fill="white" opacity="0.7"/>
    </svg>
  )
}

// ─── Header ───────────────────────────────────────────────────────────────────
function Header({
  title,
  onBack,
  lang,
  onLangChange,
  center = false,
}: {
  title?: string
  onBack?: () => void
  lang: Lang
  onLangChange: (l: Lang) => void
  center?: boolean
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
      <div className="w-8">
        {onBack && (
          <button onClick={onBack} className="text-slate-600 hover:text-slate-900 transition-colors">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <path d="M19 12H5M12 5l-7 7 7 7"/>
            </svg>
          </button>
        )}
      </div>
      <div className={`flex-1 ${center ? "text-center" : ""}`}>
        {title ? (
          <span className="text-base font-bold text-slate-800">{title}</span>
        ) : (
          <span className="text-lg font-black text-[#0B1D35] tracking-tight">ORCA</span>
        )}
      </div>
      <LangSelector lang={lang} onChange={onLangChange} />
    </div>
  )
}

// ─── Bottom Navigation ────────────────────────────────────────────────────────
function BottomNav({
  current,
  onNav,
  t,
}: {
  current: string
  onNav: (s: Screen) => void
  t: Record<string, string>
}) {
  const items = [
    {
      key: "home",
      label: t.home,
      screen: "home" as Screen,
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
          <polyline points="9,22 9,12 15,12 15,22"/>
        </svg>
      ),
    },
    {
      key: "map",
      label: t.map,
      screen: "map" as Screen,
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/>
          <line x1="8" y1="2" x2="8" y2="18"/>
          <line x1="16" y1="6" x2="16" y2="22"/>
        </svg>
      ),
    },
    {
      key: "mission",
      label: t.mission,
      screen: "mission" as Screen,
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <polygon points="10 8 16 12 10 16 10 8"/>
        </svg>
      ),
    },
    {
      key: "alerts",
      label: t.alerts,
      screen: "alerts" as Screen,
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 01-3.46 0"/>
        </svg>
      ),
    },
    {
      key: "orca-ai",
      label: t.orcaAI,
      screen: "orca-ai" as Screen,
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2a9 9 0 110 18A9 9 0 0112 2z"/>
          <path d="M9 9h.01M15 9h.01M9.5 14s1 1.5 2.5 1.5 2.5-1.5 2.5-1.5"/>
        </svg>
      ),
    },
  ]
  return (
    <div className="flex items-center justify-around border-t border-slate-100 bg-white pt-2 pb-4">
      {items.map((item) => (
        <button
          key={item.key}
          onClick={() => onNav(item.screen)}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 transition-colors ${
            current === item.key
              ? "text-blue-600"
              : "text-slate-400"
          }`}
        >
          {item.icon}
          <span className="text-[10px] font-medium">{item.label}</span>
        </button>
      ))}
    </div>
  )
}

// ─── Ocean Map Visual ─────────────────────────────────────────────────────────
function OceanMap({
  showPFZ = false,
  onPFZTap,
  showRoute = false,
}: {
  showPFZ?: boolean
  onPFZTap?: () => void
  showRoute?: boolean
}) {
  return (
    <div className="relative w-full h-full overflow-hidden" style={{ background: "linear-gradient(160deg, #1a6b8a 0%, #1565C0 35%, #0d4f8a 65%, #0a3d6e 100%)" }}>
      {/* Land mass - right side (Kerala coast) */}
      <div className="absolute right-0 top-0 bottom-0 w-[35%]" style={{
        background: "linear-gradient(to left, #8B9E6E 0%, #7a9260 30%, transparent 100%)",
        clipPath: "polygon(30% 0, 100% 0, 100% 100%, 20% 100%, 15% 80%, 25% 60%, 10% 40%, 20% 20%)"
      }} />
      {/* Coastal detail */}
      <div className="absolute right-[28%] top-0 bottom-0 w-[8%]" style={{
        background: "rgba(139,158,110,0.3)",
        clipPath: "polygon(0 20%, 100% 0, 100% 100%, 0 80%)"
      }} />

      {/* Grid lines */}
      {[20, 40, 60, 80].map((pct) => (
        <div key={`h${pct}`} className="absolute inset-x-0" style={{ top: `${pct}%`, height: 1, background: "rgba(255,255,255,0.06)" }} />
      ))}
      {[20, 40, 60, 80].map((pct) => (
        <div key={`v${pct}`} className="absolute inset-y-0" style={{ left: `${pct}%`, width: 1, background: "rgba(255,255,255,0.06)" }} />
      ))}

      {/* PFZ zones */}
      {showPFZ && (
        <>
          {/* PFZ-01 green zone */}
          <button
            onClick={onPFZTap}
            className="absolute"
            style={{ left: "18%", top: "35%", transform: "translate(-50%, -50%)" }}
          >
            <div className="w-20 h-20 rounded-full flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(34,197,94,0.5) 0%, rgba(34,197,94,0.15) 70%, transparent 100%)" }}>
              <div className="w-10 h-10 rounded-full bg-green-400/70 flex items-center justify-center">
                <span className="text-[8px] font-bold text-white">PFZ-01</span>
              </div>
            </div>
          </button>

          {/* PFZ-02 yellow zone */}
          <div className="absolute" style={{ left: "35%", top: "20%", transform: "translate(-50%, -50%)" }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(234,179,8,0.5) 0%, rgba(234,179,8,0.15) 70%, transparent 100%)" }}>
              <div className="w-8 h-8 rounded-full bg-yellow-400/70 flex items-center justify-center">
                <span className="text-[7px] font-bold text-white">PFZ-02</span>
              </div>
            </div>
          </div>

          {/* Restricted/MPA zone (red) */}
          <div className="absolute" style={{ right: "38%", top: "55%", transform: "translate(50%, -50%)" }}>
            <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ background: "radial-gradient(circle, rgba(239,68,68,0.4) 0%, rgba(239,68,68,0.1) 70%, transparent 100%)" }}>
              <div className="w-7 h-7 rounded-full bg-red-400/70 flex items-center justify-center">
                <span className="text-[7px] font-bold text-white">MPA</span>
              </div>
            </div>
          </div>

          {/* Route line */}
          {showRoute && (
            <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: "none" }}>
              <path
                d="M 60 75% Q 30% 50% 18% 35%"
                stroke="#60A5FA"
                strokeWidth="2"
                strokeDasharray="6 4"
                fill="none"
              />
            </svg>
          )}
        </>
      )}

      {/* Current location marker */}
      <div className="absolute" style={{ left: "62%", top: "72%", transform: "translate(-50%, -50%)" }}>
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-blue-400/30 animate-pulse-ring" style={{ width: 32, height: 32, marginLeft: -6, marginTop: -6 }} />
          <div className="w-5 h-5 rounded-full bg-white border-2 border-blue-500 shadow-lg flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-blue-600" />
          </div>
        </div>
      </div>

      {/* Map controls */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col gap-1">
        <button className="w-8 h-8 rounded-lg bg-white/90 shadow flex items-center justify-center text-slate-600 text-sm font-bold hover:bg-white transition-colors">+</button>
        <button className="w-8 h-8 rounded-lg bg-white/90 shadow flex items-center justify-center text-slate-600 text-sm font-bold hover:bg-white transition-colors">−</button>
      </div>

      {/* Current location button */}
      <div className="absolute right-3 bottom-3">
        <button className="w-8 h-8 rounded-lg bg-white/90 shadow flex items-center justify-center">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1565C0" strokeWidth="2.5">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>
          </svg>
        </button>
      </div>
    </div>
  )
}

// ─── Screen 1: Splash ─────────────────────────────────────────────────────────
function SplashScreen({ t, lang, onLangChange, onNext }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onNext: () => void }) {
  return (
    <div className="relative flex flex-col h-full text-white" style={{ background: "linear-gradient(180deg, #0a1628 0%, #0d2b50 30%, #0f3d6e 60%, #0a2850 100%)" }}>
      {/* Ocean image */}
      <img
        src="https://images.unsplash.com/photo-1592132886027-b7bbc39a22e5?w=800&h=1200&fit=crop&auto=format"
        alt="Fishing boat at sunset"
        className="absolute inset-0 w-full h-full object-cover"
        style={{ opacity: 0.45 }}
      />
      {/* Gradient overlay */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(10,22,40,0.4) 0%, rgba(10,22,40,0.2) 40%, rgba(10,22,40,0.85) 75%, rgba(10,22,40,0.97) 100%)" }} />

      <StatusBar light />
      {/* Lang selector top right */}
      <div className="relative z-10 flex justify-end px-4 pt-1">
        <LangSelector lang={lang} onChange={onLangChange} light />
      </div>

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center justify-center flex-1 px-6">
        <OrcaLogo size={80} white />
        <h1 className="mt-4 text-5xl font-black tracking-tight" style={{ textShadow: "0 2px 20px rgba(0,0,0,0.5)" }}>ORCA</h1>
        <p className="mt-2 text-center text-sm font-medium text-blue-200 leading-relaxed max-w-[220px]">{t.appSubtitle}</p>
        {/* Dots */}
        <div className="flex gap-2 mt-6">
          <div className="w-2 h-2 rounded-full bg-white" />
          <div className="w-2 h-2 rounded-full bg-white/40" />
          <div className="w-2 h-2 rounded-full bg-white/40" />
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="relative z-10 px-6 pb-10">
        <button
          onClick={onNext}
          className="w-full py-4 rounded-2xl font-bold text-base text-white shadow-2xl transition-transform active:scale-95"
          style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}
        >
          {t.getStarted}
        </button>
        <div className="mt-4 flex items-center gap-2 justify-center opacity-60">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.1 2 5 5.1 5 9c0 5.2 7 13 7 13s7-7.8 7-13c0-3.9-3.1-7-7-7zm0 9.5c-1.4 0-2.5-1.1-2.5-2.5S10.6 6.5 12 6.5s2.5 1.1 2.5 2.5S13.4 11.5 12 11.5z"/></svg>
          <span className="text-xs">Oceanic Resource & Coastal Advisory Assistant</span>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 2: Location Permission ───────────────────────────────────────────
function LocationPermScreen({ t, lang, onLangChange, onBack, onUseLocation, onManual }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onUseLocation: () => void; onManual: () => void }) {
  return (
    <div className="flex flex-col h-full bg-white">
      <StatusBar />
      <Header lang={lang} onLangChange={onLangChange} onBack={onBack} center />
      <div className="flex flex-col items-center flex-1 px-6 pt-8">
        {/* Location icon */}
        <div className="w-28 h-28 rounded-full flex items-center justify-center mb-6" style={{ background: "linear-gradient(135deg, #E3F2FD, #BBDEFB)" }}>
          <svg width="56" height="56" viewBox="0 0 24 24" fill="none">
            <path d="M12 2C8.1 2 5 5.1 5 9c0 5.2 7 13 7 13s7-7.8 7-13c0-3.9-3.1-7-7-7z" fill="#1565C0"/>
            <circle cx="12" cy="9" r="2.5" fill="white"/>
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-slate-800 text-center mb-3">{t.enableLocation}</h2>
        <p className="text-slate-500 text-center text-sm leading-relaxed mb-8 max-w-[280px]">{t.locationDesc}</p>

        {/* Benefit bullets */}
        <div className="w-full space-y-3 mb-8">
          {[
            { icon: "🌊", text: lang === "en" ? "Nearby marine conditions" : lang === "hi" ? "पास की समुद्री स्थिति" : "जवळपासच्या समुद्री परिस्थिती" },
            { icon: "🐟", text: lang === "en" ? "Fishing opportunities" : lang === "hi" ? "मछली पकड़ने के अवसर" : "मासेमारीच्या संधी" },
            { icon: "⚠️", text: lang === "en" ? "Safety alerts & warnings" : lang === "hi" ? "सुरक्षा अलर्ट" : "सुरक्षा सूचना" },
          ].map((b, i) => (
            <div key={i} className="flex items-center gap-3 bg-blue-50 rounded-xl px-4 py-3">
              <span className="text-xl">{b.icon}</span>
              <span className="text-sm font-medium text-slate-700">{b.text}</span>
            </div>
          ))}
        </div>

        <button
          onClick={onUseLocation}
          className="w-full py-4 rounded-2xl font-bold text-white text-base mb-3 transition-transform active:scale-95"
          style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}
        >
          📍 {t.useMyLocation}
        </button>
        <div className="text-xs text-slate-400 my-1">{lang === "en" ? "or" : lang === "hi" ? "या" : "किंवा"}</div>
        <button
          onClick={onManual}
          className="w-full py-4 rounded-2xl font-semibold text-slate-700 text-base border-2 border-slate-200 mb-6 hover:border-blue-300 transition-colors"
        >
          🔍 {t.selectManually}
        </button>

        <p className="text-[11px] text-slate-400 text-center flex items-start gap-1.5">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" className="mt-0.5 flex-shrink-0"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
          {t.locationPrivacy}
        </p>
      </div>
    </div>
  )
}

// ─── Screen 3: Location Detected ─────────────────────────────────────────────
function LocationDetectedScreen({ t, lang, onLangChange, onBack, onContinue }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onContinue: () => void }) {
  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      <Header lang={lang} onLangChange={onLangChange} onBack={onBack} center />
      {/* Map area */}
      <div className="relative flex-1">
        <OceanMap />
        {/* Info overlay */}
        <div className="absolute inset-x-0 bottom-0 bg-white rounded-t-3xl px-6 pt-6 pb-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800">{t.locationFound}</h2>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-xs font-medium text-green-600">{lang === "en" ? "GPS Active" : lang === "hi" ? "GPS सक्रिय" : "GPS सक्रिय"}</span>
              </div>
            </div>
          </div>
          <div className="bg-slate-50 rounded-2xl px-4 py-3 mb-4">
            <div className="flex items-center gap-2 mb-1">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#1565C0"><path d="M12 2C8.1 2 5 5.1 5 9c0 5.2 7 13 7 13s7-7.8 7-13c0-3.9-3.1-7-7-7zm0 9.5c-1.4 0-2.5-1.1-2.5-2.5S10.6 6.5 12 6.5s2.5 1.1 2.5 2.5S13.4 11.5 12 11.5z"/></svg>
              <span className="text-base font-bold text-slate-800">{t.locationCity}</span>
            </div>
            <span className="text-xs text-slate-500">{t.accuracy}</span>
          </div>
          <button
            onClick={onContinue}
            className="w-full py-4 rounded-2xl font-bold text-white text-base transition-transform active:scale-95"
            style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}
          >
            {t.continueBtn}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 4: Home Dashboard ─────────────────────────────────────────────────
function HomeScreen({ t, lang, onLangChange, onNav, onPlanTrip, onAskOrca }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onNav: (s: Screen) => void; onPlanTrip: () => void; onAskOrca: () => void }) {
  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[#1565C0] flex items-center justify-center">
            <span className="text-white text-xs font-bold">R</span>
          </div>
          <span className="text-lg font-black text-[#0B1D35]">ORCA</span>
        </div>
        <div className="flex items-center gap-3">
          <LangSelector lang={lang} onChange={onLangChange} />
          <button className="relative">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
            <div className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-3">
          {/* Greeting */}
          <div className="mb-4">
            <h2 className="text-lg font-bold text-slate-800">{t.greeting}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.locationLabel}</p>
          </div>

          {/* Safety Status Card */}
          <button onClick={() => onNav("mission")} className="w-full mb-3">
            <div className="rounded-2xl p-4 flex items-center justify-between shadow-sm" style={{ background: "linear-gradient(135deg, #16A34A, #15803D)" }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div className="text-left">
                  <p className="text-green-100 text-xs font-medium">{t.safetyDesc}</p>
                  <p className="text-white text-2xl font-black">{t.safetyStatus}</p>
                </div>
              </div>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          </button>

          {/* Marine Metrics */}
          <div className="grid grid-cols-4 gap-2 mb-3">
            {[
              { icon: "🌊", label: t.waveHeight, value: "1.2 m", sub: lang === "en" ? "Safe" : lang === "hi" ? "सुरक्षित" : "सुरक्षित" },
              { icon: "💨", label: t.windSpeed, value: "18 km/h", sub: lang === "en" ? "Moderate" : lang === "hi" ? "मध्यम" : "मध्यम" },
              { icon: "🌧", label: t.rainChance, value: "20%", sub: lang === "en" ? "Low" : lang === "hi" ? "कम" : "कमी" },
              { icon: "🌡", label: t.seaTemp, value: "29.1°C", sub: lang === "en" ? "Warm" : lang === "hi" ? "गर्म" : "उबदार" },
            ].map((m, i) => (
              <div key={i} className="bg-white rounded-xl p-2.5 text-center shadow-sm">
                <div className="text-xl mb-1">{m.icon}</div>
                <div className="text-[11px] text-slate-500 leading-tight mb-1">{m.label}</div>
                <div className="text-xs font-bold text-slate-800">{m.value}</div>
                <div className="text-[9px] text-slate-400">{m.sub}</div>
              </div>
            ))}
          </div>

          {/* PFZ Card */}
          <div className="bg-white rounded-2xl p-4 mb-3 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xl">🐟</span>
              <span className="text-sm font-bold text-slate-700">{t.pfzTitle}</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-black text-blue-600">{lang === "en" ? "High" : lang === "hi" ? "उच्च" : "उच्च"}</div>
                <div className="text-xs text-slate-500">87 / 100</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500 mb-1">{t.pfzDistance}</div>
                <div className="h-2 w-28 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full bg-blue-500" style={{ width: "87%" }} />
                </div>
              </div>
            </div>
          </div>

          {/* CTAs */}
          <button
            onClick={onPlanTrip}
            className="w-full py-3.5 rounded-2xl font-bold text-white text-sm mb-2.5 transition-transform active:scale-95"
            style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}
          >
            {t.planTrip}
          </button>
          <button
            onClick={onAskOrca}
            className="w-full py-3.5 rounded-2xl font-bold text-slate-700 text-sm mb-3 border-2 border-slate-200 hover:border-blue-300 transition-colors flex items-center justify-center gap-2"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1565C0" strokeWidth="2.5" strokeLinecap="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg>
            {t.askOrca}
          </button>

          {/* No warning */}
          <div className="flex items-center gap-2 bg-green-50 border border-green-100 rounded-xl px-3 py-2.5">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            <span className="text-xs text-green-700 font-medium">{t.noWarning}</span>
          </div>
        </div>
      </div>
      <BottomNav current="home" onNav={onNav} t={t} />
    </div>
  )
}

// ─── Screen 5: Marine Map ─────────────────────────────────────────────────────
function MapScreen({ t, lang, onLangChange, onNav, onPFZSheet, showSheet, onCloseSheet, onPlanRoute }: {
  t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void;
  onNav: (s: Screen) => void; onPFZSheet: () => void; showSheet: boolean;
  onCloseSheet: () => void; onPlanRoute: () => void
}) {
  const [activeLayer, setActiveLayer] = useState("PFZ")
  const layers = [t.layerPFZ, t.layerSafety, t.layerWind, t.layerWave, t.layerMPA, t.layerRestricted, t.layerIMBL]
  return (
    <div className="flex flex-col h-full">
      <StatusBar />
      {/* Search */}
      <div className="flex items-center gap-2 px-3 py-2 bg-white border-b border-slate-100">
        <div className="flex-1 flex items-center gap-2 bg-slate-100 rounded-xl px-3 py-2.5">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <span className="text-xs text-slate-400">{t.search}</span>
        </div>
        <LangSelector lang={lang} onChange={onLangChange} />
      </div>
      {/* Layer chips */}
      <div className="flex gap-1.5 px-3 py-2 bg-white border-b border-slate-100 overflow-x-auto">
        {layers.map((l) => (
          <button
            key={l}
            onClick={() => setActiveLayer(l)}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
              activeLayer === l
                ? "bg-blue-600 text-white"
                : "bg-slate-100 text-slate-600"
            }`}
          >
            {l}
          </button>
        ))}
      </div>
      {/* Map */}
      <div className="relative flex-1">
        <OceanMap showPFZ onPFZTap={onPFZSheet} showRoute />
        {/* Layers button */}
        <div className="absolute left-3 top-3">
          <button className="flex items-center gap-1 bg-white/90 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-600 shadow">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>
            {t.layers}
          </button>
        </div>
      </div>

      {/* PFZ Bottom Sheet */}
      {showSheet && (
        <div className="absolute inset-x-0 bottom-0 bg-white rounded-t-3xl shadow-2xl px-4 pt-4 pb-6 z-20 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-800">{t.pfzSheet}</h3>
              <span className="text-xs font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">{lang === "en" ? "ACTIVE" : lang === "hi" ? "सक्रिय" : "सक्रिय"}</span>
            </div>
            <button onClick={onCloseSheet} className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">✕</button>
          </div>
          <div className="grid grid-cols-4 gap-2 mb-4">
            {[
              { label: t.pfzOpportunity, value: "91/100", color: "text-green-600" },
              { label: t.pfzWave, value: "1.3 m", color: "text-blue-600" },
              { label: t.pfzWind, value: "18 km", color: "text-slate-700" },
              { label: t.pfzDist, value: "22 km", color: "text-slate-700" },
            ].map((m, i) => (
              <div key={i} className="bg-slate-50 rounded-xl p-2.5 text-center">
                <div className={`text-sm font-black ${m.color}`}>{m.value}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{m.label}</div>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={onPlanRoute} className="flex-1 py-3 rounded-xl font-bold text-white text-sm" style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}>{t.planRoute}</button>
            <button className="flex-1 py-3 rounded-xl font-bold text-slate-700 text-sm border-2 border-slate-200">{t.viewDetails}</button>
          </div>
        </div>
      )}
      <BottomNav current="map" onNav={onNav} t={t} />
    </div>
  )
}

// ─── Screen 6: Trip Planner ───────────────────────────────────────────────────
function TripPlannerScreen({ t, lang, onLangChange, onBack, onPlan }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onPlan: () => void }) {
  const [priority, setPriority] = useState("safety")
  const [duration, setDuration] = useState(6)
  const steps = [
    { num: 1, label: t.stepLocation, value: t.locationValue, chevron: true },
    { num: 2, label: t.stepDate, value: `${t.dateValue}  •  ${t.timeValue}`, chevron: false },
    { num: 3, label: t.stepDuration, value: null, chevron: false },
    { num: 4, label: t.stepVessel, value: t.vesselValue, chevron: true },
  ]
  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      <Header title={t.tripTitle} onBack={onBack} lang={lang} onLangChange={onLangChange} />
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {steps.map((s) => (
          <div key={s.num} className="bg-white rounded-2xl px-4 py-3.5 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white text-xs font-bold">{s.num}</span>
              </div>
              <div className="flex-1">
                <div className="text-xs text-slate-500 font-medium mb-1">{s.label}</div>
                {s.num === 3 ? (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-slate-800">{duration} {lang === "en" ? "hours" : lang === "hi" ? "घंटे" : "तास"}</span>
                      <span className="text-xs text-blue-600 font-semibold">{duration * 60} {lang === "en" ? "min" : lang === "hi" ? "मिनट" : "मिनिट"}</span>
                    </div>
                    <input
                      type="range" min={2} max={12} value={duration}
                      onChange={(e) => setDuration(Number(e.target.value))}
                      className="w-full h-1.5 bg-blue-100 rounded-full appearance-none cursor-pointer"
                      style={{ accentColor: "#1565C0" }}
                    />
                    <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                      <span>2h</span><span>6h</span><span>12h</span>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-800 leading-snug">{s.value}</span>
                    {s.chevron && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        {/* Priority selector */}
        <div className="bg-white rounded-2xl px-4 py-3.5 shadow-sm">
          <div className="flex items-start gap-3">
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-xs font-bold">5</span>
            </div>
            <div className="flex-1">
              <div className="text-xs text-slate-500 font-medium mb-2">{t.stepPriority}</div>
              <div className="flex gap-2">
                {[
                  { key: "safety", icon: "🛡", label: t.prioritySafety },
                  { key: "fishing", icon: "🐟", label: t.priorityFishing },
                  { key: "fuel", icon: "⛽", label: t.priorityFuel },
                ].map((p) => (
                  <button
                    key={p.key}
                    onClick={() => setPriority(p.key)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 transition-colors ${
                      priority === p.key
                        ? "bg-blue-600 text-white"
                        : "bg-slate-100 text-slate-600"
                    }`}
                  >
                    <span className="text-lg">{p.icon}</span>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 pb-6 pt-3 bg-white border-t border-slate-100">
        <button
          onClick={onPlan}
          className="w-full py-4 rounded-2xl font-bold text-white text-sm transition-transform active:scale-95"
          style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}
        >
          {t.planWithOrca}
        </button>
      </div>
    </div>
  )
}

// ─── Screen 7: Mission Recommendation ────────────────────────────────────────
function MissionScreen({ t, lang, onLangChange, onBack, onNav, onWhyRoute, onStartMission }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onNav: (s: Screen) => void; onWhyRoute: () => void; onStartMission: () => void }) {
  const [selectedRoute, setSelectedRoute] = useState("B")
  const routes = [
    { key: "A", label: t.routeA, sub: t.safe, safety: 96, fishing: 72, fuel: 89, color: "text-blue-600", bg: "bg-blue-50" },
    { key: "B", label: t.routeB, sub: t.balanced, safety: 92, fishing: 87, fuel: 81, color: "text-green-600", bg: "bg-green-50", recommended: true },
    { key: "C", label: t.routeC, sub: t.fishing, safety: 61, fishing: 97, fuel: 75, color: "text-orange-600", bg: "bg-orange-50" },
  ]
  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      <Header title={t.missionTitle} onBack={onBack} lang={lang} onLangChange={onLangChange} />
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {/* Recommended banner */}
        <div className="rounded-2xl p-4 text-white" style={{ background: "linear-gradient(135deg, #16A34A, #15803D)" }}>
          <div className="flex items-center gap-2 mb-1">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            <span className="font-bold">{t.routeRecommended}</span>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-green-100 text-xs">{t.routeSubtitle}</p>
            <div className="flex items-center gap-1.5 bg-white/20 rounded-full px-2.5 py-1">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              <span className="text-white text-xs font-bold">{t.confidence} 88%</span>
            </div>
          </div>
        </div>

        {/* Route comparison */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="grid grid-cols-4 border-b border-slate-100">
            <div className="py-2.5 px-3" />
            {routes.map((r) => (
              <button
                key={r.key}
                onClick={() => setSelectedRoute(r.key)}
                className={`py-2.5 text-center border-b-2 transition-colors ${selectedRoute === r.key ? "border-blue-500" : "border-transparent"}`}
              >
                <div className={`text-xs font-bold ${r.color}`}>{r.label}</div>
                <div className="text-[10px] text-slate-400">{r.sub}</div>
                {r.recommended && <div className="text-[9px] bg-green-100 text-green-600 rounded-full px-1 font-semibold mt-0.5">★ {lang === "en" ? "Best" : lang === "hi" ? "सर्वोत्तम" : "उत्तम"}</div>}
              </button>
            ))}
          </div>
          {[
            { label: t.safety, key: "safety" as const },
            { label: t.fishing, key: "fishing" as const },
            { label: t.fuel, key: "fuel" as const },
          ].map((row) => (
            <div key={row.key} className="grid grid-cols-4 border-b border-slate-50">
              <div className="py-3 px-3 text-xs text-slate-500 font-medium">{row.label}</div>
              {routes.map((r) => (
                <div key={r.key} className={`py-3 text-center ${selectedRoute === r.key ? r.bg : ""}`}>
                  <span className={`text-sm font-black ${r.color}`}>{r[row.key]}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Map preview */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="h-32 relative">
            <OceanMap showPFZ showRoute />
          </div>
          <div className="px-4 py-2.5 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">{t.routeInfo}</span>
            <button onClick={() => onNav("map")} className="text-xs text-blue-600 font-semibold">{t.viewMap}</button>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2">
          <button onClick={onWhyRoute} className="flex-1 py-3 rounded-xl font-semibold text-slate-700 text-xs border-2 border-slate-200">
            {t.whyRoute}
          </button>
          <button className="flex-1 py-3 rounded-xl font-semibold text-slate-700 text-xs border-2 border-slate-200">
            {t.whatIf}
          </button>
        </div>
      </div>

      <div className="px-4 pb-6 pt-3 bg-white border-t border-slate-100">
        <button
          onClick={onStartMission}
          className="w-full py-4 rounded-2xl font-bold text-white text-sm transition-transform active:scale-95"
          style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}
        >
          {t.startMission}
        </button>
      </div>
    </div>
  )
}

// ─── Screen 8: Why This Route ─────────────────────────────────────────────────
function WhyRouteScreen({ t, lang, onLangChange, onBack }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void }) {
  const reasons = [t.reason1, t.reason2, t.reason3, t.reason4, t.reason5, t.reason6]
  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      <Header title={t.whyTitle} onBack={onBack} lang={lang} onLangChange={onLangChange} />
      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="bg-white rounded-2xl shadow-sm p-4 mb-4 space-y-3">
          {reasons.map((r, i) => (
            <div key={i} className="flex items-start gap-3">
              <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth="3.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <p className="text-sm text-slate-700 leading-snug">{r}</p>
            </div>
          ))}
        </div>

        {/* Data sources */}
        <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
          <p className="text-xs font-bold text-slate-500 mb-3">{t.dataSources}</p>
          <div className="flex gap-2">
            {[t.src1, t.src2, t.src3].map((s) => (
              <div key={s} className="flex-1 bg-blue-50 rounded-xl px-2 py-2 text-center">
                <div className="text-[10px] font-semibold text-blue-700 leading-tight">{s}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Confidence */}
        <div className="rounded-2xl p-4 text-white text-center" style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}>
          <div className="text-5xl font-black mb-1">88%</div>
          <div className="text-blue-100 text-sm font-bold tracking-widest">{t.highConfidence}</div>
          <div className="mt-2 flex justify-center gap-1">
            {[1,2,3,4,5].map((s) => (
              <div key={s} className="h-1.5 w-8 rounded-full" style={{ background: s <= 4 ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.25)" }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 9: ORCA AI Voice ──────────────────────────────────────────────────
function OrcaAIScreen({ t, lang, onLangChange, onBack, onNav, onAskQuestion }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onNav: (s: Screen) => void; onAskQuestion: () => void }) {
  const [listening, setListening] = useState(false)
  const [inputText, setInputText] = useState("")

  const handleMic = () => {
    setListening(true)
    setTimeout(() => { setListening(false); onAskQuestion() }, 2500)
  }

  const chips = [t.chip1, t.chip2, t.chip3, t.chip4]

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
        <button onClick={onBack} className="text-slate-600">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        </button>
        <span className="text-base font-bold text-slate-800">{t.orcaAITitle}</span>
        <LangSelector lang={lang} onChange={onLangChange} />
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6 flex flex-col items-center">
        {/* Avatar */}
        <div className="relative mb-4">
          <div className="w-20 h-20 rounded-full flex items-center justify-center shadow-lg" style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}>
            <OrcaLogo size={48} white />
          </div>
          {listening && (
            <>
              <div className="absolute inset-0 rounded-full animate-pulse-ring border-2 border-blue-400 opacity-60" />
              <div className="absolute -inset-3 rounded-full animate-pulse-ring border border-blue-300 opacity-30" style={{ animationDelay: "0.4s" }} />
            </>
          )}
        </div>

        {/* Greeting */}
        <div className="text-center mb-6 px-4">
          {t.orcaGreeting.split("\n").map((line, i) => (
            <p key={i} className={i === 0 ? "font-bold text-slate-800 text-base" : "text-slate-500 text-sm mt-1"}>{line}</p>
          ))}
        </div>

        {/* Suggestion chips */}
        <div className="w-full mb-6">
          <p className="text-xs text-slate-400 font-medium text-center mb-3">{lang === "en" ? "Try asking:" : lang === "hi" ? "पूछें:" : "विचारा:"}</p>
          <div className="flex flex-wrap gap-2 justify-center">
            {chips.map((c, i) => (
              <button
                key={i}
                onClick={onAskQuestion}
                className="px-3 py-2 bg-white rounded-xl text-xs font-medium text-slate-700 border border-slate-200 hover:border-blue-300 hover:text-blue-600 transition-colors shadow-sm text-center"
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Microphone */}
        <div className="flex flex-col items-center">
          <button
            onClick={handleMic}
            className="w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-transform active:scale-95 relative"
            style={{ background: listening ? "linear-gradient(135deg, #DC2626, #EF4444)" : "linear-gradient(135deg, #1565C0, #00B4D8)" }}
          >
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
              <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
              <line x1="12" y1="19" x2="12" y2="23"/>
              <line x1="8" y1="23" x2="16" y2="23"/>
            </svg>
          </button>

          {listening ? (
            <div className="mt-3 flex flex-col items-center">
              <div className="flex items-end gap-0.5 h-8 mb-2">
                {[1,2,3,4,5,6,7].map((b, i) => (
                  <div
                    key={b}
                    className={`w-1.5 rounded-full bg-blue-500 animate-wave-${Math.min(i+1, 5)}`}
                    style={{ height: [16,24,32,20,28,18,22][i] }}
                  />
                ))}
              </div>
              <span className="text-blue-600 text-sm font-semibold">{t.listening}</span>
            </div>
          ) : (
            <p className="mt-3 text-slate-500 text-xs">{t.speakLang}</p>
          )}
        </div>
      </div>

      {/* Input bar */}
      <div className="px-4 pb-4 pt-3 bg-white border-t border-slate-100">
        <div className="flex items-center gap-2 bg-slate-100 rounded-2xl px-4 py-2.5">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={t.typeHere}
            className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder-slate-400"
            onKeyDown={(e) => e.key === "Enter" && onAskQuestion()}
          />
          <button onClick={handleMic}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
          </button>
          <button onClick={onAskQuestion} className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 10: ORCA AI Response ──────────────────────────────────────────────
function OrcaResponseScreen({ t, lang, onLangChange, onBack, onViewMap, onSeeDetails }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onViewMap: () => void; onSeeDetails: () => void }) {
  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
        <button onClick={onBack} className="text-slate-600">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        </button>
        <span className="text-base font-bold text-slate-800">{t.orcaAITitle}</span>
        <LangSelector lang={lang} onChange={onLangChange} />
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* User message */}
        <div className="flex justify-end">
          <div className="max-w-[75%]">
            <div className="bg-blue-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 text-sm font-medium">{t.userQ}</div>
            <div className="text-[10px] text-slate-400 text-right mt-1">10:02 AM</div>
          </div>
        </div>

        {/* ORCA response */}
        <div className="flex gap-3">
          <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center" style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}>
            <OrcaLogo size={20} white />
          </div>
          <div className="flex-1">
            <div className="bg-white rounded-2xl rounded-tl-sm shadow-sm p-4">
              <p className="text-sm text-slate-700 mb-4 leading-relaxed">{t.orcaResp}</p>

              {/* Risk badge + confidence */}
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold text-white bg-green-500">{t.lowRiskBadge}</span>
                <span className="text-xs text-slate-500">{t.confidence} <span className="font-bold text-slate-700">88%</span></span>
              </div>

              {/* Metrics grid */}
              <div className="grid grid-cols-4 gap-2 mb-4">
                {[
                  { label: lang === "en" ? "Wave" : lang === "hi" ? "लहर" : "लाट", value: t.waveRange, icon: "🌊" },
                  { label: lang === "en" ? "Wind" : lang === "hi" ? "हवा" : "वारा", value: t.windRange, icon: "💨" },
                  { label: lang === "en" ? "Rain" : lang === "hi" ? "वर्षा" : "पाऊस", value: t.rainPct, icon: "🌧" },
                  { label: lang === "en" ? "Warning" : lang === "hi" ? "चेतावनी" : "सूचना", value: t.warningNone, icon: "✓" },
                ].map((m, i) => (
                  <div key={i} className="bg-slate-50 rounded-xl p-2 text-center">
                    <div className="text-base mb-0.5">{m.icon}</div>
                    <div className="text-[10px] font-bold text-slate-700">{m.value}</div>
                    <div className="text-[9px] text-slate-400">{m.label}</div>
                  </div>
                ))}
              </div>

              <p className="text-xs text-green-700 bg-green-50 rounded-xl px-3 py-2 mb-4 flex items-center gap-1.5">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#16A34A" strokeWidth="3" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                {t.safeNote}
              </p>

              <div className="flex gap-2">
                <button onClick={onSeeDetails} className="flex-1 py-2.5 rounded-xl font-semibold text-white text-xs" style={{ background: "linear-gradient(135deg, #1565C0, #00B4D8)" }}>{t.seeDetails}</button>
                <button onClick={onViewMap} className="flex-1 py-2.5 rounded-xl font-semibold text-slate-700 text-xs border-2 border-slate-200">{t.viewMap}</button>
              </div>
            </div>
            <div className="text-[10px] text-slate-400 mt-1">10:02 AM</div>
          </div>
        </div>

        <p className="text-center text-xs text-slate-400">{lang === "en" ? "Ask me anything about conditions..." : lang === "hi" ? "समुद्री परिस्थितियों के बारे में पूछें..." : "आणखी काही विचारायचे आहे का?"}</p>
      </div>

      {/* Input */}
      <div className="px-4 pb-4 pt-3 bg-white border-t border-slate-100">
        <div className="flex items-center gap-2 bg-slate-100 rounded-2xl px-4 py-2.5">
          <input
            type="text"
            placeholder={lang === "en" ? "Ask another question..." : lang === "hi" ? "कोई और सवाल पूछें..." : "आणखी काही विचारा..."}
            className="flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder-slate-400"
          />
          <button>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>
          </button>
          <button className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 11: Alerts ────────────────────────────────────────────────────────
function AlertsScreen({ t, lang, onLangChange, onBack, onNav, onViewRoute }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void; onNav: (s: Screen) => void; onViewRoute: () => void }) {
  const [activeTab, setActiveTab] = useState(0)
  const tabs = [t.tabAll, t.tabImportant, t.tabEnded]

  const alerts = [
    {
      level: "HIGH",
      color: "border-orange-400 bg-orange-50",
      badgeColor: "bg-orange-500",
      icon: "⚠️",
      title: t.alert1Title,
      desc: t.alert1Desc,
      time: t.alert1Time,
      action: t.viewDetails,
      onAction: () => {},
    },
    {
      level: "WARNING",
      color: "border-yellow-400 bg-yellow-50",
      badgeColor: "bg-yellow-500",
      icon: "🌊",
      title: t.alert2Title,
      desc: t.alert2Desc,
      time: t.alert2Time,
      action: t.viewNewRoute,
      onAction: onViewRoute,
    },
    {
      level: "INFO",
      color: "border-blue-300 bg-blue-50",
      badgeColor: "bg-blue-500",
      icon: "🐟",
      title: t.alert3Title,
      desc: t.alert3Desc,
      time: t.alert3Time,
      action: t.viewDetails,
      onAction: () => {},
    },
  ]

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <StatusBar />
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
        <button onClick={onBack} className="text-slate-600">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        </button>
        <span className="text-base font-bold text-slate-800">{t.alertsTitle}</span>
        <LangSelector lang={lang} onChange={onLangChange} />
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-100 bg-white">
        {tabs.map((tab, i) => (
          <button
            key={i}
            onClick={() => setActiveTab(i)}
            className={`flex-1 py-3 text-xs font-semibold transition-colors border-b-2 ${
              activeTab === i ? "border-blue-500 text-blue-600" : "border-transparent text-slate-500"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {alerts.map((a, i) => (
          <div key={i} className={`rounded-2xl border-l-4 p-4 ${a.color}`}>
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-lg">{a.icon}</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold text-white ${a.badgeColor}`}>{a.level}</span>
              </div>
              <span className="text-[10px] text-slate-400">{a.time}</span>
            </div>
            <h3 className="font-bold text-slate-800 text-sm mb-1">{a.title}</h3>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">{a.desc}</p>
            <button
              onClick={a.onAction}
              className="px-3 py-2 rounded-xl text-xs font-semibold text-blue-700 bg-white border border-blue-200 hover:bg-blue-50 transition-colors"
            >
              {a.action}
            </button>
          </div>
        ))}
      </div>
      <BottomNav current="alerts" onNav={onNav} t={t} />
    </div>
  )
}

// ─── Screen 12: Emergency SOS ─────────────────────────────────────────────────
function EmergencyScreen({ t, lang, onLangChange, onBack }: { t: Record<string,string>; lang: Lang; onLangChange: (l: Lang) => void; onBack: () => void }) {
  const [sosSent, setSosSent] = useState(false)
  const handleSOS = () => setSosSent(true)

  const actions = [
    { icon: "📍", label: t.shareLocation },
    { icon: "⚓", label: t.findSafeHarbour },
    { icon: "🌊", label: t.calculateDrift },
    { icon: "📞", label: t.contactCoastGuard },
  ]

  return (
    <div className="flex flex-col h-full bg-white">
      <StatusBar />
      <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-slate-100">
        <button onClick={onBack} className="text-slate-600">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
        </button>
        <span className="text-base font-bold text-red-600">{t.emergencyTitle}</span>
        <LangSelector lang={lang} onChange={onLangChange} />
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6 flex flex-col items-center">
        {/* SOS Button */}
        <button
          onClick={handleSOS}
          className={`w-44 h-44 rounded-3xl flex flex-col items-center justify-center shadow-2xl mb-3 transition-transform active:scale-95 ${sosSent ? "bg-slate-400" : ""}`}
          style={sosSent ? undefined : { background: "linear-gradient(135deg, #DC2626, #B91C1C)" }}
        >
          <span className="text-white text-5xl font-black tracking-tight">{t.sos}</span>
          <div className="w-8 h-0.5 bg-white/50 my-1" />
          <svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.68A2 2 0 012 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92V16.92z"/></svg>
        </button>
        <p className="text-sm font-semibold text-slate-600 mb-6">{sosSent ? (lang === "en" ? "✓ SOS Sent!" : lang === "hi" ? "✓ SOS भेजा!" : "✓ SOS पाठवला!") : t.sosLabel}</p>

        {/* Coordinates */}
        <div className="w-full bg-slate-50 rounded-2xl px-4 py-3 mb-4">
          <p className="text-xs text-slate-500 mb-1">{t.coordsLabel}</p>
          <p className="font-mono text-sm font-bold text-slate-800">{t.coords}</p>
          <p className="text-[10px] text-green-600 mt-1 flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
            {t.lastSaved}
          </p>
        </div>

        {/* Action items */}
        <div className="w-full space-y-2">
          {actions.map((a, i) => (
            <button key={i} className="w-full flex items-center gap-3 bg-white rounded-2xl px-4 py-3.5 shadow-sm border border-slate-100 hover:border-blue-200 transition-colors">
              <span className="text-xl">{a.icon}</span>
              <span className="text-sm font-semibold text-slate-700 flex-1 text-left">{a.label}</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>
            </button>
          ))}
        </div>

        {/* Warning */}
        <div className="mt-4 bg-red-50 border border-red-100 rounded-xl px-4 py-3">
          <p className="text-xs text-red-600 text-center leading-relaxed">{t.emergencyWarning}</p>
        </div>
      </div>
    </div>
  )
}

// ─── Screen Navigation Sidebar ────────────────────────────────────────────────
function ScreenNav({ current, onSelect }: { current: Screen; onSelect: (s: Screen) => void }) {
  const screens: { key: Screen; num: string; label: string }[] = [
    { key: "splash", num: "01", label: "Splash" },
    { key: "location-perm", num: "02", label: "Location Perm." },
    { key: "location-detected", num: "03", label: "Location Found" },
    { key: "home", num: "04", label: "Home" },
    { key: "map", num: "05", label: "Marine Map" },
    { key: "trip-planner", num: "06", label: "Trip Planner" },
    { key: "mission", num: "07", label: "Mission" },
    { key: "why-route", num: "08", label: "Why Route?" },
    { key: "orca-ai", num: "09", label: "ORCA AI Voice" },
    { key: "orca-response", num: "10", label: "AI Response" },
    { key: "alerts", num: "11", label: "Alerts" },
    { key: "emergency", num: "12", label: "Emergency" },
  ]
  return (
    <div className="hidden sm:flex flex-col bg-[#0B1D35] w-36 py-4 gap-0.5 overflow-y-auto flex-shrink-0">
      <div className="px-3 pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <OrcaLogo size={24} white />
          <span className="text-white font-black text-sm">ORCA</span>
        </div>
        <p className="text-white/40 text-[9px] mt-1">12-Screen Prototype</p>
      </div>
      {screens.map((s) => (
        <button
          key={s.key}
          onClick={() => onSelect(s.key)}
          className={`flex items-center gap-2 mx-2 px-2 py-2 rounded-lg text-left transition-colors ${
            current === s.key
              ? "bg-blue-600 text-white"
              : "text-white/60 hover:bg-white/10 hover:text-white"
          }`}
        >
          <span className="text-[10px] font-mono font-bold opacity-60">{s.num}</span>
          <span className="text-[10px] font-medium leading-tight">{s.label}</span>
        </button>
      ))}
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("splash")
  const [lang, setLang] = useState<Lang>("mr")
  const [showPFZSheet, setShowPFZSheet] = useState(false)

  const t = T[lang]
  const go = (s: Screen) => { setScreen(s); setShowPFZSheet(false) }
  const goBack = () => {
    const flow: Record<Screen, Screen> = {
      splash: "splash",
      "location-perm": "splash",
      "location-detected": "location-perm",
      home: "location-detected",
      map: "home",
      "trip-planner": "home",
      mission: "trip-planner",
      "why-route": "mission",
      "orca-ai": "home",
      "orca-response": "orca-ai",
      alerts: "home",
      emergency: "home",
    }
    go(flow[screen])
  }

  const sharedProps = { t, lang, onLangChange: setLang }

  return (
    <div className="min-h-screen bg-slate-800 flex" style={{ fontFamily: "'Inter', 'Noto Sans Devanagari', sans-serif" }}>
      <ScreenNav current={screen} onSelect={go} />

      {/* Phone frame */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="relative w-full max-w-[390px]" style={{ height: "min(844px, calc(100vh - 32px))" }}>
          {/* Phone chrome */}
          <div className="absolute inset-0 rounded-[42px] bg-[#1a1a1a] shadow-[0_0_0_2px_#333,0_30px_80px_rgba(0,0,0,0.7)] overflow-hidden">
            {/* Notch */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-7 bg-[#1a1a1a] rounded-b-3xl z-50" />
            {/* Screen */}
            <div className="absolute top-0 left-0 right-0 bottom-0 rounded-[42px] overflow-hidden bg-white">
              <div className="w-full h-full overflow-hidden">
                {screen === "splash" && (
                  <SplashScreen {...sharedProps} onNext={() => go("location-perm")} />
                )}
                {screen === "location-perm" && (
                  <LocationPermScreen {...sharedProps} onBack={goBack} onUseLocation={() => go("location-detected")} onManual={() => go("location-detected")} />
                )}
                {screen === "location-detected" && (
                  <LocationDetectedScreen {...sharedProps} onBack={goBack} onContinue={() => go("home")} />
                )}
                {screen === "home" && (
                  <HomeScreen {...sharedProps} onNav={go} onPlanTrip={() => go("trip-planner")} onAskOrca={() => go("orca-ai")} />
                )}
                {screen === "map" && (
                  <MapScreen {...sharedProps} onNav={go} onPFZSheet={() => setShowPFZSheet(true)} showSheet={showPFZSheet} onCloseSheet={() => setShowPFZSheet(false)} onPlanRoute={() => go("trip-planner")} />
                )}
                {screen === "trip-planner" && (
                  <TripPlannerScreen {...sharedProps} onBack={goBack} onPlan={() => go("mission")} />
                )}
                {screen === "mission" && (
                  <MissionScreen {...sharedProps} onBack={goBack} onNav={go} onWhyRoute={() => go("why-route")} onStartMission={() => go("home")} />
                )}
                {screen === "why-route" && (
                  <WhyRouteScreen {...sharedProps} onBack={goBack} />
                )}
                {screen === "orca-ai" && (
                  <OrcaAIScreen {...sharedProps} onBack={goBack} onNav={go} onAskQuestion={() => go("orca-response")} />
                )}
                {screen === "orca-response" && (
                  <OrcaResponseScreen {...sharedProps} onBack={goBack} onViewMap={() => go("map")} onSeeDetails={() => go("why-route")} />
                )}
                {screen === "alerts" && (
                  <AlertsScreen {...sharedProps} onBack={goBack} onNav={go} onViewRoute={() => go("mission")} />
                )}
                {screen === "emergency" && (
                  <EmergencyScreen {...sharedProps} onBack={goBack} />
                )}
              </div>
            </div>
          </div>

          {/* Side button */}
          <div className="absolute right-[-3px] top-32 w-1 h-16 bg-[#333] rounded-l-sm" />
          <div className="absolute left-[-3px] top-24 w-1 h-10 bg-[#333] rounded-r-sm" />
          <div className="absolute left-[-3px] top-40 w-1 h-10 bg-[#333] rounded-r-sm" />
          <div className="absolute left-[-3px] top-56 w-1 h-10 bg-[#333] rounded-r-sm" />
        </div>
      </div>

      {/* Emergency shortcut */}
      <button
        onClick={() => go("emergency")}
        className="fixed bottom-6 right-6 w-12 h-12 rounded-full bg-red-600 text-white font-black text-xs shadow-xl flex items-center justify-center hover:bg-red-700 transition-colors sm:flex hidden"
        title="Emergency Screen"
      >
        SOS
      </button>
    </div>
  )
}
